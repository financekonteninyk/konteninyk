import Link from "next/link";
import { Sparkles, ArrowRight } from "lucide-react";
import type { CalendarStrategy } from "@/types/calendar";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
}

export function StrategyShowcaseCard({
  strategies,
  shareToken,
  title,
}: {
  strategies: CalendarStrategy[];
  shareToken: string;
  title?: string | null;
}) {
  if (strategies.length === 0) return null;

  const mostRecent = [...strategies].sort((a, b) => b.updated_at.localeCompare(a.updated_at))[0]!;

  return (
    <Link
      href={`/calendar/${shareToken}/strategy`}
      className="group relative block overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-card p-6 transition-all hover:border-primary/40 sm:p-8"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-primary/20 blur-3xl transition-opacity group-hover:opacity-80"
      />
      <div className="relative flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div className="flex items-center gap-4">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-primary">
            <Sparkles className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.15em] text-primary">Content Strategy</p>
            <h2 className="mt-0.5 text-xl font-bold tracking-tight sm:text-2xl">{title || "Strategi & Arah Konten"}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {strategies.length} dokumen · Diperbarui {formatDate(mostRecent.updated_at)}
            </p>
          </div>
        </div>
        <span className="flex shrink-0 items-center gap-1.5 rounded-full border border-primary/30 bg-background/60 px-4 py-2 text-sm font-medium text-primary transition-transform group-hover:translate-x-1">
          Lihat Strategi
          <ArrowRight className="h-4 w-4" />
        </span>
      </div>
    </Link>
  );
}
