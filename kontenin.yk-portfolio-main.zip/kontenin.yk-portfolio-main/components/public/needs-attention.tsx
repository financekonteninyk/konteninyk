import { AlertTriangle } from "lucide-react";
import type { ContentCalendarEntry } from "@/types/calendar";

function isOverdueOrToday(entryDate: string): "overdue" | "today" | null {
  const target = new Date(entryDate + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffDays = Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays < 0) return "overdue";
  if (diffDays === 0) return "today";
  return null;
}

export function NeedsAttention({ entries }: { entries: ContentCalendarEntry[] }) {
  const active = entries.filter((e) => e.status !== "published" && e.status !== "cancelled");

  const overdue = active.filter((e) => isOverdueOrToday(e.entry_date) === "overdue");
  const dueToday = active.filter((e) => isOverdueOrToday(e.entry_date) === "today");

  if (overdue.length === 0 && dueToday.length === 0) return null;

  const items: string[] = [];
  if (overdue.length > 0) items.push(`${overdue.length} konten sudah melewati jadwal upload`);
  if (dueToday.length > 0) items.push(`${dueToday.length} konten harus diupload hari ini`);

  return (
    <div className="rounded-2xl border border-destructive/40 bg-destructive/[0.08] p-4">
      <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-destructive">
        <AlertTriangle className="h-4 w-4" />
        Perlu Perhatian
      </p>
      <ul className="space-y-1">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-foreground/90">
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
