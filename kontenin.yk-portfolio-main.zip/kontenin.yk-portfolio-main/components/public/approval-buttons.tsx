"use client";

import * as React from "react";
import { Check, XCircle, Send, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { setApprovalStatusAction, rejectEntryWithCommentAction } from "@/lib/actions/calendar";
import type { ApprovalStatus } from "@/types/calendar";

interface ApprovalButtonsProps {
  entryId: string;
  calendarId: string;
  onDecided: (status: ApprovalStatus, timestamp: string) => void;
}

export function ApprovalButtons({ entryId, calendarId, onDecided }: ApprovalButtonsProps) {
  const [askingReason, setAskingReason] = React.useState(false);
  const [reason, setReason] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  async function handleApprove() {
    setBusy(true);
    await setApprovalStatusAction(entryId, "approved");
    onDecided("approved", new Date().toISOString());
    setBusy(false);
  }

  async function handleConfirmReject() {
    const trimmed = reason.trim();
    if (!trimmed) return;
    setBusy(true);
    const result = await rejectEntryWithCommentAction(entryId, calendarId, trimmed);
    if (!result.error) {
      onDecided("rejected", new Date().toISOString());
      setAskingReason(false);
      setReason("");
    }
    setBusy(false);
  }

  if (askingReason) {
    return (
      <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3">
        <p className="mb-2 text-xs font-medium text-destructive">
          Kasih tau alasan atau referensi revisinya dulu — biar kami tau harus perbaiki apa.
        </p>
        <div className="flex items-center gap-2">
          <Input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Apa yang perlu direvisi?"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleConfirmReject();
              }
            }}
          />
          <Button type="button" size="icon" variant="destructive" disabled={busy || !reason.trim()} onClick={handleConfirmReject} aria-label="Kirim & Tolak">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
          <Button
            type="button"
            size="icon"
            variant="ghost"
            disabled={busy}
            onClick={() => {
              setAskingReason(false);
              setReason("");
            }}
            aria-label="Batal"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-2">
      <Button type="button" size="sm" disabled={busy} onClick={handleApprove}>
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
        Setuju
      </Button>
      <Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => setAskingReason(true)}>
        <XCircle className="h-3.5 w-3.5" />
        Minta Revisi
      </Button>
    </div>
  );
}
