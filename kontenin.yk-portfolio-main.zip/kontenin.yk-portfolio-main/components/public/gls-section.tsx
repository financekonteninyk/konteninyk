"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Send, CheckCircle2, Circle, RefreshCw, MessagesSquare, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { postGlsCommentAction, type CalendarActionState } from "@/lib/actions/calendar";
import type { CalendarGlsEntry } from "@/types/calendar";

const initialState: CalendarActionState = {};

function LiveClock() {
  const [now, setNow] = React.useState<Date | null>(null);

  React.useEffect(() => {
    setNow(new Date());
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  if (!now) return null;

  return (
    <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
      <RefreshCw className="h-3 w-3" />
      {now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
    </p>
  );
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", { day: "numeric", month: "short", year: "numeric" });
}

export function GlsSection({ calendarId, entries }: { calendarId: string; entries: CalendarGlsEntry[] }) {
  const [open, setOpen] = React.useState(false);
  const resolvedCount = entries.filter((e) => e.is_resolved).length;
  const pendingCount = entries.length - resolvedCount;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-4 text-left transition-colors hover:border-primary/40"
      >
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <MessagesSquare className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">GLS — Growth Loop System</p>
          <p className="text-xs text-muted-foreground">
            {entries.length === 0
              ? "No feedback yet"
              : `${resolvedCount} resolved · ${pendingCount} pending`}
          </p>
        </div>
      </button>

      {open && <GlsPopup calendarId={calendarId} entries={entries} onClose={() => setOpen(false)} />}
    </>
  );
}

function GlsPopup({ calendarId, entries, onClose }: { calendarId: string; entries: CalendarGlsEntry[]; onClose: () => void }) {
  const boundAction = postGlsCommentAction.bind(null, calendarId);
  const [state, formAction] = useActionState(boundAction, initialState);
  const [localEntries, setLocalEntries] = React.useState(entries);
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);
  const formRef = React.useRef<HTMLFormElement>(null);
  const isFirstRender = React.useRef(true);

  React.useEffect(() => setLocalEntries(entries), [entries]);

  React.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    if (!state.error) {
      const message = textareaRef.current?.value.trim();
      if (message) {
        setLocalEntries((prev) => [
          { id: `local-${Date.now()}`, calendar_id: calendarId, client_comment: message, resolution: null, is_resolved: false, created_at: new Date().toISOString(), resolved_at: null },
          ...prev,
        ]);
      }
      formRef.current?.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-border bg-card" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h3 className="text-sm font-semibold">GLS — Growth Loop System</h3>
          <button type="button" onClick={onClose} aria-label="Close" className="text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5">
          <p className="mb-4 text-xs text-muted-foreground">Share a concern or suggestion — our team follows up here.</p>

          {localEntries.length > 0 && (
            <div className="mb-4 space-y-3">
              {localEntries.map((entry) => (
                <div key={entry.id} className="rounded-xl border border-border p-3.5">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Comment</p>
                      <p className="text-sm">{entry.client_comment}</p>
                    </div>
                    <div className="border-t border-border pt-3 sm:border-l sm:border-t-0 sm:pl-3 sm:pt-0">
                      <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Resolution</p>
                      {entry.resolution ? (
                        <p className="text-sm text-muted-foreground">{entry.resolution}</p>
                      ) : (
                        <p className="text-sm italic text-muted-foreground">Not yet addressed</p>
                      )}
                    </div>
                  </div>
                  <div className="mt-2.5 flex items-center justify-between border-t border-border pt-2.5">
                    <span className="text-[10px] text-muted-foreground">{formatDate(entry.created_at)}</span>
                    <span className={`flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide ${entry.is_resolved ? "text-emerald-600" : "text-muted-foreground"}`}>
                      {entry.is_resolved ? <CheckCircle2 className="h-3 w-3" /> : <Circle className="h-3 w-3" />}
                      {entry.is_resolved ? "Resolved" : "Pending"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {state.error && <p className="mb-3 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{state.error}</p>}

          <form ref={formRef} action={formAction} className="space-y-2.5">
            <Textarea ref={textareaRef} name="client_comment" rows={2} placeholder="Write your concern or suggestion..." required />
            <div className="flex items-center justify-between">
              <LiveClock />
              <SubmitButton />
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="sm" disabled={pending}>
      {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
      Send
    </Button>
  );
}
