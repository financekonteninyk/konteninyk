"use client";

import * as React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CalendarGrid } from "@/components/admin/calendar-grid";
import { CalendarFilterBar } from "@/components/public/calendar-filter-bar";
import { CalendarDayDetail } from "@/components/public/calendar-day-detail";
import { getWorkflowStage, type WorkflowStage } from "@/lib/calendar-workflow";
import type { ContentCalendarEntry, CalendarEntryComment } from "@/types/calendar";

interface PublicCalendarViewerProps {
  entries: ContentCalendarEntry[];
  commentsByEntry: Record<string, CalendarEntryComment[]>;
  calendarId: string;
}

const MONTH_NAMES = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];

export function PublicCalendarViewer({ entries, commentsByEntry, calendarId }: PublicCalendarViewerProps) {
  const now = new Date();
  const [year, setYear] = React.useState(now.getFullYear());
  const [month, setMonth] = React.useState(now.getMonth());
  const [selectedDate, setSelectedDate] = React.useState<string | null>(null);
  const [filter, setFilter] = React.useState<WorkflowStage | "all">("all");

  function goToMonth(delta: number) {
    let newMonth = month + delta;
    let newYear = year;
    if (newMonth < 0) {
      newMonth = 11;
      newYear -= 1;
    } else if (newMonth > 11) {
      newMonth = 0;
      newYear += 1;
    }
    setMonth(newMonth);
    setYear(newYear);
  }

  const filteredEntries = filter === "all" ? entries : entries.filter((e) => getWorkflowStage(e) === filter);
  const selectedEntries = selectedDate ? entries.filter((e) => e.entry_date === selectedDate) : [];

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-lg font-semibold sm:text-xl">
          {MONTH_NAMES[month]} {year}
        </h2>
        <div className="flex items-center gap-1">
          <Button type="button" variant="outline" size="icon" onClick={() => goToMonth(-1)} aria-label="Bulan sebelumnya">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setYear(now.getFullYear());
              setMonth(now.getMonth());
            }}
          >
            Today
          </Button>
          <Button type="button" variant="outline" size="icon" onClick={() => goToMonth(1)} aria-label="Bulan berikutnya">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="mb-4">
        <CalendarFilterBar active={filter} onChange={setFilter} />
      </div>

      <CalendarGrid
        year={year}
        month={month}
        entries={filteredEntries}
        readOnly
        onDayClick={() => {}}
        onEntryClick={(entry) => setSelectedDate(entry.entry_date)}
        onShowMore={(isoDate) => setSelectedDate(isoDate)}
      />

      {selectedDate && selectedEntries.length > 0 && (
        <CalendarDayDetail
          isoDate={selectedDate}
          entries={selectedEntries}
          commentsByEntry={commentsByEntry}
          calendarId={calendarId}
          onClose={() => setSelectedDate(null)}
        />
      )}
    </div>
  );
}
