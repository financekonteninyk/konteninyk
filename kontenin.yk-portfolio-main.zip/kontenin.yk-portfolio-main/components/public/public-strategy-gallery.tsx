"use client";

import * as React from "react";
import { X, FileText, BookOpen, ChevronRight, ArrowLeft } from "lucide-react";
import type { CalendarStrategy } from "@/types/calendar";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
}

export function PublicStrategyGallery({ strategies }: { strategies: CalendarStrategy[] }) {
  const [open, setOpen] = React.useState(false);
  const [viewing, setViewing] = React.useState<CalendarStrategy | null>(null);

  if (strategies.length === 0) return null;

  // Safe: the early return above guarantees strategies.length > 0, so
  // sorting and taking [0] always has a value — TypeScript just can't
  // trace that guarantee through the array index on its own.
  const mostRecent = [...strategies].sort((a, b) => b.updated_at.localeCompare(a.updated_at))[0]!;

  function close() {
    setOpen(false);
    setViewing(null);
  }

  return (
    <>
      {/* Compact summary card — the actual content lives behind the modal */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-4 text-left transition-colors hover:border-primary/40"
      >
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <BookOpen className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">Content Strategy</p>
          <p className="truncate text-xs text-muted-foreground">
            {strategies.length === 1 ? "Strategic direction & content plan" : `${strategies.length} dokumen strategi`}
          </p>
          <p className="mt-0.5 text-[11px] text-muted-foreground">Diperbarui {formatDate(mostRecent.updated_at)}</p>
        </div>
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
      </button>

      {open && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={close}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-border bg-card" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              {viewing ? (
                <button type="button" onClick={() => setViewing(null)} className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
                  <ArrowLeft className="h-4 w-4" />
                  Kembali
                </button>
              ) : (
                <h3 className="text-sm font-semibold">Dokumen Strategi</h3>
              )}
              <button type="button" onClick={close} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>

            {viewing ? (
              <div className="p-5">
                <h4 className="mb-3 text-base font-semibold">{viewing.title}</h4>
                <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{viewing.content}</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {strategies.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setViewing(s)}
                    className="flex w-full items-center gap-3 px-5 py-3.5 text-left transition-colors hover:bg-secondary/40"
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <FileText className="h-3.5 w-3.5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{s.title}</p>
                      <p className="line-clamp-1 text-xs text-muted-foreground">{s.content}</p>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
