"use client";

import { WORKFLOW_STAGE_LABELS, WORKFLOW_STAGE_ORDER, type WorkflowStage } from "@/lib/calendar-workflow";

interface CalendarFilterBarProps {
  active: WorkflowStage | "all";
  onChange: (stage: WorkflowStage | "all") => void;
}

export function CalendarFilterBar({ active, onChange }: CalendarFilterBarProps) {
  return (
    <div className="flex flex-wrap gap-1.5">
      <button
        type="button"
        onClick={() => onChange("all")}
        className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
          active === "all" ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-foreground/30"
        }`}
      >
        Semua
      </button>
      {WORKFLOW_STAGE_ORDER.map((stage) => (
        <button
          key={stage}
          type="button"
          onClick={() => onChange(stage)}
          className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
            active === stage ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-foreground/30"
          }`}
        >
          {WORKFLOW_STAGE_LABELS[stage]}
        </button>
      ))}
    </div>
  );
}
