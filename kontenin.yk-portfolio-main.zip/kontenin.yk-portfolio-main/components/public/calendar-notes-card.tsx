import { StickyNote } from "lucide-react";
import type { ContentCalendar } from "@/types/calendar";

export function CalendarNotesCard({ calendar }: { calendar: ContentCalendar }) {
  if (!calendar.notes) return null;

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <p className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold">
        <StickyNote className="h-4 w-4" />
        Catatan
      </p>
      <p className="whitespace-pre-line text-sm text-muted-foreground">{calendar.notes}</p>
    </div>
  );
}
