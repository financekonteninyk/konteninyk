"use client";

import * as React from "react";
import { Activity, X, Check, Clock3 } from "lucide-react";
import { setClientConfirmedAction } from "@/lib/actions/calendar";
import { countByStage, WORKFLOW_STAGE_LABELS, WORKFLOW_STAGE_ORDER } from "@/lib/calendar-workflow";
import type { ContentCalendar, ContentCalendarEntry } from "@/types/calendar";

function daysRemaining(endDateIso: string): number {
  const end = new Date(endDateIso + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function todayIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function formatDate(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-US", { day: "numeric", month: "short" });
}

/** Content the client is responsible for publishing themselves — approved,
 * due or overdue, and not yet confirmed as uploaded. This is what drives
 * the widget's alert state. */
function getPendingUploads(entries: ContentCalendarEntry[]): ContentCalendarEntry[] {
  const today = todayIso();
  return entries.filter((e) => e.approval_status === "approved" && !e.client_confirmed && e.entry_date <= today);
}

export function FloatingMetricsWidget({ calendar, entries }: { calendar: ContentCalendar; entries: ContentCalendarEntry[] }) {
  const [open, setOpen] = React.useState(false);
  const [localEntries, setLocalEntries] = React.useState(entries);
  const [tab, setTab] = React.useState<"uploads" | "stats">("uploads");

  React.useEffect(() => setLocalEntries(entries), [entries]);

  const pendingUploads = getPendingUploads(localEntries);
  const hasAlert = pendingUploads.length > 0;

  const stageCounts = countByStage(localEntries);
  const remaining = calendar.contract_end_date ? daysRemaining(calendar.contract_end_date) : null;

  async function handleConfirm(entryId: string, confirmed: boolean) {
    setLocalEntries((prev) => prev.map((e) => (e.id === entryId ? { ...e, client_confirmed: confirmed } : e)));
    await setClientConfirmedAction(entryId, confirmed);
  }

  return (
    <div className="fixed bottom-20 left-5 z-40 lg:bottom-5">
      <style>{`
        @keyframes cfs-shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-3px); }
          40% { transform: translateX(3px); }
          60% { transform: translateX(-2px); }
          80% { transform: translateX(2px); }
        }
        .cfs-shake { animation: cfs-shake 0.5s ease-in-out infinite; animation-play-state: running; }
      `}</style>

      {open && (
        <div className="mb-3 w-72 overflow-hidden rounded-2xl border border-border bg-card shadow-2xl">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => setTab("uploads")}
                className={`rounded-full px-2.5 py-1 text-xs font-medium transition-colors ${
                  tab === "uploads" ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Uploads {pendingUploads.length > 0 && `(${pendingUploads.length})`}
              </button>
              <button
                type="button"
                onClick={() => setTab("stats")}
                className={`rounded-full px-2.5 py-1 text-xs font-medium transition-colors ${
                  tab === "stats" ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Overview
              </button>
            </div>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </button>
          </div>

          {tab === "uploads" ? (
            <div className="max-h-72 overflow-y-auto p-3">
              {pendingUploads.length === 0 ? (
                <p className="px-1 py-4 text-center text-sm text-muted-foreground">Nothing waiting on you right now.</p>
              ) : (
                <div className="space-y-2">
                  {pendingUploads.map((entry) => (
                    <div key={entry.id} className="rounded-xl border border-destructive/30 bg-destructive/[0.06] p-3">
                      <div className="mb-2 flex items-center justify-between">
                        <p className="text-sm font-medium">{entry.content_type}</p>
                        <span className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-destructive">
                          <Clock3 className="h-3 w-3" />
                          {formatDate(entry.entry_date)}
                        </span>
                      </div>
                      <p className="mb-2 text-xs text-muted-foreground">Has this gone live yet?</p>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => handleConfirm(entry.id, true)}
                          className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-emerald-500/15 px-2 py-1.5 text-xs font-medium text-emerald-600 transition-colors hover:bg-emerald-500/25"
                        >
                          <Check className="h-3.5 w-3.5" />
                          Uploaded
                        </button>
                        <button
                          type="button"
                          onClick={() => handleConfirm(entry.id, false)}
                          className="flex-1 rounded-lg border border-border px-2 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
                        >
                          Not yet
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-2 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total Content</span>
                <span className="font-semibold tabular-nums">{localEntries.length}</span>
              </div>
              {WORKFLOW_STAGE_ORDER.map((stage) => (
                <div key={stage} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{WORKFLOW_STAGE_LABELS[stage]}</span>
                  <span className="font-semibold tabular-nums">{stageCounts[stage]}</span>
                </div>
              ))}
              {remaining !== null && (
                <div className="flex items-center justify-between border-t border-border pt-2 text-sm">
                  <span className="text-muted-foreground">Days Remaining</span>
                  <span className="font-semibold tabular-nums text-primary">{remaining > 0 ? remaining : 0}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-medium shadow-xl transition-transform hover:scale-105 ${
          hasAlert && !open ? "cfs-shake border-destructive/50 bg-destructive text-destructive-foreground" : "border-border bg-card"
        }`}
      >
        <Activity className="h-4 w-4" />
        {hasAlert ? `${pendingUploads.length} Needs Upload` : `${entries.length} Content`}
      </button>
    </div>
  );
}
