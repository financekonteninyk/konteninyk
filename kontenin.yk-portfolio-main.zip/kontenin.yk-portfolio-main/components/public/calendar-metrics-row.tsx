import { countByStage, WORKFLOW_STAGE_LABELS, WORKFLOW_STAGE_ORDER } from "@/lib/calendar-workflow";
import type { ContentCalendar, ContentCalendarEntry } from "@/types/calendar";

function daysRemaining(endDateIso: string): number {
  const end = new Date(endDateIso + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function MetricCard({ value, label, accent = false }: { value: string; label: string; accent?: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-card px-3.5 py-3">
      <p className={`text-xl font-bold tabular-nums tracking-tight sm:text-2xl ${accent ? "text-primary" : ""}`}>{value}</p>
      <p className="mt-0.5 truncate text-[11px] font-medium text-muted-foreground">{label}</p>
    </div>
  );
}

export function CalendarMetricsRow({ calendar, entries }: { calendar: ContentCalendar; entries: ContentCalendarEntry[] }) {
  const stageCounts = countByStage(entries);
  const remaining = calendar.contract_end_date ? daysRemaining(calendar.contract_end_date) : null;

  const cards = [
    { value: String(entries.length), label: "Total Konten" },
    ...WORKFLOW_STAGE_ORDER.map((stage) => ({ value: String(stageCounts[stage]), label: WORKFLOW_STAGE_LABELS[stage] })),
  ];
  if (remaining !== null) {
    cards.push({ value: remaining > 0 ? String(remaining) : "0", label: "Hari Tersisa" });
  }

  return (
    <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 lg:grid-cols-7">
      {cards.map((card, i) => (
        <MetricCard key={i} value={card.value} label={card.label} accent={i === 0} />
      ))}
    </div>
  );
}
