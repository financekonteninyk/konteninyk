"use client";

import * as React from "react";
import { CalendarDays, ListTodo, BookOpen, Inbox } from "lucide-react";

const NAV_ITEMS = [
  { id: "strategy", label: "Strategy", icon: BookOpen },
  { id: "calendar", label: "Calendar", icon: CalendarDays },
  { id: "content", label: "Content", icon: ListTodo },
  { id: "requests", label: "Requests", icon: Inbox },
];

export function CfsSidebar() {
  const [active, setActive] = React.useState("strategy");

  React.useEffect(() => {
    const sections = NAV_ITEMS.map((item) => document.getElementById(item.id)).filter((el): el is HTMLElement => el !== null);

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-20% 0px -60% 0px", threshold: [0, 0.25, 0.5, 1] }
    );

    sections.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  function scrollTo(id: string) {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <aside className="hidden w-[72px] shrink-0 flex-col items-center gap-1 border-r border-border py-5 lg:flex">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = active === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => scrollTo(item.id)}
            title={item.label}
            className={`flex h-11 w-11 flex-col items-center justify-center gap-0.5 rounded-xl transition-colors ${
              isActive ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            <Icon className="h-4 w-4" />
          </button>
        );
      })}
    </aside>
  );
}

/** Mobile equivalent — a fixed bottom bar with the same anchor targets. */
export function CfsMobileNav() {
  function scrollTo(id: string) {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <nav className="fixed inset-x-3 bottom-3 z-40 flex items-center justify-around rounded-2xl border border-border bg-card/95 px-1 py-1.5 shadow-2xl backdrop-blur lg:hidden">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => scrollTo(item.id)}
            className="flex flex-1 flex-col items-center gap-0.5 rounded-xl py-2 text-[10px] font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </button>
        );
      })}
    </nav>
  );
}
