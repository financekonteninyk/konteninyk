"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Send, CheckCircle2, MessageSquarePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { submitCalendarRequestAction, type CalendarActionState } from "@/lib/actions/calendar";

const initialState: CalendarActionState = {};

export function CalendarRequestForm({ calendarId }: { calendarId: string }) {
  const boundAction = submitCalendarRequestAction.bind(null, calendarId);
  const [state, formAction] = useActionState(boundAction, initialState);
  const [submitted, setSubmitted] = React.useState(false);
  const isFirstRender = React.useRef(true);

  React.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    if (!state.error) setSubmitted(true);
  }, [state]);

  if (submitted) {
    return (
      <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-6 text-center">
        <CheckCircle2 className="mx-auto mb-2 h-6 w-6 text-emerald-600" />
        <p className="font-medium">Terima kasih — request kamu sudah terkirim!</p>
        <p className="mt-1 text-sm text-muted-foreground">Tim kami akan meninjau dan memperbarui kalender sesuai kebutuhan.</p>
        <Button type="button" variant="ghost" size="sm" className="mt-3" onClick={() => setSubmitted(false)}>
          Kirim request lain
        </Button>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border p-6">
      <p className="mb-1 flex items-center gap-2 font-semibold">
        <MessageSquarePlus className="h-4 w-4 text-primary" />
        Request Konten atau Kasih Referensi
      </p>
      <p className="mb-4 text-sm text-muted-foreground">
        Ada ide, kebutuhan mendadak, atau sesuatu yang ingin dibuatkan? Kasih tau kami di sini — kami akan tinjau dan
        masukkan ke kalender.
      </p>

      {state.error && (
        <p className="mb-4 rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>
      )}

      <form action={formAction} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="message">Butuh konten apa?</Label>
          <Textarea id="message" name="message" rows={3} placeholder="cth. Bisa dibuatkan Reels tentang menu baru yang launching minggu depan?" required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="reference_url">Link referensi (opsional)</Label>
          <Input id="reference_url" name="reference_url" placeholder="Link contoh, foto, atau inspirasi" />
        </div>
        <SubmitButton />
      </form>
    </div>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
      Kirim Request
    </Button>
  );
}
