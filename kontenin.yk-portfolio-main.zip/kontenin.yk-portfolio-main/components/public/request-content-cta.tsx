"use client";

import * as React from "react";
import { MessageSquarePlus, ListOrdered, X } from "lucide-react";
import { CalendarRequestForm } from "@/components/public/calendar-request-form";
import { CalendarRequestHistory } from "@/components/public/calendar-request-history";
import type { ContentCalendarRequest } from "@/types/calendar";

interface RequestContentCtaProps {
  calendarId: string;
  requests: ContentCalendarRequest[];
}

export function RequestContentCta({ calendarId, requests }: RequestContentCtaProps) {
  const [formOpen, setFormOpen] = React.useState(false);
  const [listOpen, setListOpen] = React.useState(false);

  return (
    <>
      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => setFormOpen(true)}
          className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-card px-4 py-3.5 text-sm font-medium text-foreground transition-colors hover:border-primary/40 hover:bg-secondary/30"
        >
          <MessageSquarePlus className="h-4 w-4 text-primary" />
          Request Konten
        </button>
        <button
          type="button"
          onClick={() => setListOpen(true)}
          className="flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-4 py-3.5 text-sm font-medium text-foreground transition-colors hover:border-foreground/30 hover:bg-secondary/30"
        >
          <ListOrdered className="h-4 w-4 text-muted-foreground" />
          Daftar Request
        </button>
      </div>

      {/* Wide popup — form for submitting a new request */}
      {formOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={() => setFormOpen(false)}>
          <div className="relative w-full max-w-2xl" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              onClick={() => setFormOpen(false)}
              aria-label="Tutup"
              className="absolute -top-10 right-0 text-white/80 hover:text-white"
            >
              <X className="h-6 w-6" />
            </button>
            <CalendarRequestForm calendarId={calendarId} />
          </div>
        </div>
      )}

      {/* Popup — history of requests already sent */}
      {listOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={() => setListOpen(false)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-border bg-card" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              <h3 className="text-sm font-semibold">Daftar Request</h3>
              <button type="button" onClick={() => setListOpen(false)} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>
            {requests.length === 0 ? (
              <p className="p-5 text-center text-sm text-muted-foreground">Belum ada request yang dikirim.</p>
            ) : (
              <CalendarRequestHistory requests={requests} bare />
            )}
          </div>
        </div>
      )}
    </>
  );
}
