import type { ContentCalendar, ContentCalendarEntry } from "@/types/calendar";

function daysRemaining(endDateIso: string): number {
  const end = new Date(endDateIso + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

interface StatCardProps {
  value: string;
  label: string;
}

function StatCard({ value, label }: StatCardProps) {
  return (
    <div className="rounded-xl border border-border bg-card px-4 py-3.5">
      <p className="text-2xl font-bold tabular-nums tracking-tight">{value}</p>
      <p className="mt-0.5 text-xs font-medium text-muted-foreground">{label}</p>
    </div>
  );
}

export function CalendarStatsRow({ calendar, entries }: { calendar: ContentCalendar; entries: ContentCalendarEntry[] }) {
  const total = entries.length;
  const approved = entries.filter((e) => e.approval_status === "approved").length;
  const published = entries.filter((e) => e.status === "published").length;

  const remaining = calendar.contract_end_date ? daysRemaining(calendar.contract_end_date) : null;
  const remainingLabel = remaining === null ? null : remaining > 0 ? String(remaining) : remaining === 0 ? "0" : "—";

  return (
    <div className={`grid grid-cols-2 gap-3 ${remainingLabel !== null ? "sm:grid-cols-4" : "sm:grid-cols-3"}`}>
      <StatCard value={String(total)} label="Total Konten" />
      <StatCard value={String(approved)} label="Disetujui" />
      <StatCard value={String(published)} label="Sudah Tayang" />
      {remainingLabel !== null && <StatCard value={remainingLabel} label="Hari Tersisa" />}
    </div>
  );
}
