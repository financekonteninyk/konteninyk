import { Circle, CheckCircle2, XCircle } from "lucide-react";
import type { ContentCalendarRequest } from "@/types/calendar";

const STATUS_CONFIG = {
  pending: { label: "OPEN", icon: Circle, className: "bg-primary/10 text-primary" },
  placed: { label: "DIJADWALKAN", icon: CheckCircle2, className: "bg-emerald-500/10 text-emerald-600" },
  dismissed: { label: "SELESAI", icon: XCircle, className: "bg-secondary text-muted-foreground" },
} as const;

export function CalendarRequestHistory({ requests, bare = false }: { requests: ContentCalendarRequest[]; bare?: boolean }) {
  if (requests.length === 0) return null;

  // Purely presentational ticket numbers — oldest request is #001, so
  // numbering stays stable as new requests come in. Not stored anywhere.
  const chronological = [...requests].sort((a, b) => a.created_at.localeCompare(b.created_at));
  const ticketNumber = new Map(chronological.map((r, i) => [r.id, i + 1]));

  const rows = (
    <div className="divide-y divide-border">
      {requests.map((req) => {
        const config = STATUS_CONFIG[req.status];
        const StatusIcon = config.icon;
        return (
          <div key={req.id} className="flex items-start justify-between gap-3 px-5 py-3.5">
            <div className="min-w-0">
              <p className="text-[11px] font-semibold tabular-nums text-muted-foreground">
                #{String(ticketNumber.get(req.id) ?? 0).padStart(3, "0")}
              </p>
              <p className="truncate text-sm">{req.message}</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {new Date(req.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}
              </p>
            </div>
            <span className={`flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-wide ${config.className}`}>
              <StatusIcon className="h-3 w-3" />
              {config.label}
            </span>
          </div>
        );
      })}
    </div>
  );

  if (bare) return rows;

  return (
    <div className="rounded-2xl border border-border bg-card">
      <div className="border-b border-border px-5 py-4">
        <h3 className="text-sm font-semibold">Requests</h3>
      </div>
      {rows}
    </div>
  );
}
