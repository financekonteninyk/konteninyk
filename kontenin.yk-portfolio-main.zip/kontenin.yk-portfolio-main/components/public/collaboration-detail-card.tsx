import { Calendar, StickyNote } from "lucide-react";
import type { ContentCalendar } from "@/types/calendar";

function formatDate(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
}

function daysRemaining(endDateIso: string): number {
  const end = new Date(endDateIso + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export function CollaborationDetailCard({ calendar }: { calendar: ContentCalendar }) {
  const hasContractDates = calendar.contract_start_date && calendar.contract_end_date;
  if (!hasContractDates && !calendar.notes) return null;

  const remaining = calendar.contract_end_date ? daysRemaining(calendar.contract_end_date) : null;

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <p className="mb-3 flex items-center gap-1.5 text-sm font-semibold">
        <Calendar className="h-4 w-4" />
        Detail Kerja Sama
      </p>

      {hasContractDates && (
        <div className="mb-3 space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Mulai</span>
            <span className="font-medium">{formatDate(calendar.contract_start_date!)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Selesai</span>
            <span className="font-medium">{formatDate(calendar.contract_end_date!)}</span>
          </div>
          {remaining !== null && (
            <div className="flex items-center justify-between border-t border-border pt-2">
              <span className="text-muted-foreground">Sisa Waktu</span>
              <span className="font-semibold text-primary">{remaining > 0 ? `${remaining} hari lagi` : remaining === 0 ? "Berakhir hari ini" : "Sudah berakhir"}</span>
            </div>
          )}
        </div>
      )}

      {calendar.notes && (
        <div className={hasContractDates ? "border-t border-border pt-3" : ""}>
          <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            <StickyNote className="h-3 w-3" />
            Catatan
          </p>
          <p className="whitespace-pre-line text-sm text-muted-foreground">{calendar.notes}</p>
        </div>
      )}
    </div>
  );
}
