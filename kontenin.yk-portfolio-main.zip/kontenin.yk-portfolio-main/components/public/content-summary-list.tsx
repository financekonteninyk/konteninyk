"use client";

import * as React from "react";
import { CheckCheck, Loader2, X, ArrowRight, CheckSquare, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ApprovalButtons } from "@/components/public/approval-buttons";
import { approveAllEntriesAction, setClientConfirmedAction } from "@/lib/actions/calendar";
import { getWorkflowStage, WORKFLOW_STAGE_LABELS, STAGE_ICON, STAGE_COLOR } from "@/lib/calendar-workflow";
import type { ContentCalendarEntry } from "@/types/calendar";

function formatShortDate(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("id-ID", { day: "numeric", month: "short" }).toUpperCase();
}

/** Content still to be uploaded (anything not yet published/cancelled)
 * comes first, nearest date first. Already-published items fall to the
 * bottom, so the list always leads with what's coming up next. */
function sortByWhatsNext(entries: ContentCalendarEntry[]): ContentCalendarEntry[] {
  return [...entries].sort((a, b) => {
    const aDone = a.status === "published" || a.status === "cancelled";
    const bDone = b.status === "published" || b.status === "cancelled";
    if (aDone !== bDone) return aDone ? 1 : -1;
    return a.entry_date.localeCompare(b.entry_date);
  });
}

interface ContentSummaryListProps {
  calendarId: string;
  entries: ContentCalendarEntry[];
  editable?: boolean;
}

export function ContentSummaryList({ calendarId, entries, editable = true }: ContentSummaryListProps) {
  const [localEntries, setLocalEntries] = React.useState(entries);
  const [approvingAll, setApprovingAll] = React.useState(false);
  const [showAllModal, setShowAllModal] = React.useState(false);

  React.useEffect(() => setLocalEntries(entries), [entries]);

  const sorted = sortByWhatsNext(localEntries);
  const pendingCount = sorted.filter((e) => e.approval_status === "pending").length;
  const preview = sorted.slice(0, 3);
  const hiddenCount = sorted.length - preview.length;

  function updateEntry(entryId: string, patch: Partial<ContentCalendarEntry>) {
    setLocalEntries((prev) => prev.map((e) => (e.id === entryId ? { ...e, ...patch } : e)));
  }

  async function handleApproveAll() {
    setApprovingAll(true);
    await approveAllEntriesAction(calendarId);
    const now = new Date().toISOString();
    setLocalEntries((prev) => prev.map((e) => (e.approval_status === "pending" ? { ...e, approval_status: "approved", approval_updated_at: now } : e)));
    setApprovingAll(false);
  }

  if (sorted.length === 0) {
    return (
      <div className="rounded-2xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">
        Belum ada konten yang direncanakan.
      </div>
    );
  }

  return (
    <>
      <div className="rounded-2xl border border-border bg-card">
        <div className="flex items-center justify-between px-5 py-4">
          <h3 className="text-sm font-semibold">Upcoming Content</h3>
          {editable && pendingCount > 0 && (
            <Button type="button" size="sm" variant="outline" disabled={approvingAll} onClick={handleApproveAll}>
              {approvingAll ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCheck className="h-3.5 w-3.5" />}
              Setujui Semua
            </Button>
          )}
        </div>

        <div className="divide-y divide-border">
          {preview.map((entry) => (
            <SummaryRow key={entry.id} entry={entry} calendarId={calendarId} editable={editable} onUpdate={updateEntry} />
          ))}
        </div>

        {hiddenCount > 0 && (
          <button
            type="button"
            onClick={() => setShowAllModal(true)}
            className="flex w-full items-center justify-center gap-1 border-t border-border px-5 py-3 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Lihat Semua
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {showAllModal && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={() => setShowAllModal(false)}>
          <div
            className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-border bg-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              <h3 className="text-sm font-semibold">Semua Konten ({sorted.length})</h3>
              <button type="button" onClick={() => setShowAllModal(false)} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="divide-y divide-border">
              {sorted.map((entry) => (
                <SummaryRow key={entry.id} entry={entry} calendarId={calendarId} editable={editable} onUpdate={updateEntry} />
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function SummaryRow({
  entry,
  calendarId,
  editable,
  onUpdate,
}: {
  entry: ContentCalendarEntry;
  calendarId: string;
  editable: boolean;
  onUpdate: (entryId: string, patch: Partial<ContentCalendarEntry>) => void;
}) {
  const stage = getWorkflowStage(entry);
  const StageIcon = STAGE_ICON[stage];

  return (
    <div className="px-5 py-3.5">
      <div className="flex items-start gap-3">
        <span className="w-11 shrink-0 pt-0.5 text-[11px] font-semibold tabular-nums text-muted-foreground">
          {formatShortDate(entry.entry_date)}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <p className="text-sm font-medium">{entry.content_type}</p>
            {entry.function_tag && <p className="text-xs text-muted-foreground">{entry.function_tag}</p>}
          </div>
          <p className={`mt-0.5 flex items-center gap-1 text-xs font-medium ${STAGE_COLOR[stage]}`}>
            <StageIcon className="h-3 w-3" />
            {WORKFLOW_STAGE_LABELS[stage]}
          </p>

          {editable && entry.approval_status === "pending" && (
            <div className="mt-2">
              <ApprovalButtons
                entryId={entry.id}
                calendarId={calendarId}
                onDecided={(status, timestamp) => onUpdate(entry.id, { approval_status: status, approval_updated_at: timestamp })}
              />
            </div>
          )}

          {editable && entry.status === "published" && (
            <button
              type="button"
              onClick={async () => {
                const next = !entry.client_confirmed;
                onUpdate(entry.id, { client_confirmed: next });
                await setClientConfirmedAction(entry.id, next);
              }}
              className={`mt-2 flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                entry.client_confirmed
                  ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600"
                  : "border-border text-muted-foreground hover:border-foreground/30"
              }`}
            >
              {entry.client_confirmed ? <CheckSquare className="h-3.5 w-3.5" /> : <Square className="h-3.5 w-3.5" />}
              {entry.client_confirmed ? "Sudah saya cek" : "Tandai sudah saya cek"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
