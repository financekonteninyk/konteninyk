"use client";

import * as React from "react";
import { X, ExternalLink, Sparkles, MessageSquareText, Send, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ApprovalButtons } from "@/components/public/approval-buttons";
import { postEntryCommentAction } from "@/lib/actions/calendar";
import { APPROVAL_STATUS_LABELS } from "@/types/calendar";
import type { ContentCalendarEntry, CalendarEntryComment, ApprovalStatus } from "@/types/calendar";

interface CalendarDayDetailProps {
  isoDate: string;
  entries: ContentCalendarEntry[];
  commentsByEntry: Record<string, CalendarEntryComment[]>;
  calendarId: string;
  onClose: () => void;
}

const STATUS_LABELS: Record<string, string> = {
  planned: "Direncanakan",
  confirmed: "Terkonfirmasi",
  published: "Sudah Tayang",
  cancelled: "Dibatalkan",
};

const STATUS_BADGE: Record<string, string> = {
  planned: "bg-secondary text-muted-foreground",
  confirmed: "bg-primary/10 text-primary",
  published: "bg-emerald-500/10 text-emerald-600",
  cancelled: "bg-destructive/10 text-destructive",
};

const APPROVAL_BADGE: Record<ApprovalStatus, string> = {
  pending: "bg-secondary text-muted-foreground",
  approved: "bg-emerald-500/10 text-emerald-600",
  rejected: "bg-destructive/10 text-destructive",
};

export function CalendarDayDetail({ isoDate, entries, commentsByEntry, calendarId, onClose }: CalendarDayDetailProps) {
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-end bg-black/50 sm:items-stretch" onClick={onClose}>
      <div
        className="animate-in slide-in-from-bottom sm:slide-in-from-right h-[90vh] w-full overflow-y-auto rounded-t-2xl border-t border-border bg-card p-6 duration-300 sm:h-full sm:max-w-md sm:rounded-none sm:border-l sm:border-t-0 sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-lg font-semibold">
            {new Date(isoDate + "T00:00:00").toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
          </h3>
          <button type="button" onClick={onClose} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          {entries.map((entry) => (
            <EntryCard key={entry.id} entry={entry} comments={commentsByEntry[entry.id] ?? []} calendarId={calendarId} />
          ))}
        </div>
      </div>
    </div>
  );
}

function EntryCard({
  entry,
  comments,
  calendarId,
}: {
  entry: ContentCalendarEntry;
  comments: CalendarEntryComment[];
  calendarId: string;
}) {
  const [approval, setApproval] = React.useState<ApprovalStatus>(entry.approval_status);
  const [localComments, setLocalComments] = React.useState(comments);
  const [message, setMessage] = React.useState("");
  const [sending, setSending] = React.useState(false);

  async function handleSendComment() {
    const trimmed = message.trim();
    if (!trimmed) return;
    setSending(true);

    const formData = new FormData();
    formData.set("message", trimmed);
    const boundAction = postEntryCommentAction.bind(null, entry.id, calendarId, "client");
    await boundAction({}, formData);

    setLocalComments((prev) => [...prev, { id: `local-${Date.now()}`, entry_id: entry.id, author: "client", message: trimmed, created_at: new Date().toISOString() }]);
    setMessage("");
    setSending(false);
  }

  return (
    <div className="rounded-xl border border-border p-4">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <p className="font-semibold">{entry.content_type}</p>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${STATUS_BADGE[entry.status] ?? ""}`}>
          {STATUS_LABELS[entry.status] ?? entry.status}
        </span>
        {new Date(entry.updated_at).getTime() - new Date(entry.created_at).getTime() > 60_000 && (
          <span className="flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            <RefreshCw className="h-2.5 w-2.5" /> Diperbarui
          </span>
        )}
        {entry.function_tag && (
          <span
            className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
            style={{
              backgroundColor: entry.function_color ? `${entry.function_color}1A` : undefined,
              color: entry.function_color || undefined,
            }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: entry.function_color || undefined }} />
            {entry.function_tag}
          </span>
        )}
        {entry.source === "initiative" && (
          <span className="flex items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-violet-600">
            <Sparkles className="h-2.5 w-2.5" /> Inisiatif Kami
          </span>
        )}
        {entry.source === "client_request" && (
          <span className="flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-600">
            <MessageSquareText className="h-2.5 w-2.5" /> Request Kamu
          </span>
        )}
      </div>

      {entry.reference_image_url && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={entry.reference_image_url} alt="" className="mb-2 h-16 w-16 rounded-lg border border-border object-cover" />
      )}
      {entry.description && <p className="whitespace-pre-line text-sm text-muted-foreground">{entry.description}</p>}

      <div className="mt-2 flex flex-wrap gap-4">
        {entry.reference_url && (
          <a href={entry.reference_url} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
            Lihat referensi <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}
        {entry.drive_url && (
          <a href={entry.drive_url} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-sm font-medium text-emerald-600 hover:underline">
            Konten Jadi (Drive) <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}
      </div>

      {/* Approval */}
      <div className="mt-4 rounded-lg border border-border p-3">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Persetujuan Konten</p>
          <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${APPROVAL_BADGE[approval]}`}>
            {APPROVAL_STATUS_LABELS[approval]}
          </span>
        </div>
        {approval === "pending" ? (
          <ApprovalButtons
            entryId={entry.id}
            calendarId={calendarId}
            onDecided={(next) => setApproval(next)}
          />
        ) : (
          <p className="text-xs text-muted-foreground">
            {approval === "approved"
              ? "Konten ini sudah kamu setujui."
              : "Kamu sudah minta revisi — lihat komentar di bawah untuk detailnya."}
          </p>
        )}
      </div>

      {/* Comments */}
      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Komentar & Feedback</p>
        {localComments.length > 0 && (
          <div className="mb-2 space-y-2">
            {localComments.map((c) => (
              <div key={c.id} className={`rounded-lg p-2.5 text-sm ${c.author === "admin" ? "bg-primary/5" : "bg-secondary/50"}`}>
                <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  {c.author === "admin" ? "Kontenin.yk" : "Kamu"}
                </p>
                {c.message}
              </div>
            ))}
          </div>
        )}
        <div className="flex items-center gap-2">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Tulis feedback atau komentar..."
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleSendComment();
              }
            }}
          />
          <Button type="button" size="icon" disabled={sending} onClick={handleSendComment} aria-label="Kirim komentar">
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}
