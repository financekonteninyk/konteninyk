"use client";

import { motion, useReducedMotion } from "framer-motion";

interface RevealTextProps {
  text: string;
  className?: string;
  as?: "h1" | "h2" | "h3" | "p" | "span";
  delay?: number;
}

/**
 * Reveals text with a fade + blur as it scrolls into view.
 *
 * Note: this used to split text into individual word spans inside a flex
 * container for a staggered word-by-word effect. That caused a real,
 * repeated bug — flex layout doesn't wrap text the way normal inline flow
 * does, so words could render one-per-line ("kurang spacy"). This version
 * animates the text as a single block instead, using completely normal
 * text flow — zero risk of that bug, at the cost of the per-word stagger.
 * The semantic tag (h1/h2/p) is rendered plainly; a wrapping motion.div
 * carries the animation, which visually affects its child either way.
 */
export function RevealText({ text, className, as: Tag = "span", delay = 0 }: RevealTextProps) {
  const prefersReducedMotion = useReducedMotion();

  if (prefersReducedMotion) {
    return <Tag className={className}>{text}</Tag>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
    >
      <Tag className={className}>{text}</Tag>
    </motion.div>
  );
}
