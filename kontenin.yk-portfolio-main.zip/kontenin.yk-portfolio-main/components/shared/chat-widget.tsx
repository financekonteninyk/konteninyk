"use client";

import * as React from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { X, Send, ArrowUpRight, MessageCircle, Headset } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { t } from "@/lib/i18n/dictionary";
import { getChatReply, getIntroMessage, getSuggestedQuestions, getLanguageSwitchMessage, BOT_NAME } from "@/lib/i18n/chat-knowledge";
import { logUnmatchedQueryAction } from "@/lib/actions/chat";
import type { Locale } from "@/lib/i18n/locale";
import type { ChatQaEntry } from "@/types/chat";

interface ChatMessage {
  from: "bot" | "user";
  text: string;
  showWaButton?: boolean;
}

const TYPING_DELAY_MS = 700;

interface ChatWidgetProps {
  whatsappUrl: string | null;
  locale: Locale;
  botLogoUrl?: string | null;
  qaEntries?: ChatQaEntry[];
}

export function ChatWidget({ whatsappUrl, locale, botLogoUrl, qaEntries }: ChatWidgetProps) {
  const [open, setOpen] = React.useState(false);
  const [hasOpened, setHasOpened] = React.useState(false);
  const [showHint, setShowHint] = React.useState(false);
  const [input, setInput] = React.useState("");
  const [isTyping, setIsTyping] = React.useState(false);
  const [chatLocale, setChatLocale] = React.useState<Locale>(locale);
  const [messages, setMessages] = React.useState<ChatMessage[]>([
    { from: "bot" as const, text: getIntroMessage(locale), showWaButton: true },
  ]);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isTyping]);

  React.useEffect(() => {
    if (hasOpened) return;

    const showTimer = setInterval(() => setShowHint(true), 8000);
    const hideTimer = setInterval(() => setShowHint(false), 8000 + 4000);

    // Show the first hint a bit after the page settles, not instantly.
    const firstShow = setTimeout(() => setShowHint(true), 3000);
    const firstHide = setTimeout(() => setShowHint(false), 3000 + 4000);

    return () => {
      clearInterval(showTimer);
      clearInterval(hideTimer);
      clearTimeout(firstShow);
      clearTimeout(firstHide);
    };
  }, [hasOpened]);

  if (!whatsappUrl) return null;

  function handleSend(overrideText?: string) {
    const trimmed = (overrideText ?? input).trim();
    if (!trimmed) return;

    const reply = getChatReply(trimmed, chatLocale, qaEntries);

    if (!reply.matched) {
      // Fire-and-forget — don't block the chat UI on this.
      logUnmatchedQueryAction(trimmed, chatLocale);
    }

    setMessages((prev) => [...prev, { from: "user" as const, text: trimmed }]);
    setInput("");
    setIsTyping(true);

    // Small delay before the reply appears — makes it feel like a real
    // conversation instead of an instant lookup.
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        { from: "bot" as const, text: reply.text, showWaButton: reply.showWaButton },
      ]);
    }, TYPING_DELAY_MS);
  }

  function handleSwitchLanguage(target: Locale) {
    if (target === chatLocale) return;
    setChatLocale(target);
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [...prev, { from: "bot" as const, text: getLanguageSwitchMessage(target), showWaButton: false }]);
    }, TYPING_DELAY_MS);
  }

  return (
    // Pushed higher on mobile (bottom-24) so it clears the fixed bottom
    // nav bar; back to its normal spot on desktop (md:bottom-5), where
    // there's no bottom bar to collide with.
    <div className="fixed bottom-24 right-5 z-50 md:bottom-5">
      {open && (
        <div className="glass mb-3 flex h-[80vh] max-h-[680px] w-[94vw] max-w-[400px] flex-col overflow-hidden rounded-2xl border border-border shadow-2xl sm:w-[440px] sm:max-w-[440px]">
          <div className="flex items-center justify-between border-b border-border bg-background/80 px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded-full bg-primary text-primary-foreground">
                {botLogoUrl ? (
                  <Image src={botLogoUrl} alt={BOT_NAME} fill sizes="28px" className="object-cover" />
                ) : (
                  <Headset className="h-3.5 w-3.5" />
                )}
              </span>
              <div>
                <p className="text-sm font-semibold leading-none">{BOT_NAME}</p>
                <p className="text-[10px] text-muted-foreground">Kontenin.yk Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-0.5 rounded-full border border-border bg-secondary/40 p-0.5">
                <button
                  type="button"
                  onClick={() => handleSwitchLanguage("id")}
                  aria-label="Switch to Indonesian"
                  className={
                    chatLocale === "id"
                      ? "rounded-full bg-primary px-2 py-1 text-[10px] font-semibold text-primary-foreground"
                      : "rounded-full px-2 py-1 text-[10px] font-medium text-muted-foreground hover:text-foreground"
                  }
                >
                  ID
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchLanguage("en")}
                  aria-label="Switch to English"
                  className={
                    chatLocale === "en"
                      ? "rounded-full bg-primary px-2 py-1 text-[10px] font-semibold text-primary-foreground"
                      : "rounded-full px-2 py-1 text-[10px] font-medium text-muted-foreground hover:text-foreground"
                  }
                >
                  EN
                </button>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close chat"
                className="text-muted-foreground transition-colors hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
            {messages.map((msg, i) => (
              <div key={i} className={msg.from === "user" ? "flex justify-end" : "flex justify-start"}>
                <div
                  className={
                    msg.from === "user"
                      ? "max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-3.5 py-2 text-sm text-primary-foreground"
                      : "max-w-[85%] whitespace-pre-line rounded-2xl rounded-bl-sm bg-secondary px-3.5 py-2 text-sm"
                  }
                >
                  <p>{msg.text}</p>
                  {msg.showWaButton && (
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="mt-2.5 flex animate-pulse items-center justify-center gap-1.5 rounded-xl bg-[#25D366] px-3.5 py-2.5 text-sm font-semibold text-white shadow-md transition-transform hover:scale-[1.03] hover:animate-none"
                    >
                      <MessageCircle className="h-4 w-4 shrink-0" fill="currentColor" strokeWidth={0} />
                      {t(chatLocale, "chat_wa_button")}
                      <ArrowUpRight className="h-3.5 w-3.5 shrink-0" />
                    </a>
                  )}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm bg-secondary px-4 py-3">
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.3s]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.15s]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground" />
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-nowrap gap-1.5 overflow-x-auto border-t border-border px-3 pb-2 pt-2.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {getSuggestedQuestions(chatLocale).map((question) => (
              <button
                key={question}
                type="button"
                onClick={() => handleSend(question)}
                className="shrink-0 rounded-full border border-border bg-background px-3 py-1.5 text-xs font-medium transition-colors hover:bg-secondary"
              >
                {question}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 border-t border-border p-3">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t(chatLocale, "chat_placeholder")}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  handleSend();
                }
              }}
              className="h-9"
            />
            <Button type="button" size="icon" className="h-9 w-9 shrink-0" onClick={() => handleSend()} aria-label={t(chatLocale, "chat_send")}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Floating hint — points at the chat bubble to draw attention before
          the visitor has ever opened it. Stops permanently once opened. */}
      <AnimatePresence>
        {!open && !hasOpened && showHint && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="glass absolute bottom-[72px] right-0 flex items-center gap-2 whitespace-nowrap rounded-full border border-border px-4 py-2.5 text-sm font-medium shadow-xl"
          >
            <span className="flex h-2 w-2 shrink-0 animate-pulse rounded-full bg-emerald-500" />
            {chatLocale === "id" ? "Ada yang bisa dibantu? 👋" : "Need any help? 👋"}
            {/* Little pointer connecting the bubble down to the button */}
            <span
              aria-hidden
              className="absolute -bottom-1.5 right-6 h-3 w-3 rotate-45 border-b border-r border-border bg-background"
            />
          </motion.div>
        )}
      </AnimatePresence>

      <button
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setHasOpened(true);
          setShowHint(false);
        }}
        aria-label={open ? "Close chat" : "Open chat"}
        className="relative flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-primary to-[hsl(231,70%,52%)] text-primary-foreground shadow-2xl shadow-primary/30 transition-transform hover:scale-105"
      >
        {open ? (
          <X className="h-5 w-5" />
        ) : botLogoUrl ? (
          <Image src={botLogoUrl} alt={BOT_NAME} fill sizes="56px" className="object-cover" />
        ) : (
          <Headset className="h-6 w-6" />
        )}
      </button>
    </div>
  );
}
