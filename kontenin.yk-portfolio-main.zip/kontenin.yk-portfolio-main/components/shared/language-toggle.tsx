"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { setLocaleAction } from "@/lib/actions/locale";
import { cn } from "@/lib/utils";
import type { Locale } from "@/lib/i18n/locale";

export function LanguageToggle({ locale }: { locale: Locale }) {
  const router = useRouter();
  const [isPending, startTransition] = React.useTransition();

  function handleSwitch(next: Locale) {
    if (next === locale || isPending) return;
    startTransition(async () => {
      await setLocaleAction(next);
      router.refresh();
    });
  }

  return (
    <div className="flex items-center overflow-hidden rounded-full border border-border text-xs font-medium">
      <button
        type="button"
        onClick={() => handleSwitch("id")}
        aria-pressed={locale === "id"}
        className={cn(
          "px-2.5 py-1.5 transition-colors",
          locale === "id" ? "bg-foreground text-background" : "text-muted-foreground hover:text-foreground"
        )}
      >
        ID
      </button>
      <button
        type="button"
        onClick={() => handleSwitch("en")}
        aria-pressed={locale === "en"}
        className={cn(
          "px-2.5 py-1.5 transition-colors",
          locale === "en" ? "bg-foreground text-background" : "text-muted-foreground hover:text-foreground"
        )}
      >
        EN
      </button>
    </div>
  );
}
