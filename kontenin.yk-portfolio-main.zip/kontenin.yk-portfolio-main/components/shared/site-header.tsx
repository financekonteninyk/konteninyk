"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { MessageCircle, Home, LayoutGrid, RefreshCw, Sparkles, User } from "lucide-react";
import { Logo } from "@/components/shared/logo";
import { ThemeToggle } from "@/components/shared/theme-toggle";
import { LanguageToggle } from "@/components/shared/language-toggle";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/shared/magnetic";
import { pickText, type Locale } from "@/lib/i18n/locale";
import type { SiteSettings } from "@/types/settings";

interface SiteHeaderProps {
  settings: SiteSettings;
  locale: Locale;
}

// Section ids tracked for the mobile bottom nav's scroll-spy indicator —
// must match the anchor hrefs below (minus the "/#").
const OBSERVED_SECTION_IDS = ["portfolio", "process", "services"];

export function SiteHeader({ settings, locale }: SiteHeaderProps) {
  const pathname = usePathname();
  const [activeSection, setActiveSection] = React.useState<string | null>(null);

  const navLinks = [
    { href: "/#portfolio", label: pickText(locale, settings.nav_portfolio_id, settings.nav_portfolio_en, "Portfolio") },
    { href: "/#process", label: pickText(locale, settings.nav_process_id, settings.nav_process_en, "How We Work") },
    { href: "/#services", label: pickText(locale, settings.nav_services_id, settings.nav_services_en, "Services") },
    { href: "/about", label: pickText(locale, settings.nav_about_id, settings.nav_about_en, "About") },
  ];

  const bottomNavItems = [
    { href: "/", label: locale === "id" ? "Beranda" : "Home", icon: Home, sectionId: null as string | null },
    { href: "/#portfolio", label: pickText(locale, settings.nav_portfolio_id, settings.nav_portfolio_en, "Portfolio"), icon: LayoutGrid, sectionId: "portfolio" as string | null },
    { href: "/#process", label: pickText(locale, settings.nav_process_id, settings.nav_process_en, "Proses"), icon: RefreshCw, sectionId: "process" as string | null },
    { href: "/#services", label: pickText(locale, settings.nav_services_id, settings.nav_services_en, "Layanan"), icon: Sparkles, sectionId: "services" as string | null },
    { href: "/about", label: pickText(locale, settings.nav_about_id, settings.nav_about_en, "Tentang"), icon: User, sectionId: null as string | null },
  ];

  // Scroll-spy: watch each homepage section and track whichever one is
  // most visible right now, so the bottom nav can show a real "you are
  // here" indicator instead of never lighting up for anchor links.
  React.useEffect(() => {
    if (pathname !== "/") {
      setActiveSection(null);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActiveSection(visible.target.id);
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0, 0.25, 0.5, 0.75, 1] }
    );

    const elements = OBSERVED_SECTION_IDS.map((id) => document.getElementById(id)).filter(
      (el): el is HTMLElement => el !== null
    );
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, [pathname]);

  const isActive = (item: { href: string; sectionId: string | null }) => {
    if (item.href === "/") return pathname === "/" && !activeSection;
    if (item.sectionId) return pathname === "/" && activeSection === item.sectionId;
    return pathname === item.href;
  };

  // Clicking a bottom-nav item updates the highlight immediately, instead
  // of waiting for the scroll to finish and the IntersectionObserver to
  // catch up — that round-trip is what made it feel laggy. Home is a
  // special case: since its href ("/") doesn't change when you're already
  // on the homepage, Next.js won't scroll or re-render on its own, so we
  // scroll to top by hand — that's what caused the "stuck" highlight.
  function handleBottomNavClick(item: { href: string; sectionId: string | null }) {
    setActiveSection(item.sectionId);
    if (item.href === "/" && pathname === "/") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  return (
    <>
      <header className="glass sticky top-0 z-40 border-b border-border">
        <div className="container flex h-16 items-center justify-between">
          <Logo logoUrl={settings.site_logo_url} />

          <nav className="hidden items-center gap-8 text-sm font-medium text-muted-foreground md:flex">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className="transition-colors hover:text-foreground">
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 sm:gap-2">
              <LanguageToggle locale={locale} />
              <ThemeToggle />
            </div>
            {settings.whatsapp_url && (
              <Magnetic>
                <Button asChild size="sm" variant="gradient" className="cta-attention rounded-full">
                  <Link href={settings.whatsapp_url} target="_blank" rel="noreferrer noopener">
                    <MessageCircle className="h-4 w-4" />
                    <span className="hidden sm:inline">
                      {pickText(locale, settings.nav_cta_id, settings.nav_cta_en, "Konsultasi Gratis")}
                    </span>
                  </Link>
                </Button>
              </Magnetic>
            )}
          </div>
        </div>
      </header>

      {/* Mobile bottom navigation — persistent liquid-glass bar with a real
          scroll-spy "you are here" indicator. */}
      <nav
        className="glass fixed inset-x-3 bottom-3 z-40 flex items-center justify-around rounded-full border border-border/60 px-1 py-1.5 shadow-2xl md:hidden"
        style={{ backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)" }}
      >
        {bottomNavItems.map((item) => {
          const active = isActive(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => handleBottomNavClick(item)}
              className={`flex flex-1 flex-col items-center gap-0.5 rounded-full py-2 text-[10px] font-medium transition-colors ${
                active ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              <span
                className={`flex h-8 w-8 items-center justify-center rounded-full transition-colors ${
                  active ? "bg-primary text-primary-foreground" : ""
                }`}
              >
                <item.icon className="h-4 w-4" />
              </span>
              {item.label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
