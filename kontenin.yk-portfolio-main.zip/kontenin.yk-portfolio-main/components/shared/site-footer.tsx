import Link from "next/link";
import { Instagram, Youtube, Music2, ArrowUpRight } from "lucide-react";
import { SITE_NAME } from "@/lib/constants";
import { pickText, type Locale } from "@/lib/i18n/locale";
import { t } from "@/lib/i18n/dictionary";
import type { SiteSettings } from "@/types/settings";

interface SiteFooterProps {
  tagline: string;
  locale: Locale;
  settings: SiteSettings;
}

export function SiteFooter({ tagline, locale, settings }: SiteFooterProps) {
  return (
    <footer className="border-t border-border">
      <div className="container py-16 md:py-24">
        <Link
          href="/#hero"
          data-cursor-pointer
          className="group flex flex-wrap items-center gap-3 break-words text-3xl font-bold tracking-tight transition-opacity hover:opacity-70 sm:text-5xl md:gap-4 md:text-8xl"
        >
          {SITE_NAME}
          <ArrowUpRight className="h-6 w-6 shrink-0 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1 sm:h-8 sm:w-8 md:h-16 md:w-16" />
        </Link>
        <p className="mt-4 max-w-md text-muted-foreground">{tagline}</p>
      </div>

      <div className="container flex flex-col gap-8 border-t border-border py-10 md:flex-row md:items-center md:justify-between">
        <nav className="flex flex-wrap gap-x-8 gap-y-3 text-sm">
          <Link href="/#hero" className="text-muted-foreground transition-colors hover:text-foreground">
            {t(locale, "home")}
          </Link>
          <Link href="/#portfolio" className="text-muted-foreground transition-colors hover:text-foreground">
            {pickText(locale, settings.nav_portfolio_id, settings.nav_portfolio_en, "Portfolio")}
          </Link>
          <Link href="/#process" className="text-muted-foreground transition-colors hover:text-foreground">
            {pickText(locale, settings.nav_process_id, settings.nav_process_en, "How We Work")}
          </Link>
          <Link href="/#services" className="text-muted-foreground transition-colors hover:text-foreground">
            {pickText(locale, settings.nav_services_id, settings.nav_services_en, "Services")}
          </Link>
          <Link href="/about" className="text-muted-foreground transition-colors hover:text-foreground">
            {pickText(locale, settings.nav_about_id, settings.nav_about_en, "About")}
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer noopener"
            aria-label="Instagram"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-foreground hover:text-foreground"
          >
            <Instagram className="h-4 w-4" />
          </a>
          <a
            href="https://tiktok.com"
            target="_blank"
            rel="noreferrer noopener"
            aria-label="TikTok"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-foreground hover:text-foreground"
          >
            <Music2 className="h-4 w-4" />
          </a>
          <a
            href="https://youtube.com"
            target="_blank"
            rel="noreferrer noopener"
            aria-label="YouTube"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-foreground hover:text-foreground"
          >
            <Youtube className="h-4 w-4" />
          </a>
        </div>
      </div>

      <div className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} {SITE_NAME}. All rights reserved.
      </div>
    </footer>
  );
}
