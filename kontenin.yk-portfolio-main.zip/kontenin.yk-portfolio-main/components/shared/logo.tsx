import Link from "next/link";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { SITE_NAME } from "@/lib/constants";
import { SiteLogoImage } from "@/components/shared/site-logo-image";

interface LogoProps {
  className?: string;
  href?: string;
  logoUrl?: string | null;
}

export function Logo({ className, href = "/", logoUrl }: LogoProps) {
  return (
    <Link
      href={href}
      className={cn(
        "inline-flex items-center gap-2 text-lg font-semibold tracking-tight",
        className
      )}
    >
      {logoUrl ? (
        <SiteLogoImage url={logoUrl} className="h-8 w-8" sizes="32px" />
      ) : (
        <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Sparkles className="h-4 w-4" />
        </span>
      )}
      {SITE_NAME}
    </Link>
  );
}
