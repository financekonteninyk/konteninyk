import Image from "next/image";
import { cn } from "@/lib/utils";
import { SITE_NAME } from "@/lib/constants";

interface SiteLogoImageProps {
  url: string;
  className?: string;
  sizes?: string;
  /** Explicit pixel dimensions (used by the admin-configurable Hero logo). Overrides className sizing. */
  width?: number;
  height?: number;
  /**
   * Whether to apply the automatic dark-mode invert filter. Defaults to
   * true — right for the Kontenin.yk mark, which is a solid black-or-white
   * image that would disappear against a matching background without it.
   * Set to false for logos with real color/photographic content (e.g. the
   * Hero's glass render) — inverting those turns them into a color-negative
   * mess instead of adapting them to the theme.
   */
  invert?: boolean;
}

/**
 * Renders the uploaded site logo with an optional automatic dark-mode
 * invert filter (see `invert` prop above for when to turn it off).
 *
 * By default sizing comes from `className` (e.g. "h-8 w-8" for the small
 * nav logo). Pass explicit `width`/`height` in pixels to size it manually
 * instead — used for the admin-configurable Hero logo.
 */
export function SiteLogoImage({ url, className, sizes = "200px", width, height, invert = true }: SiteLogoImageProps) {
  const hasExplicitSize = width != null && height != null;
  return (
    <span
      className={cn("relative block", invert && "dark:invert", !hasExplicitSize && className)}
      style={hasExplicitSize ? { width, height } : undefined}
    >
      <Image src={url} alt={SITE_NAME} fill sizes={sizes} className="object-contain" />
    </span>
  );
}
