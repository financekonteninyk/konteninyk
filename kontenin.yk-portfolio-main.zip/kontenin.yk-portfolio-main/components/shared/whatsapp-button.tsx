import Link from "next/link";
import Image from "next/image";

interface WhatsAppButtonProps {
  whatsappUrl: string | null;
  iconUrl?: string | null;
}

/** No fallback icon — an empty logo slot stays transparent until you upload one. */
export function WhatsAppButton({ whatsappUrl, iconUrl }: WhatsAppButtonProps) {
  if (!whatsappUrl) return null;

  return (
    <Link
      href={whatsappUrl}
      target="_blank"
      rel="noreferrer noopener"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-24 right-5 z-50 flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-[#25D366] text-white shadow-2xl transition-transform hover:scale-105"
    >
      {iconUrl && <Image src={iconUrl} alt="WhatsApp" fill sizes="56px" className="object-cover" />}
    </Link>
  );
}
