import Image from "next/image";
import type { ActivityPhoto } from "@/types/activity";

export function ActivityPhotosCarousel({ photos }: { photos: ActivityPhoto[] }) {
  if (photos.length === 0) return null;

  // Duplicate the list so the marquee loops seamlessly.
  const marqueePhotos = [...photos, ...photos];

  return (
    <div className="group relative flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_5%,black_95%,transparent)]">
      <div className="flex shrink-0 animate-[marquee_40s_linear_infinite] items-center gap-4 pr-4 group-hover:[animation-play-state:paused]">
        {marqueePhotos.map((photo, i) => (
          <div
            key={`${photo.id}-${i}`}
            className="relative aspect-video w-48 shrink-0 overflow-hidden rounded-xl border border-border bg-muted sm:w-64"
          >
            <Image src={photo.image_url} alt={photo.caption ?? ""} fill sizes="256px" className="object-cover" />
            {photo.caption && (
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-2.5">
                <p className="truncate text-xs font-medium text-white">{photo.caption}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
