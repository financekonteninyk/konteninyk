import { ClientCard } from "@/components/portfolio/client-card";
import { EmptyState } from "@/components/shared/empty-state";
import type { Client } from "@/types/client";

export function ClientGrid({ clients }: { clients: Client[] }) {
  if (clients.length === 0) {
    return <EmptyState title="No clients yet" description="Published work will show up here soon." />;
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
      {clients.map((client, i) => (
        <ClientCard key={client.id} client={client} index={i} />
      ))}
    </div>
  );
}
