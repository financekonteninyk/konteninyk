"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ImageOff, ArrowUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Client } from "@/types/client";

export function ClientCard({ client, index = 0 }: { client: Client; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: (index % 6) * 0.05 }}
      className="h-full"
    >
      <Link
        href={`/client/${client.id}`}
        data-cursor-pointer
        className="group relative flex h-full aspect-[16/9] flex-col overflow-hidden rounded-2xl border border-border bg-muted transition-all duration-300 ease-out hover:-translate-y-1.5 hover:shadow-2xl sm:aspect-[4/3]"
      >
        {client.cover_thumbnail_url ? (
          <Image
            src={client.cover_thumbnail_url}
            alt={client.name}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <ImageOff className="h-8 w-8" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent transition-opacity duration-300" />

        <span className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white opacity-70 backdrop-blur-sm transition-all duration-300 group-hover:opacity-100 group-hover:bg-white group-hover:text-black sm:right-4 sm:top-4 sm:h-10 sm:w-10 md:opacity-0">
          <ArrowUpRight className="h-4 w-4" />
        </span>

        <div className="relative mt-auto space-y-2 p-4 sm:space-y-3 sm:p-6">
          <Badge className="bg-white/15 text-xs text-white backdrop-blur-sm">{client.category}</Badge>
          <h3 className="text-lg font-semibold tracking-tight text-white sm:text-2xl">{client.name}</h3>
        </div>
      </Link>
    </motion.div>
  );
}
