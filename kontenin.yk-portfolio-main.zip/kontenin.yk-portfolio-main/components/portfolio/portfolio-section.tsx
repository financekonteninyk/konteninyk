import { getPublishedClients } from "@/lib/data/clients";
import { ClientGrid } from "@/components/portfolio/client-grid";
import { Pagination } from "@/components/shared/pagination";
import { ActivityPhotosCarousel } from "@/components/shared/activity-photos-carousel";
import { getActivityPhotos } from "@/lib/data/activity";
import { getLocale } from "@/lib/i18n/get-locale";
import { t } from "@/lib/i18n/dictionary";
import { CLIENTS_PER_PAGE } from "@/lib/constants";

interface PortfolioSectionProps {
  searchParams: Promise<{
    page?: string;
  }>;
}

export async function PortfolioSection({ searchParams }: PortfolioSectionProps) {
  const resolvedSearchParams = await searchParams;
  const page = Math.max(1, Number(resolvedSearchParams.page ?? "1") || 1);

  const [{ clients, total }, activityPhotos, locale] = await Promise.all([
    getPublishedClients({ page, perPage: CLIENTS_PER_PAGE }),
    getActivityPhotos(),
    getLocale(),
  ]);
  const totalPages = Math.max(1, Math.ceil(total / CLIENTS_PER_PAGE));

  return (
    // id changed from "portfolio" to "partners" — the content gallery
    // above is now "Portfolio"; this client grid is reframed as a trust/
    // collaboration showcase instead, so it isn't duplicating that label.
    <section id="partners" className="scroll-mt-20 py-20 md:py-28">
      <div className="container">
        <div className="mb-12 max-w-2xl">
          <span className="eyebrow text-xs text-muted-foreground">{t(locale, "partners_eyebrow")}</span>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">
            {t(locale, "partners_heading")}
          </h2>
          <p className="mt-3 text-muted-foreground">{t(locale, "partners_subheading")}</p>
        </div>

        <ClientGrid clients={clients} />

        <Pagination currentPage={page} totalPages={totalPages} anchor="partners" />

        {activityPhotos.length > 0 && (
          <div className="mt-20">
            <p className="eyebrow mb-4 text-xs text-muted-foreground">{t(locale, "activity_photos_label")}</p>
            <ActivityPhotosCarousel photos={activityPhotos} />
          </div>
        )}
      </div>
    </section>
  );
}
