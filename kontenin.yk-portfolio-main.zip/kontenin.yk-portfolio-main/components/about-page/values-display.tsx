"use client";

import { motion } from "framer-motion";
import type { Value } from "@/types/about";

export function ValuesDisplay({ items }: { items: Value[] }) {
  if (items.length === 0) return null;

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">What We Believe</span>
        <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Values</h2>

        <div className="mt-14 grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="border-t border-border pt-5"
            >
              <span className="eyebrow text-xs text-muted-foreground">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="mt-2 text-lg font-semibold tracking-tight">{item.title}</h3>
              {item.description && (
                <p className="mt-2 text-sm text-muted-foreground">{item.description}</p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
