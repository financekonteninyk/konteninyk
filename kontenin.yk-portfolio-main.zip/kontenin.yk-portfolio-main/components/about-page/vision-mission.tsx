"use client";

import { motion } from "framer-motion";
import { Eye, Target } from "lucide-react";

interface VisionMissionProps {
  vision: string | null;
  mission: string | null;
}

export function VisionMission({ vision, mission }: VisionMissionProps) {
  if (!vision && !mission) return null;

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container grid grid-cols-1 gap-10 md:grid-cols-2">
        {vision && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5 }}
          >
            <Eye className="h-6 w-6 text-muted-foreground" />
            <h2 className="mt-4 text-2xl font-semibold tracking-tight">Vision</h2>
            <p className="mt-3 whitespace-pre-line leading-relaxed text-muted-foreground">{vision}</p>
          </motion.div>
        )}
        {mission && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Target className="h-6 w-6 text-muted-foreground" />
            <h2 className="mt-4 text-2xl font-semibold tracking-tight">Mission</h2>
            <p className="mt-3 whitespace-pre-line leading-relaxed text-muted-foreground">{mission}</p>
          </motion.div>
        )}
      </div>
    </section>
  );
}
