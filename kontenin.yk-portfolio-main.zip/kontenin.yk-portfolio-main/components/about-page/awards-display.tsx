"use client";

import { motion } from "framer-motion";
import { Award as AwardIcon } from "lucide-react";
import type { Award } from "@/types/about";

export function AwardsDisplay({ items }: { items: Award[] }) {
  if (items.length === 0) return null;

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">Recognition</span>
        <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Awards</h2>

        <div className="mt-14 divide-y divide-border border-t border-border">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="flex items-center gap-4 py-5"
            >
              <AwardIcon className="h-5 w-5 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold">{item.title}</h3>
                {(item.issuer || item.year) && (
                  <p className="text-sm text-muted-foreground">
                    {[item.issuer, item.year].filter(Boolean).join(" · ")}
                  </p>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
