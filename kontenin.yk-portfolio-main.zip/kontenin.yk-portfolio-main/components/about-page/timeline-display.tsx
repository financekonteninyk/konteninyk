"use client";

import { motion } from "framer-motion";
import type { TimelineItem } from "@/types/about";

export function TimelineDisplay({ items }: { items: TimelineItem[] }) {
  if (items.length === 0) return null;

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">Our Journey</span>
        <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Timeline</h2>

        <div className="relative mt-14 space-y-10 border-l border-border pl-8 md:pl-12">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -12 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="relative"
            >
              <span
                aria-hidden
                className="absolute -left-[calc(2rem+5px)] top-1.5 h-2.5 w-2.5 rounded-full bg-foreground md:-left-[calc(3rem+5px)]"
              />
              <span className="eyebrow text-xs text-muted-foreground">{item.year}</span>
              <h3 className="mt-1 text-xl font-semibold tracking-tight md:text-2xl">{item.title}</h3>
              {item.description && (
                <p className="mt-2 max-w-2xl text-muted-foreground">{item.description}</p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
