import Image from "next/image";
import type { Tool } from "@/types/about";

export function ToolsDisplay({ items }: { items: Tool[] }) {
  if (items.length === 0) return null;

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">Our Toolkit</span>
        <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Tools</h2>

        <div className="mt-10 flex flex-wrap gap-3">
          {items.map((tool) => (
            <div
              key={tool.id}
              className="flex items-center gap-2.5 rounded-full border border-border px-4 py-2"
            >
              {tool.logo_url ? (
                <span className="relative h-6 w-6 shrink-0 overflow-hidden rounded-full bg-muted">
                  <Image src={tool.logo_url} alt={tool.name} fill sizes="24px" className="object-cover" />
                </span>
              ) : (
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-semibold">
                  {tool.name.slice(0, 2).toUpperCase()}
                </span>
              )}
              <span className="text-sm font-medium">{tool.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
