"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import type { GalleryImage } from "@/types/about";

export function GalleryDisplay({ items }: { items: GalleryImage[] }) {
  if (items.length === 0) return null;

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">Behind The Scenes</span>
        <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Gallery</h2>

        <div className="mt-14 grid grid-cols-2 gap-4 md:grid-cols-3">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="group relative aspect-video overflow-hidden rounded-2xl border border-border bg-muted"
            >
              <Image
                src={item.image_url}
                alt={item.caption ?? ""}
                fill
                sizes="(max-width: 768px) 50vw, 33vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {item.caption && (
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                  <p className="text-xs text-white">{item.caption}</p>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
