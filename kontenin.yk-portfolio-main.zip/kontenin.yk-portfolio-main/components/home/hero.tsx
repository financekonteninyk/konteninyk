"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/shared/magnetic";
import { SiteLogoImage } from "@/components/shared/site-logo-image";
import { FloatingCards } from "@/components/home/floating-cards";
import { ActivityPhotosCarousel } from "@/components/shared/activity-photos-carousel";
import { pickText, type Locale } from "@/lib/i18n/locale";
import { t } from "@/lib/i18n/dictionary";
import type { SiteSettings } from "@/types/settings";
import type { VideoWithClient } from "@/types/video";
import type { ActivityPhoto } from "@/types/activity";

interface HeroProps {
  settings: SiteSettings;
  previewVideos: VideoWithClient[];
  locale: Locale;
  activityPhotos: ActivityPhoto[];
}

export function Hero({ settings, previewVideos, locale, activityPhotos }: HeroProps) {
  // Falls back to the header logo if a dedicated Hero logo hasn't been set.
  const heroLogoUrl = settings.hero_logo_url ?? settings.site_logo_url;

  const badgeText = pickText(locale, settings.hero_badge_text_id, settings.hero_badge_text_en, settings.hero_badge_text);
  const heading = pickText(locale, settings.hero_heading_id, settings.hero_heading_en, settings.hero_heading);
  const description = pickText(
    locale,
    settings.hero_description_id,
    settings.hero_description_en,
    settings.hero_description
  );

  return (
    <section
      id="hero"
      className="relative overflow-hidden"
    >
      {/* Dynamic gradient — subtle, theme-aware (uses --foreground/--primary tokens so it auto-adapts to light/dark), always slowly drifting */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -left-1/4 -top-1/4 -z-10 h-[70vh] w-[70vh] rounded-full bg-[radial-gradient(circle,hsl(var(--primary)/0.16),transparent_70%)] blur-3xl"
        animate={{ x: [0, 60, 0], y: [0, 40, 0], scale: [1, 1.15, 1] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -right-1/4 top-0 -z-10 h-[60vh] w-[60vh] rounded-full bg-[radial-gradient(circle,hsl(var(--foreground)/0.1),transparent_70%)] blur-3xl"
        animate={{ x: [0, -50, 0], y: [0, 50, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-transparent to-background"
      />

      <div className="container grid min-h-[90vh] grid-cols-1 items-center gap-12 py-20 sm:py-24 lg:grid-cols-2 lg:gap-16">
        <div className="order-2 lg:order-1">
          {heroLogoUrl && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <SiteLogoImage
                url={heroLogoUrl}
                width={settings.hero_logo_width}
                height={settings.hero_logo_height}
                sizes={`${settings.hero_logo_width}px`}
                invert={false}
              />
            </motion.div>
          )}

          <motion.span
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="eyebrow mb-6 block text-xs text-muted-foreground"
          >
            {badgeText}
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
            className="text-balance break-words text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl md:text-6xl lg:text-7xl lg:leading-[1.05]"
          >
            {heading}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35 }}
            className="mt-6 max-w-md text-balance text-base text-muted-foreground sm:text-lg"
          >
            {description}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="mt-10 flex flex-wrap items-center gap-3"
          >
            <Magnetic>
              <Button asChild size="lg" variant="gradient" className="rounded-full">
                <Link href="#portfolio">
                  {t(locale, "view_portfolio")}
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </Magnetic>
            {settings.whatsapp_url && (
              <Magnetic>
                <Button asChild size="lg" variant="outline" className="cta-attention rounded-full">
                  <Link href={settings.whatsapp_url} target="_blank" rel="noreferrer noopener">
                    <MessageCircle className="h-4 w-4" />
                    {t(locale, "start_consultation")}
                  </Link>
                </Button>
              </Magnetic>
            )}
          </motion.div>
        </div>

        <div className="hidden md:block lg:order-2">
          <FloatingCards videos={previewVideos} />
        </div>
      </div>

      {activityPhotos.length > 0 && (
        <div className="container pb-16">
          <p className="eyebrow mb-4 text-xs text-muted-foreground">{t(locale, "activity_photos_label")}</p>
          <ActivityPhotosCarousel photos={activityPhotos} />
        </div>
      )}
    </section>
  );
}
