import { RevealText } from "@/components/shared/reveal-text";
import { ActivityPhotosCarousel } from "@/components/shared/activity-photos-carousel";
import { ServicePackages } from "@/components/home/service-packages";
import { getPublishedPricingCategories } from "@/lib/data/pricing";
import { getActivityPhotos } from "@/lib/data/activity";
import { getSiteSettings } from "@/lib/data/settings";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

export async function ServicesSection({ locale }: { locale: Locale }) {
  const [categories, activityPhotos, settings] = await Promise.all([
    getPublishedPricingCategories(),
    getActivityPhotos(),
    getSiteSettings(),
  ]);

  if (categories.length === 0 && activityPhotos.length === 0) return null;

  return (
    <section
      id="services"
      className="scroll-mt-20 border-t border-border py-20 md:py-28"
    >
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">
          {t(locale, "what_we_do")}
        </span>

        <RevealText
          as="h2"
          text={locale === "id" ? "Layanan Kami" : "Our Services"}
          className="text-4xl font-bold tracking-tight md:text-6xl"
        />

        <p className="mt-6 max-w-2xl text-balance text-muted-foreground">
          {t(locale, "services_desc")}
        </p>

        {categories.length > 0 && (
          <ServicePackages categories={categories} locale={locale} whatsappUrl={settings.whatsapp_url} />
        )}

        {activityPhotos.length > 0 && (
          <div className="mt-20">
            <p className="eyebrow mb-4 text-xs text-muted-foreground">
              {t(locale, "activity_photos_label")}
            </p>

            <ActivityPhotosCarousel photos={activityPhotos} />
          </div>
        )}
      </div>
    </section>
  );
}
