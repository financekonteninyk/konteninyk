import Image from "next/image";
import Link from "next/link";
import { Layers } from "lucide-react";
import type { VideoWithClient } from "@/types/video";

export function FeaturedWorkGallery({ videos }: { videos: VideoWithClient[] }) {
  const featured = videos.slice(0, 6);

  if (featured.length === 0) return null;

  return (
    <div className="grid grid-cols-3 gap-2.5">
      {featured.map((video) => (
        <Link
          key={video.id}
          href={`/client/${video.client_id}`}
          className="relative aspect-[9/16] overflow-hidden rounded-xl border border-border bg-muted"
        >
          <Image src={video.thumbnail_url} alt="" fill sizes="120px" className="object-cover" />
          {video.content_type === "carousel" && (
            <span className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 text-white">
              <Layers className="h-2.5 w-2.5" />
            </span>
          )}
        </Link>
      ))}
    </div>
  );
}
