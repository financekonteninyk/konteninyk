import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/shared/magnetic";
import { RevealText } from "@/components/shared/reveal-text";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

interface CtaSectionProps {
  tagline: string;
  locale: Locale;
  whatsappUrl: string | null;
}

export function CtaSection({ tagline, locale, whatsappUrl }: CtaSectionProps) {
  return (
    <section className="border-t border-border py-24 md:py-32">
      <div className="container flex flex-col items-center text-center">
        <span className="eyebrow mb-6 text-xs text-muted-foreground">{t(locale, "lets_talk")}</span>
        <RevealText
          as="h2"
          text={tagline}
          className="justify-center text-balance text-2xl font-bold tracking-tight sm:text-4xl md:text-7xl"
        />
        {whatsappUrl ? (
          <>
            <Magnetic className="mt-10">
              <Button asChild size="lg" variant="gradient" className="cta-attention rounded-full">
                <Link href={whatsappUrl} target="_blank" rel="noreferrer noopener">
                  <MessageCircle className="h-4 w-4" />
                  {t(locale, "start_consultation")}
                </Link>
              </Button>
            </Magnetic>
            <p className="mt-4 text-sm text-muted-foreground">{t(locale, "cta_subtext")}</p>
          </>
        ) : (
          <Magnetic className="mt-10">
            <Button asChild size="lg" variant="gradient" className="rounded-full">
              <Link href="#portfolio">{t(locale, "view_our_work")}</Link>
            </Button>
          </Magnetic>
        )}
      </div>
    </section>
  );
}
