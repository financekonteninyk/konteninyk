"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence, useMotionValue, useSpring, useReducedMotion } from "framer-motion";
import { ImageOff, Layers } from "lucide-react";
import { getVideoPrimaryLink } from "@/lib/utils";
import type { VideoWithClient } from "@/types/video";

// Fixed slot positions + individual depth (translateZ, in px) for genuine
// 3D parallax as the scene tilts — cards with more depth shift more.
const CARD_LAYOUT = [
  { top: "24%", left: "0%", z: 40 },
  { top: "2%", left: "30%", z: 90 },
  { top: "30%", left: "58%", z: 20 },
  { top: "52%", left: "24%", z: 65 },
] as const;

const ROTATE_INTERVAL_MS = 4000;
const TILT_DEGREES = 22;

interface SceneCardProps {
  video: VideoWithClient;
  index: number;
  prefersReducedMotion: boolean;
}

function SceneCard({ video, index, prefersReducedMotion }: SceneCardProps) {
  const layout = CARD_LAYOUT[index % CARD_LAYOUT.length]!;
  const link = getVideoPrimaryLink(video);

  const thumbnail = (
    <div className="group/card relative h-full w-full overflow-hidden rounded-xl border border-white/10 bg-muted shadow-[0_20px_50px_-15px_rgba(0,0,0,0.6)] transition-shadow duration-300 hover:shadow-[0_30px_70px_-15px_rgba(0,0,0,0.75)] sm:rounded-2xl md:rounded-3xl">
      <AnimatePresence mode="sync">
        <motion.div
          key={video.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, delay: index * 0.12 }}
          className="absolute inset-0"
        >
          {video.thumbnail_url ? (
            <Image
              src={video.thumbnail_url}
              alt=""
              fill
              sizes="200px"
              className="object-cover transition-transform duration-500 group-hover/card:scale-110"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-muted-foreground">
              <ImageOff className="h-5 w-5" />
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Glass caption bar: client logo + name, always legible over any thumbnail */}
      {video.content_type === "carousel" && (
        <div className="absolute right-1.5 top-1.5 flex items-center gap-0.5 rounded-full bg-black/50 px-1.5 py-0.5 text-[8px] font-medium text-white backdrop-blur-sm sm:right-2 sm:top-2">
          <Layers className="h-2.5 w-2.5" />
          {video.carousel_images.length + 1}
        </div>
      )}
      <div className="absolute inset-x-0 bottom-0 flex items-center gap-1.5 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-1.5 backdrop-blur-[2px] sm:gap-2 sm:p-2">
        <span className="relative h-4 w-4 shrink-0 overflow-hidden rounded-full ring-1 ring-white/40 sm:h-5 sm:w-5">
          {video.client.logo_url ? (
            <Image src={video.client.logo_url} alt="" fill sizes="20px" className="object-cover" />
          ) : (
            <span className="flex h-full w-full items-center justify-center bg-white/20 text-[7px] font-semibold text-white sm:text-[8px]">
              {video.client.name.slice(0, 2).toUpperCase()}
            </span>
          )}
        </span>
        <span className="truncate text-[9px] font-medium text-white sm:text-[11px]">
          {video.client.name}
        </span>
      </div>

      {/* Subtle top sheen for a more premium/glassy edge */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-white/10 to-transparent" />
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
      style={{ top: layout.top, left: layout.left, z: layout.z }}
      className="pointer-events-auto absolute h-44 w-28 sm:h-52 sm:w-32 md:h-60 md:w-40 lg:h-72 lg:w-44"
    >
      <motion.div
        className="h-full w-full"
        animate={prefersReducedMotion ? undefined : { y: [0, -16, 0] }}
        whileHover={prefersReducedMotion ? undefined : { scale: 1.08, y: -6 }}
        transition={{ duration: 5 + index, repeat: Infinity, ease: "easeInOut", delay: index * 0.5 }}
      >
        {link.external ? (
          <a
            href={link.href}
            target="_blank"
            rel="noreferrer noopener"
            aria-label={`View ${video.client.name} on social media`}
            className="block h-full w-full"
          >
            {thumbnail}
          </a>
        ) : (
          <Link href={link.href} aria-label={`View ${video.client.name} gallery`} className="block h-full w-full">
            {thumbnail}
          </Link>
        )}
      </motion.div>
    </motion.div>
  );
}

/**
 * A "scene" of floating video cards that tilts in 3D following the cursor
 * anywhere on the page. Each card sits at its own depth (translateZ), so as
 * the scene rotates, nearer cards shift more than farther ones — genuine
 * parallax rather than a flat rotation. Card positions are fixed; the
 * videos shown inside rotate together on a single shared timer, offset by
 * slot index, guaranteeing every visible slot always shows a different
 * video, capped to how many distinct videos are actually available.
 */
export function FloatingCards({ videos }: { videos: VideoWithClient[] }) {
  const prefersReducedMotion = useReducedMotion();
  const rotateX = useMotionValue(0);
  const rotateY = useMotionValue(0);
  const springRotateX = useSpring(rotateX, { stiffness: 100, damping: 12 });
  const springRotateY = useSpring(rotateY, { stiffness: 100, damping: 12 });
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    if (prefersReducedMotion) return;

    function handleMove(e: MouseEvent) {
      rotateY.set((e.clientX / window.innerWidth - 0.5) * TILT_DEGREES);
      rotateX.set((e.clientY / window.innerHeight - 0.5) * -TILT_DEGREES);
    }

    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, [prefersReducedMotion, rotateX, rotateY]);

  const slotCount = Math.min(CARD_LAYOUT.length, videos.length);

  React.useEffect(() => {
    if (prefersReducedMotion || slotCount <= 1) return;
    const interval = setInterval(() => setTick((t) => t + 1), ROTATE_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [prefersReducedMotion, slotCount]);

  if (videos.length === 0) return null;

  return (
    <div className="relative h-[380px] w-full sm:h-[420px] md:h-[500px]" style={{ perspective: 1200 }}>
      <motion.div
        className="relative h-full w-full"
        style={{
          rotateX: prefersReducedMotion ? 0 : springRotateX,
          rotateY: prefersReducedMotion ? 0 : springRotateY,
          transformStyle: "preserve-3d",
        }}
      >
        {Array.from({ length: slotCount }, (_, i) => {
          // Consecutive offsets guarantee distinct videos per slot whenever
          // videos.length >= slotCount, which is always true here since
          // slotCount is capped at videos.length above.
          const video = videos[(tick + i) % videos.length]!;
          return <SceneCard key={i} video={video} index={i} prefersReducedMotion={Boolean(prefersReducedMotion)} />;
        })}
      </motion.div>
    </div>
  );
}
