import { RevealText } from "@/components/shared/reveal-text";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

export function WhyUsSection({ locale }: { locale: Locale }) {
  const items = [
    { title: t(locale, "why_us_1_title"), desc: t(locale, "why_us_1_desc") },
    { title: t(locale, "why_us_2_title"), desc: t(locale, "why_us_2_desc") },
    { title: t(locale, "why_us_3_title"), desc: t(locale, "why_us_3_desc") },
  ];

  return (
    <section className="border-t border-border py-20 md:py-28">
      <div className="container">
        <div className="rounded-3xl border border-border bg-secondary/20 p-6 sm:p-10 md:p-14">
          <RevealText
            as="h2"
            text={`${t(locale, "why_us_heading_1")} ${t(locale, "why_us_heading_2")}`}
            className="max-w-md text-balance text-3xl font-bold leading-tight tracking-tight sm:text-4xl md:text-5xl"
          />

          <div className="mt-10 divide-y divide-border border-t border-border">
            {items.map((item, i) => (
              <div key={i} className="grid grid-cols-1 gap-2 py-6 sm:grid-cols-[80px_1fr]">
                <span className="text-sm font-medium text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <h3 className="text-lg font-semibold tracking-tight sm:text-xl">{item.title}</h3>
                  <p className="mt-2 max-w-xl text-sm text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
