"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { ImageOff, Layers } from "lucide-react";
import { getVideoPrimaryLink } from "@/lib/utils";
import type { VideoWithClient } from "@/types/video";

const MAX_LANES = 14;
const ROTATE_INTERVAL_MS = 3500;

interface LaneProps {
  pool: VideoWithClient[];
  baseOffset: number;
  laneIndex: number;
  aspectClassName: string;
  prefersReducedMotion: boolean;
}

function GalleryLane({ pool, baseOffset, laneIndex, aspectClassName, prefersReducedMotion }: LaneProps) {
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    if (prefersReducedMotion || pool.length <= 1) return;
    const interval = setInterval(
      () => setTick((t) => t + 1),
      ROTATE_INTERVAL_MS + laneIndex * 180
    );
    return () => clearInterval(interval);
  }, [prefersReducedMotion, pool.length, laneIndex]);

  // baseOffset comes from a shuffled, unique permutation (see GalleryMarquee),
  // not a sequential lane index — this is what stops neighboring lanes from
  // just showing consecutive items from the pool (which looked "patterned"
  // since the pool is naturally clustered by upload batch/client).
  const video = pool[(tick + baseOffset) % pool.length];
  if (!video) return null;

  const link = getVideoPrimaryLink(video);

  const tile = (
    <div
      className={`relative w-32 shrink-0 overflow-hidden rounded-xl border border-border bg-muted transition-transform duration-300 hover:-translate-y-1 sm:w-40 md:w-44 ${aspectClassName}`}
    >
      <AnimatePresence mode="sync">
        <motion.div
          key={video.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0"
        >
          {video.thumbnail_url ? (
            <Image src={video.thumbnail_url} alt="" fill sizes="180px" className="object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-muted-foreground">
              <ImageOff className="h-5 w-5" />
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {video.content_type === "carousel" && (
        <div className="absolute right-2 top-2 z-10 flex items-center gap-1 rounded-full bg-black/50 px-1.5 py-0.5 text-[9px] font-medium text-white backdrop-blur-sm">
          <Layers className="h-2.5 w-2.5" />
          {video.carousel_images.length + 1}
        </div>
      )}

      <div className="absolute inset-x-0 bottom-0 z-10 flex items-center gap-1.5 bg-gradient-to-t from-black/85 via-black/30 to-transparent p-2">
        <span className="relative h-4 w-4 shrink-0 overflow-hidden rounded-full ring-1 ring-white/40">
          {video.client.logo_url ? (
            <Image src={video.client.logo_url} alt="" fill sizes="16px" className="object-cover" />
          ) : (
            <span className="flex h-full w-full items-center justify-center bg-white/20 text-[7px] font-semibold text-white">
              {video.client.name.slice(0, 2).toUpperCase()}
            </span>
          )}
        </span>
        <span className="truncate text-[10px] font-medium text-white">{video.client.name}</span>
      </div>
    </div>
  );

  return link.external ? (
    <a href={link.href} target="_blank" rel="noreferrer noopener" aria-label={video.client.name}>
      {tile}
    </a>
  ) : (
    <Link href={link.href} aria-label={video.client.name}>
      {tile}
    </Link>
  );
}

/** Fisher-Yates shuffle, pure (doesn't mutate the input). */
function shuffledIndices(length: number): number[] {
  const arr = Array.from({ length }, (_, i) => i);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j]!, arr[i]!];
  }
  return arr;
}

/**
 * A continuously scrolling strip where each lane ALSO independently swaps
 * which video it shows over time. Lane base positions come from a shuffled,
 * unique permutation of the pool (not sequential indices) so:
 * (1) all visible lanes show genuinely different videos at any moment, and
 * (2) neighboring lanes don't end up showing consecutive uploads from the
 * same client, which is what made it look "patterned" before.
 */
export function GalleryMarquee({
  videos,
  aspectClassName = "aspect-[9/16]",
}: {
  videos: VideoWithClient[];
  aspectClassName?: string;
}) {
  const prefersReducedMotion = useReducedMotion();
  const laneCount = Math.min(MAX_LANES, videos.length);

  // Two independent shuffles so the two duplicated copies of the strip
  // (needed for a seamless CSS loop) don't mirror each other either.
  const offsetsA = React.useMemo(() => shuffledIndices(videos.length).slice(0, laneCount), [videos.length, laneCount]);
  const offsetsB = React.useMemo(() => shuffledIndices(videos.length).slice(0, laneCount), [videos.length, laneCount]);

  if (videos.length === 0) return null;

  return (
    <div className="group relative flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_5%,black_95%,transparent)]">
      <div className="flex shrink-0 animate-[marquee_50s_linear_infinite] items-center gap-4 pr-4 group-hover:[animation-play-state:paused]">
        {[offsetsA, offsetsB].map((offsets, copyIndex) =>
          offsets.map((baseOffset, laneIndex) => (
            <GalleryLane
              key={`${copyIndex}-${laneIndex}`}
              pool={videos}
              baseOffset={baseOffset}
              laneIndex={laneIndex}
              aspectClassName={aspectClassName}
              prefersReducedMotion={Boolean(prefersReducedMotion)}
            />
          ))
        )}
      </div>
    </div>
  );
}
