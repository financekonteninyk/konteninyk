"use client";

import * as React from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, Check, Minus, Briefcase, Scissors, UserRound, Sparkles as SparklesIcon } from "lucide-react";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";
import type { PricingCategory, PricingTier } from "@/types/pricing";

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);
}

// Picks a fitting icon based on the package name, falling back to a
// generic sparkle so this never breaks if a category is renamed.
function iconFor(name: string) {
  const lower = name.toLowerCase();
  if (lower.includes("edit")) return Scissors;
  if (lower.includes("personal")) return UserRound;
  if (lower.includes("content") || lower.includes("business")) return Briefcase;
  return SparklesIcon;
}

/**
 * Builds the full set of comparison rows across every tier in a category —
 * the union of every feature label that appears on ANY tier, in the order
 * first seen. This is what lets someone scan across Starter/Creator/
 * Signature and see exactly what's added at each level, instead of each
 * tier only listing the handful of features it happens to include.
 */
function getComparisonLabels(tiers: PricingTier[]): string[] {
  const seen = new Set<string>();
  const labels: string[] = [];
  for (const tier of tiers) {
    for (const feature of tier.features) {
      if (!seen.has(feature.label)) {
        seen.add(feature.label);
        labels.push(feature.label);
      }
    }
  }
  return labels;
}

interface ServicePackagesProps {
  categories: PricingCategory[];
  locale: Locale;
  whatsappUrl: string | null;
}

export function ServicePackages({ categories, locale, whatsappUrl }: ServicePackagesProps) {
  const [openId, setOpenId] = React.useState<string | null>(null);

  return (
    <div className="mt-16 grid grid-cols-1 gap-5 lg:grid-cols-3">
      {categories.map((category) => {
        const isOpen = openId === category.id;
        const Icon = iconFor(category.name);
        const startingPrice = category.tiers.reduce(
          (min, tier) => (tier.price < min ? tier.price : min),
          category.tiers[0]?.price ?? 0
        );
        const comparisonLabels = getComparisonLabels(category.tiers);

        return (
          <div
            key={category.id}
            className={`overflow-hidden rounded-3xl border transition-all duration-300 ${
              isOpen ? "lg:col-span-3 border-primary/40 shadow-xl shadow-primary/10" : "border-border hover:border-primary/30"
            }`}
          >
            <button
              type="button"
              onClick={() => setOpenId(isOpen ? null : category.id)}
              className={`relative flex w-full items-center justify-between gap-4 overflow-hidden p-6 text-left sm:p-8 ${
                isOpen ? "gradient-accent" : ""
              }`}
            >
              <div className="flex items-start gap-4">
                <span
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl transition-colors ${
                    isOpen ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <div>
                  <h3 className="text-lg font-semibold tracking-tight sm:text-xl">{category.name}</h3>
                  {category.subtitle && (
                    <p className="mt-1 text-sm text-muted-foreground">{category.subtitle}</p>
                  )}
                  {!isOpen && startingPrice > 0 && (
                    <p className="mt-2 text-sm font-medium text-primary">
                      {locale === "id" ? "mulai" : "from"} {formatIDR(startingPrice)}
                    </p>
                  )}
                  {!isOpen && (
                    <p className="mt-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                      {t(locale, "services_tap_hint")}
                    </p>
                  )}
                </div>
              </div>
              <motion.span
                animate={{ rotate: isOpen ? 180 : 0 }}
                transition={{ duration: 0.25 }}
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-colors ${
                  isOpen ? "border-primary bg-primary text-primary-foreground" : "border-border"
                }`}
              >
                <ChevronDown className="h-4 w-4" />
              </motion.span>
            </button>

            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <div className="border-t border-border p-6 pt-8 sm:p-8 sm:pt-10">
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                      {category.tiers.map((tier, i) => {
                        const isHighlighted = Boolean(tier.badge);
                        // Look up this tier's value for every comparison
                        // row by label, so every tier card shows the exact
                        // same rows in the exact same order — a feature
                        // missing from this tier just shows a dash.
                        const featureByLabel = new Map(tier.features.map((f) => [f.label, f.value]));

                        return (
                          <div
                            key={i}
                            className={`relative flex flex-col rounded-2xl border p-6 transition-transform hover:-translate-y-1 ${
                              isHighlighted
                                ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
                                : "border-border"
                            }`}
                          >
                            {tier.badge && (
                              <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-[10px] font-semibold uppercase tracking-wide text-primary-foreground">
                                {tier.badge}
                              </span>
                            )}
                            <h4 className="text-lg font-semibold">{tier.name}</h4>
                            <p className="mt-2 text-2xl font-bold tracking-tight">
                              {formatIDR(tier.price)}
                              {tier.period && <span className="text-sm font-normal text-muted-foreground">{tier.period}</span>}
                            </p>
                            {tier.description && (
                              <p className="mt-2 text-sm text-muted-foreground">{tier.description}</p>
                            )}
                            {comparisonLabels.length > 0 && (
                              <ul className="mt-4 space-y-2.5 text-sm">
                                {comparisonLabels.map((label) => {
                                  const value = featureByLabel.get(label);
                                  const included = value !== undefined && value !== "false";
                                  return (
                                    <li
                                      key={label}
                                      className={`flex items-start gap-2 ${included ? "" : "opacity-40"}`}
                                    >
                                      {included ? (
                                        <Check className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${isHighlighted ? "text-primary" : "text-muted-foreground"}`} />
                                      ) : (
                                        <Minus className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                                      )}
                                      <span>
                                        {label}
                                        {included && value !== "true" && (
                                          <span className="text-muted-foreground"> — {value}</span>
                                        )}
                                      </span>
                                    </li>
                                  );
                                })}
                              </ul>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {whatsappUrl && (
                      <div className="mt-8 text-center">
                        <Link
                          href={`${whatsappUrl}${whatsappUrl.includes("?") ? "&" : "?"}text=${encodeURIComponent(
                            locale === "id"
                              ? `Halo, saya tertarik dengan paket ${category.name}. Boleh minta info lebih lanjut?`
                              : `Hi, I'm interested in the ${category.name} package. Could you share more details?`
                          )}`}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="inline-flex items-center justify-center rounded-full bg-gradient-to-br from-primary to-[hsl(231,70%,52%)] px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-transform hover:-translate-y-0.5"
                        >
                          {t(locale, "services_cta")}
                        </Link>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
