"use client";

import { motion } from "framer-motion";

export function StatsLine({ text }: { text: string | null }) {
  if (!text) return null;

  return (
    <motion.p
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="eyebrow text-center text-xs text-muted-foreground"
    >
      {text}
    </motion.p>
  );
}
