"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Search, Compass, Video, RefreshCw } from "lucide-react";
import { RevealText } from "@/components/shared/reveal-text";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

const STEPS = {
  id: [
    {
      number: "01",
      title: "Discovery",
      description:
        "Kami memahami karakter brand, audiens, tujuan bisnis, dan posisi brand di pasar — fondasi sebelum strategi dan konten mulai dibangun.",
      icon: Search,
    },
    {
      number: "02",
      title: "Strategy",
      description:
        "Kami menerjemahkan insight menjadi strategi konten yang jelas — mulai dari content pillar, tone of voice, identitas visual dan audio, hingga customer journey melalui TOFU–MOFU–BOFU.",
      icon: Compass,
    },
    {
      number: "03",
      title: "Production",
      description:
        "Strategi diterjemahkan menjadi konten melalui proses produksi yang efisien, menghasilkan berbagai aset dan format yang siap digunakan di berbagai platform.",
      icon: Video,
    },
    {
      number: "04",
      title: "Growth Loop",
      description:
        "Kami mengevaluasi performa konten secara berkala — memahami apa yang berhasil, apa yang perlu diperbaiki, dan insight apa yang dapat menjadi dasar strategi berikutnya.",
      icon: RefreshCw,
    },
  ],
  en: [
    {
      number: "01",
      title: "Discovery",
      description:
        "We understand your brand character, audience, business goals, and market position — the foundation before strategy and content are built.",
      icon: Search,
    },
    {
      number: "02",
      title: "Strategy",
      description:
        "We turn insights into a clear content strategy — from content pillars, tone of voice, visual and audio identity, to the customer journey across TOFU–MOFU–BOFU.",
      icon: Compass,
    },
    {
      number: "03",
      title: "Production",
      description:
        "We turn strategy into content through an efficient production process, creating versatile assets and formats ready for different platforms.",
      icon: Video,
    },
    {
      number: "04",
      title: "Growth Loop",
      description:
        "We regularly evaluate content performance — identifying what works, what needs improvement, and which insights can shape the next strategy.",
      icon: RefreshCw,
    },
  ],
} as const;

export function ProcessSection({
  locale,
  glsIconUrl,
}: {
  locale: Locale;
  glsIconUrl?: string | null;
}) {
  const steps = STEPS[locale];

  return (
    <section
      id="process"
      className="scroll-mt-20 border-t border-border py-20 md:py-28"
    >
      <div className="container">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">
          {t(locale, "how_we_work")}
        </span>

        <RevealText
          as="h2"
          text={t(locale, "process_heading")}
          className="text-4xl font-bold tracking-tight md:text-6xl"
        />

        <p className="mt-6 max-w-2xl text-balance text-muted-foreground">
          {t(locale, "process_desc")}
        </p>

        <div className="relative mt-16 grid grid-cols-1 gap-10 md:grid-cols-4 md:gap-6">
          <div
            aria-hidden
            className="absolute left-0 right-0 top-6 hidden h-px bg-border md:block"
          />

          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative"
            >
              <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full border border-border bg-background">
                {i === steps.length - 1 ? (
                  glsIconUrl ? (
                    <Image
                      src={glsIconUrl}
                      alt="Growth Loop System"
                      width={20}
                      height={20}
                      className="rounded object-cover"
                    />
                  ) : (
                    <RefreshCw className="h-5 w-5" />
                  )
                ) : (
                  <step.icon className="h-5 w-5" />
                )}
              </div>

              <span className="eyebrow mt-5 block text-xs text-muted-foreground">
                {step.number}
              </span>

              <h3 className="mt-2 text-xl font-semibold tracking-tight">
                {step.title}
              </h3>

              <p className="mt-2 text-sm text-muted-foreground">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        <p className="mt-10 flex items-center gap-1.5 text-sm text-muted-foreground">
          {glsIconUrl && (
            <Image
              src={glsIconUrl}
              alt="Growth Loop System"
              width={14}
              height={14}
              className="shrink-0 rounded object-cover"
            />
          )}

          {t(locale, "process_loop_note")}
        </p>
      </div>
    </section>
  );
}
