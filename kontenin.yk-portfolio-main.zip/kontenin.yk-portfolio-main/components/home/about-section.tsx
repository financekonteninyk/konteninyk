import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { RevealText } from "@/components/shared/reveal-text";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

export function AboutSection({ aboutText, locale }: { aboutText: string; locale: Locale }) {
  return (
    <section id="about" className="scroll-mt-20 border-t border-border py-20 md:py-28">
      <div className="container">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow mb-6 block text-xs text-muted-foreground">
            {t(locale, "who_we_are")}
          </span>
          <RevealText
            as="p"
            text={aboutText}
            className="justify-center text-balance text-xl font-medium leading-relaxed tracking-tight text-foreground md:text-4xl"
          />
          <Link
            href="/about"
            data-cursor-pointer
            className="group mt-8 inline-flex items-center gap-1.5 text-sm font-medium transition-opacity hover:opacity-70"
          >
            {t(locale, "read_full_story")}
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
