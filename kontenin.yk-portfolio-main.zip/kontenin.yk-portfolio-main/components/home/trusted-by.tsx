import Link from "next/link";
import Image from "next/image";
import { getFeaturedClients } from "@/lib/data/clients";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

export async function TrustedBySection({ locale }: { locale: Locale }) {
  const clients = await getFeaturedClients(12);

  if (clients.length === 0) return null;

  // Duplicate the list so the marquee loops seamlessly.
  const marqueeClients = [...clients, ...clients];

  return (
    <section className="border-y border-border py-14">
      <div className="container mb-8">
        <p className="eyebrow text-center text-xs text-muted-foreground">{t(locale, "trusted_by")}</p>
      </div>

      <div className="group relative flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
        <div className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-14 pr-14 group-hover:[animation-play-state:paused]">
          {marqueeClients.map((client, i) => (
            <Link
              key={`${client.id}-${i}`}
              href={`/client/${client.id}`}
              className="relative h-10 w-28 shrink-0 transition-transform duration-300 hover:scale-105"
              aria-label={client.name}
            >
              {client.logo_url && (
                <Image
                  src={client.logo_url}
                  alt={client.name}
                  fill
                  sizes="112px"
                  className="object-contain"
                />
              )}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
