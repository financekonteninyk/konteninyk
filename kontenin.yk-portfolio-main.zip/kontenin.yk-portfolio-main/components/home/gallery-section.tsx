import { GalleryMarquee } from "@/components/home/gallery-marquee";
import { getAllPublishedVideos } from "@/lib/data/videos";
import { t } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/locale";

export async function GallerySection({ locale }: { locale: Locale }) {
  const [videos, carousels] = await Promise.all([
    getAllPublishedVideos(40, "video"),
    getAllPublishedVideos(40, "carousel"),
  ]);

  if (videos.length === 0 && carousels.length === 0) return null;

  return (
    // id changed from "gallery" to "portfolio" — this is now the section
    // the "Portfolio" nav link points to, since it shows actual creative
    // work. The old client-logo grid below is no longer "Portfolio".
    <section id="portfolio" className="scroll-mt-20 border-t border-border py-20 md:py-28">
      <div className="container mb-10">
        <span className="eyebrow mb-4 block text-xs text-muted-foreground">
          {t(locale, "selected_work")}
        </span>
        <h2 className="text-4xl font-bold tracking-tight md:text-5xl">
          {t(locale, "gallery_heading")}
        </h2>
        <p className="mt-4 max-w-xl text-muted-foreground">{t(locale, "gallery_subheading")}</p>
      </div>

      {videos.length > 0 && (
        <div className="mb-10">
          <p className="container mb-4 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {t(locale, "gallery_video_label")}
          </p>
          <GalleryMarquee videos={videos} aspectClassName="aspect-[9/16]" />
        </div>
      )}

      {carousels.length > 0 && (
        <div>
          <p className="container mb-4 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {t(locale, "gallery_carousel_label")}
          </p>
          <GalleryMarquee videos={carousels} aspectClassName="aspect-[4/5]" />
        </div>
      )}
    </section>
  );
}
