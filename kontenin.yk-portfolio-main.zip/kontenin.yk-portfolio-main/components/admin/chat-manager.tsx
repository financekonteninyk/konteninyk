"use client";

import { UnmatchedQueriesExport } from "@/components/admin/unmatched-queries-export";
import { QaBulkImport } from "@/components/admin/qa-bulk-import";
import { QaEntriesSummary } from "@/components/admin/qa-entries-summary";
import { clearAllUnmatchedQueriesAction, clearAllQaEntriesAction } from "@/lib/actions/chat";
import type { ChatQaEntry, UnmatchedQuery } from "@/types/chat";

interface ChatManagerProps {
  qaEntries: ChatQaEntry[];
  unmatchedQueries: UnmatchedQuery[];
}

export function ChatManager({ qaEntries, unmatchedQueries }: ChatManagerProps) {
  return (
    <div className="space-y-8">
      <UnmatchedQueriesExport items={unmatchedQueries} onClearAll={clearAllUnmatchedQueriesAction} />
      <QaBulkImport />
      <QaEntriesSummary items={qaEntries} onClearAll={clearAllQaEntriesAction} />
    </div>
  );
}
