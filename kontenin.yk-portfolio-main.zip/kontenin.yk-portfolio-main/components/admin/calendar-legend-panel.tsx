import { Sparkles, MessageSquareText, CheckCircle2, XCircle, Clock } from "lucide-react";

export function CalendarLegendPanel() {
  return (
    <div className="rounded-2xl border border-border p-4">
      <p className="mb-3 text-sm font-semibold">Keterangan</p>

      <div className="mb-4 space-y-2.5">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Sumber Konten</p>
        <div className="flex items-center gap-2 text-sm">
          <span className="h-3 w-3 rounded-full border-2 border-border" />
          Rencana Reguler
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="h-3 w-3 rounded-full ring-2 ring-amber-400/60" />
          <MessageSquareText className="h-3.5 w-3.5 text-amber-500" />
          Request Klien
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="h-3 w-3 rounded-full ring-2 ring-violet-400/60" />
          <Sparkles className="h-3.5 w-3.5 text-violet-500" />
          Inisiatif Kontenin.yk
        </div>
      </div>

      <div className="space-y-2.5">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Persetujuan Klien</p>
        <div className="flex items-center gap-2 text-sm">
          <Clock className="h-3.5 w-3.5 text-muted-foreground" />
          Menunggu Review
        </div>
        <div className="flex items-center gap-2 text-sm">
          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
          Disetujui
        </div>
        <div className="flex items-center gap-2 text-sm">
          <XCircle className="h-3.5 w-3.5 text-destructive" />
          Ditolak / Minta Revisi
        </div>
      </div>

      <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">
        Konten dengan Kategori Fungsi (Trust, Awareness, dll) tampil dengan warna latar sesuai kategorinya di kalender.
      </p>
    </div>
  );
}
