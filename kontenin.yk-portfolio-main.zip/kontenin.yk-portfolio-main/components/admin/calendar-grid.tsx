"use client";

import * as React from "react";
import { Plus, CheckCircle2 } from "lucide-react";
import { getWorkflowStage, WORKFLOW_STAGE_LABELS, STAGE_ICON, STAGE_COLOR, STAGE_DOT } from "@/lib/calendar-workflow";
import type { ContentCalendarEntry } from "@/types/calendar";

const WEEKDAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const WEEKDAY_LABELS_SHORT = ["S", "M", "T", "W", "T", "F", "S"];

const MAX_VISIBLE_PER_DAY = 2;
const MAX_DOTS_MOBILE = 4;

interface CalendarGridProps {
  year: number;
  month: number; // 0-11
  entries: ContentCalendarEntry[];
  onDayClick: (isoDate: string) => void;
  onEntryClick: (entry: ContentCalendarEntry) => void;
  onShowMore?: (isoDate: string) => void;
  readOnly?: boolean;
}

function toIsoDate(year: number, month: number, day: number): string {
  const y = String(year).padStart(4, "0");
  const m = String(month + 1).padStart(2, "0");
  const d = String(day).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function CalendarGrid({ year, month, entries, onDayClick, onEntryClick, onShowMore, readOnly = false }: CalendarGridProps) {
  const firstOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leadingBlanks = firstOfMonth.getDay(); // 0 = Sunday

  const entriesByDate = new Map<string, ContentCalendarEntry[]>();
  for (const entry of entries) {
    const list = entriesByDate.get(entry.entry_date) ?? [];
    list.push(entry);
    entriesByDate.set(entry.entry_date, list);
  }

  const todayIso = toIsoDate(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

  const cells: { day: number | null; iso: string | null }[] = [];
  for (let i = 0; i < leadingBlanks; i++) cells.push({ day: null, iso: null });
  for (let d = 1; d <= daysInMonth; d++) cells.push({ day: d, iso: toIsoDate(year, month, d) });
  while (cells.length % 7 !== 0) cells.push({ day: null, iso: null });

  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card">
      <div className="grid grid-cols-7 border-b border-border">
        {WEEKDAY_LABELS.map((label, i) => (
          <div key={label} className="py-2.5 text-center text-[11px] font-semibold uppercase tracking-wide text-muted-foreground sm:py-3">
            <span className="sm:hidden">{WEEKDAY_LABELS_SHORT[i]}</span>
            <span className="hidden sm:inline">{label}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {cells.map((cell, i) => {
          const dayEntries = cell.iso ? entriesByDate.get(cell.iso) ?? [] : [];
          const visibleEntries = dayEntries.slice(0, MAX_VISIBLE_PER_DAY);
          const overflowCount = dayEntries.length - visibleEntries.length;
          const isToday = cell.iso === todayIso;
          const hasEntries = dayEntries.length > 0;

          return (
            <div
              key={i}
              className={`group relative min-h-[64px] border-b border-r border-border/70 p-1.5 transition-colors last:border-r-0 hover:bg-secondary/30 sm:min-h-[140px] sm:p-2.5 ${
                cell.day === null ? "bg-secondary/10" : ""
              }`}
            >
              {cell.day !== null && (
                <>
                  <div className="mb-1 flex items-center justify-between sm:mb-1.5">
                    <span
                      className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold transition-colors ${
                        isToday ? "bg-primary text-primary-foreground" : "text-foreground"
                      }`}
                    >
                      {cell.day}
                    </span>
                    {!readOnly && (
                      <button
                        type="button"
                        onClick={() => cell.iso && onDayClick(cell.iso)}
                        aria-label="Add content"
                        className="hidden h-5 w-5 items-center justify-center rounded-full text-muted-foreground opacity-70 transition-all hover:bg-secondary hover:text-foreground sm:flex md:opacity-0 md:group-hover:opacity-100"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Mobile: tap anywhere on a day with content to open the
                      full detail drawer — a row of small dots hints at
                      what's there without forcing 3 lines of text into a
                      ~45px-wide cell. */}
                  {hasEntries && (
                    <button
                      type="button"
                      onClick={() => cell.iso && (onShowMore ? onShowMore(cell.iso) : onEntryClick(dayEntries[0]!))}
                      className="flex w-full flex-wrap items-center justify-center gap-1 py-1 sm:hidden"
                      aria-label={`${dayEntries.length} items on day ${cell.day}`}
                    >
                      {dayEntries.slice(0, MAX_DOTS_MOBILE).map((entry) => (
                        <span key={entry.id} className={`h-1.5 w-1.5 rounded-full ${STAGE_DOT[getWorkflowStage(entry)]}`} />
                      ))}
                      {dayEntries.length > MAX_DOTS_MOBILE && (
                        <span className="text-[9px] font-medium text-muted-foreground">+{dayEntries.length - MAX_DOTS_MOBILE}</span>
                      )}
                    </button>
                  )}

                  {/* Desktop: full mini-cards, unchanged */}
                  <div className="hidden space-y-1 sm:block">
                    {visibleEntries.map((entry) => {
                      const stage = getWorkflowStage(entry);
                      const StageIcon = STAGE_ICON[stage];
                      return (
                        <button
                          key={entry.id}
                          type="button"
                          onClick={() => onEntryClick(entry)}
                          className="block w-full rounded-lg border border-border/80 bg-background px-2 py-1.5 text-left transition-all hover:-translate-y-0.5 hover:border-foreground/20 hover:shadow-sm"
                          style={entry.function_color ? { borderLeftColor: entry.function_color, borderLeftWidth: 3 } : undefined}
                        >
                          <div className="flex items-center justify-between gap-1">
                            <p className="truncate text-[10px] font-semibold uppercase tracking-wide">{entry.content_type}</p>
                            {entry.client_confirmed && <CheckCircle2 className="h-3 w-3 shrink-0 text-emerald-500" />}
                          </div>
                          {entry.function_tag && (
                            <p className="truncate text-[10px] text-muted-foreground">{entry.function_tag}</p>
                          )}
                          <p className={`mt-0.5 flex items-center gap-1 text-[10px] font-medium ${STAGE_COLOR[stage]}`}>
                            <StageIcon className="h-2.5 w-2.5" />
                            {WORKFLOW_STAGE_LABELS[stage]}
                          </p>
                        </button>
                      );
                    })}
                    {overflowCount > 0 && (
                      <button
                        type="button"
                        onClick={() => cell.iso && onShowMore?.(cell.iso)}
                        className="w-full rounded-lg px-2 py-1 text-left text-[10px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                      >
                        +{overflowCount} more
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
