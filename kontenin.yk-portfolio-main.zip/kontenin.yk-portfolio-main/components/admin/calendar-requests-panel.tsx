"use client";

import * as React from "react";
import { Inbox, Check, X, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { dismissCalendarRequestAction } from "@/lib/actions/calendar";
import type { ContentCalendarRequest } from "@/types/calendar";

interface CalendarRequestsPanelProps {
  calendarId: string;
  requests: ContentCalendarRequest[];
}

export function CalendarRequestsPanel({ calendarId, requests }: CalendarRequestsPanelProps) {
  const [dismissing, setDismissing] = React.useState<string | null>(null);
  const pending = requests.filter((r) => r.status === "pending");

  async function handleDismiss(id: string) {
    setDismissing(id);
    await dismissCalendarRequestAction(id, calendarId);
    setDismissing(null);
  }

  if (pending.length === 0) {
    return (
      <div className="rounded-2xl border border-border p-5 text-center">
        <Inbox className="mx-auto mb-2 h-5 w-5 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">Belum ada request dari klien.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="flex items-center gap-1.5 text-sm font-semibold">
        <Inbox className="h-4 w-4" />
        Request Klien ({pending.length})
      </p>
      {pending.map((req) => (
        <div key={req.id} className="rounded-2xl border border-amber-400/40 bg-amber-400/5 p-4">
          <p className="text-sm">{req.message}</p>
          {req.reference_url && (
            <a
              href={req.reference_url}
              target="_blank"
              rel="noreferrer noopener"
              className="mt-1.5 inline-flex items-center gap-1 text-xs text-primary hover:underline"
            >
              Lihat referensi <ExternalLink className="h-3 w-3" />
            </a>
          )}
          <p className="mt-2 text-[11px] text-muted-foreground">
            Masukkan manual ke kalender (klik tanggal → Tambah Konten), lalu tandai selesai di sini setelah dijadwalkan.
          </p>
          <div className="mt-3 flex gap-2">
            <Button
              type="button"
              size="sm"
              variant="outline"
              disabled={dismissing === req.id}
              onClick={() => handleDismiss(req.id)}
            >
              <Check className="h-3.5 w-3.5" />
              Tandai Selesai
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              disabled={dismissing === req.id}
              onClick={() => handleDismiss(req.id)}
              className="text-muted-foreground"
            >
              <X className="h-3.5 w-3.5" />
              Abaikan
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
