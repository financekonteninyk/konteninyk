"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import Image from "next/image";
import { Loader2, Save, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ImageUpload } from "@/components/admin/image-upload";
import { STORAGE_BUCKETS } from "@/lib/constants";
import { VIDEO_PLATFORMS, PLATFORM_LABELS, CONTENT_TYPES, CONTENT_TYPE_LABELS } from "@/types/video";
import type { Video, VideoPlatform, ContentType } from "@/types/video";
import type { VideoActionState } from "@/lib/actions/videos";

interface VideoFormProps {
  video?: Video;
  action: (state: VideoActionState, formData: FormData) => Promise<VideoActionState>;
}

const initialState: VideoActionState = {};

export function VideoForm({ video, action }: VideoFormProps) {
  const [state, formAction] = useActionState(action, initialState);
  const [thumbnailUrl, setThumbnailUrl] = React.useState<string | null>(video?.thumbnail_url ?? null);
  const [platform, setPlatform] = React.useState<VideoPlatform | "">(video?.platform ?? "");
  const [contentType, setContentType] = React.useState<ContentType>(video?.content_type ?? "video");
  const [carouselImages, setCarouselImages] = React.useState<string[]>(video?.carousel_images ?? []);
  const [newSlideUrl, setNewSlideUrl] = React.useState<string | null>(null);

  const fieldError = (key: string) => state.fieldErrors?.[key];

  function addSlide(url: string | null) {
    if (!url) return;
    setCarouselImages((prev) => [...prev, url]);
    setNewSlideUrl(null);
  }

  function removeSlide(index: number) {
    setCarouselImages((prev) => prev.filter((_, i) => i !== index));
  }

  return (
    <form action={formAction} className="space-y-8">
      <input type="hidden" name="thumbnail_url" value={thumbnailUrl ?? ""} />
      <input type="hidden" name="platform" value={platform} />
      <input type="hidden" name="content_type" value={contentType} />
      {carouselImages.map((url) => (
        <input key={url} type="hidden" name="carousel_images" value={url} />
      ))}

      {state.error && (
        <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">
          {state.error}
        </p>
      )}

      <div className="space-y-2">
        <Label>Content Type</Label>
        <Select value={contentType} onValueChange={(v) => setContentType(v as ContentType)}>
          <SelectTrigger className="max-w-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {CONTENT_TYPES.map((c) => (
              <SelectItem key={c} value={c}>
                {CONTENT_TYPE_LABELS[c]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground">
          Carousel is for multi-image Instagram-style posts — add extra slides below.
        </p>
      </div>

      <div className="flex justify-center">
        <ImageUpload
          label={contentType === "carousel" ? "Slide 1 (4:5)" : "Thumbnail (9:16 portrait)"}
          bucket={STORAGE_BUCKETS.VIDEO_THUMBNAILS}
          value={thumbnailUrl}
          onChange={setThumbnailUrl}
          aspectClassName={contentType === "carousel" ? "aspect-[4/5] max-w-[280px]" : "aspect-[9/16] max-w-[240px]"}
        />
      </div>
      {fieldError("thumbnail_url") && (
        <p className="text-center text-xs text-destructive">{fieldError("thumbnail_url")}</p>
      )}

      {contentType === "carousel" && (
        <div className="space-y-3 rounded-2xl border border-border p-5">
          <Label>Additional Slides</Label>

          {carouselImages.length > 0 && (
            <div className="flex flex-wrap gap-3">
              {carouselImages.map((url, i) => (
                <div key={url} className="relative aspect-[4/5] w-20 overflow-hidden rounded-lg border border-border">
                  <Image src={url} alt={`Slide ${i + 2}`} fill sizes="80px" className="object-cover" />
                  <button
                    type="button"
                    onClick={() => removeSlide(i)}
                    aria-label={`Remove slide ${i + 2}`}
                    className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-background/90 text-foreground shadow-sm transition-colors hover:bg-destructive hover:text-destructive-foreground"
                  >
                    <X className="h-3 w-3" />
                  </button>
                  <span className="absolute bottom-1 left-1 rounded bg-background/90 px-1 text-[9px] font-medium">
                    {i + 2}
                  </span>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-end gap-3">
            <ImageUpload
              label="Add a slide"
              bucket={STORAGE_BUCKETS.VIDEO_THUMBNAILS}
              value={newSlideUrl}
              onChange={setNewSlideUrl}
              aspectClassName="aspect-[4/5] max-w-[140px]"
            />
            <Button type="button" size="sm" variant="outline" onClick={() => addSlide(newSlideUrl)} disabled={!newSlideUrl}>
              <Plus className="h-3.5 w-3.5" />
              Add Slide
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="title">Title <span className="text-muted-foreground">(optional)</span></Label>
          <Input id="title" name="title" defaultValue={video?.title ?? ""} placeholder="e.g. Behind the Scenes" />
        </div>
        <div className="space-y-2">
          <Label>Platform</Label>
          <Select value={platform} onValueChange={(v) => setPlatform(v as VideoPlatform)}>
            <SelectTrigger>
              <SelectValue placeholder="Select platform" />
            </SelectTrigger>
            <SelectContent>
              {VIDEO_PLATFORMS.map((p) => (
                <SelectItem key={p} value={p}>
                  {PLATFORM_LABELS[p]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description <span className="text-muted-foreground">(optional)</span></Label>
        <Textarea
          id="description"
          name="description"
          defaultValue={video?.description ?? ""}
          placeholder="Optional caption or notes"
          rows={3}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="instagram_url">Instagram URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="instagram_url"
            name="instagram_url"
            type="url"
            defaultValue={video?.instagram_url ?? ""}
            placeholder="https://instagram.com/reel/..."
          />
          {fieldError("instagram_url") && (
            <p className="text-xs text-destructive">{fieldError("instagram_url")}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="tiktok_url">TikTok URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="tiktok_url"
            name="tiktok_url"
            type="url"
            defaultValue={video?.tiktok_url ?? ""}
            placeholder="https://tiktok.com/..."
          />
          {fieldError("tiktok_url") && (
            <p className="text-xs text-destructive">{fieldError("tiktok_url")}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="youtube_url">YouTube URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="youtube_url"
            name="youtube_url"
            type="url"
            defaultValue={video?.youtube_url ?? ""}
            placeholder="https://youtube.com/shorts/..."
          />
          {fieldError("youtube_url") && (
            <p className="text-xs text-destructive">{fieldError("youtube_url")}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="views_count">Views Count <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="views_count"
            name="views_count"
            type="number"
            min={0}
            defaultValue={video?.views_count ?? ""}
            placeholder="e.g. 125000"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tags">Tags <span className="text-muted-foreground">(optional, comma separated)</span></Label>
          <Input
            id="tags"
            name="tags"
            defaultValue={video?.tags.join(", ") ?? ""}
            placeholder="e.g. bts, launch, reels"
          />
        </div>
      </div>

      <SubmitButton isEdit={Boolean(video)} />
    </form>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Save Video"}
    </Button>
  );
}
