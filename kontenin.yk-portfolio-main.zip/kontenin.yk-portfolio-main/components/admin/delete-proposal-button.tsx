"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteProposalAction } from "@/lib/actions/documents";

export function DeleteProposalButton({ id, title }: { id: string; title: string }) {
  const router = useRouter();

  return (
    <DeleteButton itemLabel={title} onDelete={() => deleteProposalAction(id)} onDeleted={() => router.refresh()} />
  );
}
