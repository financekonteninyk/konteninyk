"use client";

import * as React from "react";
import { Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PrintButton } from "@/components/admin/print-button";
import { PaymentConfirmationPreview, type PaymentConfirmationPreviewProps } from "@/components/admin/payment-confirmation-preview";

type PreviewData = Omit<PaymentConfirmationPreviewProps, "theme" | "printTargetId">;

export function PaymentConfirmationPrintView(props: PreviewData) {
  const [theme, setTheme] = React.useState<"light" | "dark">("light");

  return (
    <div className="mx-auto max-w-2xl py-8 print:py-0">
      <div className="mb-4 flex items-center justify-end gap-2 print:hidden">
        <Button type="button" variant="outline" onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}>
          {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          {theme === "light" ? "Switch to Dark" : "Switch to Light"}
        </Button>
        <PrintButton />
      </div>
      <PaymentConfirmationPreview {...props} printTargetId="payment-confirmation-print-area" theme={theme} />
    </div>
  );
}
