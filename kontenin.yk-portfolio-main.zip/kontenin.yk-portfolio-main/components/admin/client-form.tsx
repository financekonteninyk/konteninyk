"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ImageUpload } from "@/components/admin/image-upload";
import { CategorySelect } from "@/components/admin/category-select";
import { ServiceMultiSelect } from "@/components/admin/service-multiselect";
import { STATUS_LABELS, CLIENT_STATUSES } from "@/types/client";
import { STORAGE_BUCKETS } from "@/lib/constants";
import type { Client, ClientStatus } from "@/types/client";
import type { Category, Service } from "@/types/settings";
import type { ClientActionState } from "@/lib/actions/clients";

interface ClientFormProps {
  client?: Client;
  categories: Category[];
  services: Service[];
  action: (state: ClientActionState, formData: FormData) => Promise<ClientActionState>;
}

const initialState: ClientActionState = {};

export function ClientForm({ client, categories, services, action }: ClientFormProps) {
  const [state, formAction] = useActionState(action, initialState);

  const [logoUrl, setLogoUrl] = React.useState<string | null>(client?.logo_url ?? null);
  const [coverUrl, setCoverUrl] = React.useState<string | null>(client?.cover_thumbnail_url ?? null);
  const [category, setCategory] = React.useState(client?.category ?? "");
  const [selectedServices, setSelectedServices] = React.useState<string[]>(client?.services ?? []);
  const [status, setStatus] = React.useState<ClientStatus>(client?.status ?? "draft");
  const [featured, setFeatured] = React.useState(client?.featured ?? false);

  const fieldError = (key: string) => state.fieldErrors?.[key];

  return (
    <form action={formAction} className="space-y-8">
      <input type="hidden" name="logo_url" value={logoUrl ?? ""} />
      <input type="hidden" name="cover_thumbnail_url" value={coverUrl ?? ""} />
      <input type="hidden" name="category" value={category} />
      <input type="hidden" name="status" value={status} />
      <input type="hidden" name="featured" value={featured ? "true" : "false"} />
      {selectedServices.map((service) => (
        <input key={service} type="hidden" name="services" value={service} />
      ))}

      {state.error && (
        <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">
          {state.error}
        </p>
      )}

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">Client Name</Label>
          <Input id="name" name="name" defaultValue={client?.name} placeholder="e.g. Kopi Kenangan" required />
          {fieldError("name") && <p className="text-xs text-destructive">{fieldError("name")}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="industry">Industry <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="industry"
            name="industry"
            defaultValue={client?.industry ?? ""}
            placeholder="e.g. Food & Beverage Retail"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label>Category</Label>
          <CategorySelect categories={categories} value={category} onChange={setCategory} />
          {fieldError("category") && <p className="text-xs text-destructive">{fieldError("category")}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="period">Period <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="period"
            name="period"
            defaultValue={client?.period ?? ""}
            placeholder="e.g. Jan 2024 - Sekarang"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">
          Description <span className="text-muted-foreground">(optional)</span>
        </Label>
        <Textarea
          id="description"
          name="description"
          defaultValue={client?.description}
          placeholder="Describe the partnership, goals, and results..."
          rows={5}
        />
        {fieldError("description") && (
          <p className="text-xs text-destructive">{fieldError("description")}</p>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <ImageUpload
          label="Client Logo"
          bucket={STORAGE_BUCKETS.CLIENT_LOGOS}
          value={logoUrl}
          onChange={setLogoUrl}
          aspectClassName="aspect-square max-w-[200px]"
        />
        <ImageUpload
          label="Overview Thumbnail (landscape)"
          bucket={STORAGE_BUCKETS.CLIENT_COVERS}
          value={coverUrl}
          onChange={setCoverUrl}
          aspectClassName="aspect-video"
        />
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="brand_color">Brand Color</Label>
          <div className="flex items-center gap-2">
            <Input
              id="brand_color"
              name="brand_color"
              defaultValue={client?.brand_color ?? ""}
              placeholder="#2563EB"
            />
          </div>
          {fieldError("brand_color") && (
            <p className="text-xs text-destructive">{fieldError("brand_color")}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="website_url">Website URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="website_url"
            name="website_url"
            type="url"
            defaultValue={client?.website_url ?? ""}
            placeholder="https://clientbrand.com"
          />
          {fieldError("website_url") && (
            <p className="text-xs text-destructive">{fieldError("website_url")}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="instagram_url">Instagram URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="instagram_url"
            name="instagram_url"
            type="url"
            defaultValue={client?.instagram_url ?? ""}
            placeholder="https://instagram.com/..."
          />
          {fieldError("instagram_url") && (
            <p className="text-xs text-destructive">{fieldError("instagram_url")}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="tiktok_url">TikTok URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="tiktok_url"
            name="tiktok_url"
            type="url"
            defaultValue={client?.tiktok_url ?? ""}
            placeholder="https://tiktok.com/..."
          />
          {fieldError("tiktok_url") && (
            <p className="text-xs text-destructive">{fieldError("tiktok_url")}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="youtube_url">YouTube URL <span className="text-muted-foreground">(optional)</span></Label>
          <Input
            id="youtube_url"
            name="youtube_url"
            type="url"
            defaultValue={client?.youtube_url ?? ""}
            placeholder="https://youtube.com/@..."
          />
          {fieldError("youtube_url") && (
            <p className="text-xs text-destructive">{fieldError("youtube_url")}</p>
          )}
        </div>
      </div>

      <div className="space-y-3">
        <Label>Services</Label>
        <ServiceMultiSelect services={services} value={selectedServices} onChange={setSelectedServices} />
        {fieldError("services") && <p className="text-xs text-destructive">{fieldError("services")}</p>}
      </div>

      <div className="space-y-4 rounded-2xl border border-border p-5">
        <div>
          <h3 className="font-semibold">Case Study</h3>
          <p className="text-sm text-muted-foreground">
            Optional. Fill in as much or as little as you like — shown on the client&apos;s page
            as a Challenge → Strategy → Production → Result flow.
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="case_study_challenge">
            Challenge <span className="text-muted-foreground">(optional)</span>
          </Label>
          <Textarea
            id="case_study_challenge"
            name="case_study_challenge"
            defaultValue={client?.case_study_challenge ?? ""}
            placeholder="What problem or situation did the client come to us with?"
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="case_study_strategy">
            Strategy <span className="text-muted-foreground">(optional)</span>
          </Label>
          <Textarea
            id="case_study_strategy"
            name="case_study_strategy"
            defaultValue={client?.case_study_strategy ?? ""}
            placeholder="What approach did we take — content pillars, tone of voice, positioning?"
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="case_study_production">
            Production <span className="text-muted-foreground">(optional)</span>
          </Label>
          <Textarea
            id="case_study_production"
            name="case_study_production"
            defaultValue={client?.case_study_production ?? ""}
            placeholder="How did we execute it — the shoot, the formats, the rollout?"
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="case_study_result">
            Result <span className="text-muted-foreground">(optional)</span>
          </Label>
          <Textarea
            id="case_study_result"
            name="case_study_result"
            defaultValue={client?.case_study_result ?? ""}
            placeholder="What changed — reach, engagement, growth, anything measurable or notable?"
            rows={3}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="city">
            City <span className="text-muted-foreground">(optional — used on the admin dashboard map)</span>
          </Label>
          <Input id="city" name="city" defaultValue={client?.city ?? ""} placeholder="e.g. Yogyakarta" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="whatsapp_number">WhatsApp Number (optional)</Label>
          <Input
            id="whatsapp_number"
            name="whatsapp_number"
            defaultValue={client?.whatsapp_number ?? ""}
            placeholder="0812..."
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="space-y-2">
          <Label>Status</Label>
          <Select value={status} onValueChange={(v) => setStatus(v as ClientStatus)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CLIENT_STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  {STATUS_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="sort_order">
            Portfolio Order <span className="text-muted-foreground">(lower shows first)</span>
          </Label>
          <Input
            id="sort_order"
            name="sort_order"
            type="number"
            defaultValue={client?.sort_order ?? 0}
          />
        </div>

        <div className="flex items-end pb-2.5">
          <label className="flex cursor-pointer items-center gap-2.5 text-sm font-medium">
            <Checkbox checked={featured} onCheckedChange={(c) => setFeatured(c === true)} />
            Featured (larger card in Portfolio + shown in Trusted By strip)
          </label>
        </div>
      </div>

      <SubmitButton isEdit={Boolean(client)} />
    </form>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Save Client"}
    </Button>
  );
}
