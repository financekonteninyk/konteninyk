"use client";

import * as React from "react";
import { Plus, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";

interface TaxonomyItem {
  id: string;
  name: string;
}

interface TaxonomyManagerProps {
  title: string;
  description: string;
  items: TaxonomyItem[];
  onAdd: (name: string) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
}

export function TaxonomyManager({ title, description, items: initialItems, onAdd, onDelete }: TaxonomyManagerProps) {
  const [items, setItems] = React.useState(initialItems);
  const [newName, setNewName] = React.useState("");
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    const trimmed = newName.trim();
    if (!trimmed) return;

    setIsAdding(true);
    const result = await onAdd(trimmed);
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    if (!items.some((i) => i.name.toLowerCase() === trimmed.toLowerCase())) {
      setItems((prev) => [...prev, { id: crypto.randomUUID(), name: trimmed }].sort((a, b) => a.name.localeCompare(b.name)));
    }
    setNewName("");
    toast.success(`"${trimmed}" added.`);
  }

  async function handleDelete(item: TaxonomyItem) {
    setDeletingId(item.id);
    const result = await onDelete(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
    toast.success(`"${item.name}" removed.`);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder={`Add a new ${title.toLowerCase().replace(/s$/, "")}...`}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAdd();
              }
            }}
          />
          <Button type="button" onClick={handleAdd} disabled={isAdding || !newName.trim()}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add
          </Button>
        </div>

        {items.length === 0 ? (
          <EmptyState title={`No ${title.toLowerCase()} yet`} description="Add your first one above." />
        ) : (
          <div className="flex flex-wrap gap-2">
            {items.map((item) => (
              <Badge key={item.id} variant="secondary" className="gap-1.5 py-1.5 pl-3 pr-1.5 text-sm">
                {item.name}
                <button
                  type="button"
                  onClick={() => handleDelete(item)}
                  disabled={deletingId === item.id}
                  aria-label={`Remove ${item.name}`}
                  className="flex h-4 w-4 items-center justify-center rounded-full transition-colors hover:bg-destructive hover:text-destructive-foreground"
                >
                  {deletingId === item.id ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <X className="h-3 w-3" />
                  )}
                </button>
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
