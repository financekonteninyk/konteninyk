"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { ContentCalendar } from "@/types/calendar";
import type { CalendarActionState } from "@/lib/actions/calendar";
import type { Client } from "@/types/client";

const COLOR_PRESETS = ["#6075F1", "#F15760", "#22C55E", "#F59E0B", "#A855F7", "#EC4899"];

interface CalendarSettingsFormProps {
  calendar?: ContentCalendar;
  action: (state: CalendarActionState, formData: FormData) => Promise<CalendarActionState>;
  existingClients?: Pick<Client, "id" | "name" | "logo_url" | "whatsapp_number">[];
}

const initialState: CalendarActionState = {};

export function CalendarSettingsForm({ calendar, action, existingClients = [] }: CalendarSettingsFormProps) {
  const [state, formAction] = useActionState(action, initialState);
  const [clientId, setClientId] = React.useState<string | null>(calendar?.client_id ?? null);
  const [clientName, setClientName] = React.useState(calendar?.client_name ?? "");
  const [logoUrl, setLogoUrl] = React.useState(calendar?.client_logo_url ?? "");
  const [color, setColor] = React.useState(calendar?.background_color ?? "");

  function handlePickExistingClient(id: string) {
    if (id === "none") {
      setClientId(null);
      return;
    }
    const match = existingClients.find((c) => c.id === id);
    if (!match) return;
    setClientId(id);
    setClientName(match.name);
    setLogoUrl(match.logo_url ?? "");
  }

  return (
    <div className="space-y-6">
      {state.error && (
        <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>
      )}

      <form action={formAction} className="space-y-5">
        <input type="hidden" name="client_id" value={clientId ?? ""} />

        {existingClients.length > 0 && (
          <div className="space-y-2 rounded-2xl border border-border bg-secondary/30 p-4">
            <Label className="flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              Pilih dari Klien yang Sudah Ada (opsional)
            </Label>
            <p className="text-xs text-muted-foreground">Otomatis isi nama & logo dari data klien kamu — tetap bisa diedit manual di bawah.</p>
            <Select value={clientId ?? "none"} onValueChange={handlePickExistingClient}>
              <SelectTrigger><SelectValue placeholder="Pilih klien..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— Isi manual —</SelectItem>
                {existingClients.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="client_name">Nama Klien / Judul Kalender</Label>
          <Input
            id="client_name"
            name="client_name"
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            placeholder="cth. Falisha Laundry"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="client_logo_url">URL Logo Klien (opsional)</Label>
          <Input
            id="client_logo_url"
            name="client_logo_url"
            value={logoUrl}
            onChange={(e) => setLogoUrl(e.target.value)}
            placeholder="Tempel link gambar logo, atau pilih klien di atas"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="page_title">Judul Halaman (opsional)</Label>
          <p className="text-xs text-muted-foreground">
            Teks "Kalender Konten" yang tampil di halaman klien — ganti kalau kamu mau istilah lain.
          </p>
          <Input id="page_title" name="page_title" defaultValue={calendar?.page_title ?? ""} placeholder="cth. Jadwal Konten, Rencana Konten" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="whatsapp_number">Nomor WhatsApp (opsional)</Label>
          <p className="text-xs text-muted-foreground">
            Kalau diisi, tombol WhatsApp muncul di halaman klien biar mereka bisa langsung hubungi kamu.
          </p>
          <Input id="whatsapp_number" name="whatsapp_number" defaultValue={calendar?.whatsapp_number ?? ""} placeholder="cth. https://wa.me/62812xxxxxxx" />
        </div>

        <div className="space-y-2">
          <Label>Durasi Kerja Sama (opsional)</Label>
          <p className="text-xs text-muted-foreground">
            Kalau diisi, muncul hitung mundur sisa hari kerja sama di halaman klien.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <Input type="date" name="contract_start_date" defaultValue={calendar?.contract_start_date ?? ""} />
            <Input type="date" name="contract_end_date" defaultValue={calendar?.contract_end_date ?? ""} />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Catatan (opsional)</Label>
          <p className="text-xs text-muted-foreground">Catatan bebas — muncul di halaman klien.</p>
          <Textarea id="notes" name="notes" defaultValue={calendar?.notes ?? ""} rows={3} placeholder="cth. Deadline pembayaran tiap tanggal 1, atau catatan lain." />
        </div>

        <div className="space-y-2">
          <Label htmlFor="strategy_title">Judul Bagian Strategi (opsional)</Label>
          <p className="text-xs text-muted-foreground">Default-nya "Strategi & Arah Konten" — ganti kalau mau istilah lain.</p>
          <Input id="strategy_title" name="strategy_title" defaultValue={calendar?.strategy_title ?? ""} placeholder="Strategi & Arah Konten" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="strategy_note">Catatan Strategi (opsional)</Label>
          <Textarea
            id="strategy_note"
            name="strategy_note"
            defaultValue={calendar?.strategy_note ?? ""}
            rows={4}
            placeholder="Ringkasan strategi konten untuk klien ini — akan ditampilkan di kalender yang mereka lihat."
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="background_color">Warna Personal Kalender (opsional)</Label>
          <p className="text-xs text-muted-foreground">
            Beri sentuhan personal — warna ini dipakai sebagai aksen di halaman kalender yang dilihat klien.
          </p>
          <div className="flex items-center gap-2">
            <Input
              id="background_color"
              name="background_color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              placeholder="#6075F1"
              className="max-w-[160px]"
            />
            {color && <span className="h-9 w-9 shrink-0 rounded-lg border border-border" style={{ backgroundColor: color }} />}
          </div>
          <div className="flex flex-wrap gap-2 pt-1">
            {COLOR_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                title={preset}
                onClick={() => setColor(preset)}
                className="h-7 w-7 rounded-full border border-border transition-transform hover:scale-110"
                style={{ backgroundColor: preset }}
              />
            ))}
          </div>
        </div>

        <SubmitButton isEdit={Boolean(calendar)} />
      </form>
    </div>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Simpan Perubahan" : "Buat Kalender"}
    </Button>
  );
}
