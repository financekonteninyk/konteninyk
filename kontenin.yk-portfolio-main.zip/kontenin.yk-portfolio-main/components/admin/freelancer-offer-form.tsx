"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Printer } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChipInput } from "@/components/admin/chip-input";
import { FreelancerOfferPreview } from "@/components/admin/freelancer-offer-preview";
import { OFFER_STATUSES, OFFER_STATUS_LABELS } from "@/types/documents";
import type { FreelancerOffer, OfferStatus } from "@/types/documents";
import type { DocActionState } from "@/lib/actions/documents";
import type { SiteSettings } from "@/types/settings";

interface FreelancerOfferFormProps {
  offer?: FreelancerOffer;
  action: (state: DocActionState, formData: FormData) => Promise<DocActionState>;
  settings: SiteSettings;
}

const initialState: DocActionState = {};

function genOfferNumber(): string {
  const now = new Date();
  return `OFR-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${Math.floor(1000 + Math.random() * 9000)}`;
}

const JOB_TITLE_SUGGESTIONS = ["Design Carousel", "Video Editing", "Motion Graphic", "Photography", "Scriptwriting", "Voice Over", "Videography", "Social Media Management"];

export function FreelancerOfferForm({ offer, action, settings }: FreelancerOfferFormProps) {
  const [state, formAction] = useActionState(action, initialState);
  const [offerNumber, setOfferNumber] = React.useState(offer?.offer_number ?? genOfferNumber());
  const [status, setStatus] = React.useState<OfferStatus>(offer?.status ?? "draft");

  const [freelancerName, setFreelancerName] = React.useState(offer?.freelancer_name ?? "");
  const [jobTitle, setJobTitle] = React.useState(offer?.job_title ?? "");
  const [price, setPrice] = React.useState(offer?.price ?? 0);
  const [specifications, setSpecifications] = React.useState(offer?.specifications ?? "");
  const [projectDeadline, setProjectDeadline] = React.useState(offer?.project_deadline ?? "");

  return (
    <div className="grid grid-cols-1 gap-8 xl:grid-cols-[1.05fr_0.95fr] xl:items-start">
      <form action={formAction} className="min-w-0 space-y-6">
        <input type="hidden" name="offer_number" value={offerNumber} />
        <input type="hidden" name="status" value={status} />

        {state.error && <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>}

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Offer Number</Label>
            <Input value={offerNumber} onChange={(e) => setOfferNumber(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as OfferStatus)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {OFFER_STATUSES.map((s) => <SelectItem key={s} value={s}>{OFFER_STATUS_LABELS[s]}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="freelancer_name">Freelancer Name</Label>
            <Input id="freelancer_name" name="freelancer_name" value={freelancerName} onChange={(e) => setFreelancerName(e.target.value)} required />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="job_title">Job Title</Label>
            <ChipInput id="job_title" name="job_title" value={jobTitle} onChange={setJobTitle} suggestions={JOB_TITLE_SUGGESTIONS} placeholder="e.g. Design Carousel" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="price">Offered Rate (IDR)</Label>
            <Input id="price" name="price" type="number" min={0} value={price} onChange={(e) => setPrice(Number(e.target.value) || 0)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="project_deadline">Project Deadline</Label>
            <Input id="project_deadline" name="project_deadline" type="date" value={projectDeadline} onChange={(e) => setProjectDeadline(e.target.value)} />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="specifications">Job Description & Specifications</Label>
          <Textarea
            id="specifications"
            name="specifications"
            value={specifications}
            onChange={(e) => setSpecifications(e.target.value)}
            rows={6}
            placeholder={"e.g. Design 5 carousel slides for Instagram, following the brand's visual guidelines.\nFormat: 1080x1350px, PSD source file included."}
          />
        </div>

        <SubmitButton isEdit={Boolean(offer)} />
      </form>

      <div className="min-w-0 xl:sticky xl:top-8">
        {offer && (
          <div className="mb-3 flex gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/admin/dashboard/agreements/offers/${offer.id}/print`} target="_blank">
                <Printer className="h-3.5 w-3.5" />
                Print / PDF
              </Link>
            </Button>
          </div>
        )}
        <FreelancerOfferPreview
          offerNumber={offerNumber}
          freelancerName={freelancerName}
          jobTitle={jobTitle}
          price={price}
          specifications={specifications}
          projectDeadline={projectDeadline}
          companyName={settings.invoice_company_name || "Kontenin.yk"}
          companyLogoUrl={settings.site_logo_url}
        />
      </div>
    </div>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Create Offer"}
    </Button>
  );
}
