"use client";

import * as React from "react";
import { Plus, Loader2, X, Ruler } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { addEditingStandardAction, deleteEditingStandardAction } from "@/lib/actions/tools";
import type { EditingStandard } from "@/types/tools";

export function EditingStandardsWidget({ items: initialItems }: { items: EditingStandard[] }) {
  const [items, setItems] = React.useState(initialItems);
  const [category, setCategory] = React.useState("");
  const [label, setLabel] = React.useState("");
  const [value, setValue] = React.useState("");
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!category.trim() || !label.trim() || !value.trim()) return;
    setIsAdding(true);
    const result = await addEditingStandardAction(category.trim(), label.trim(), value.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        category: category.trim(),
        label: label.trim(),
        value: value.trim(),
        sort_order: 0,
        created_at: new Date().toISOString(),
      },
    ]);
    setCategory("");
    setLabel("");
    setValue("");
  }

  async function handleDelete(item: EditingStandard) {
    setDeletingId(item.id);
    const result = await deleteEditingStandardAction(item.id);
    setDeletingId(null);
    if (result.error) {
      toast.error(result.error);
      return;
    }
    setItems((prev) => prev.filter((i) => i.id !== item.id));
  }

  const grouped = items.reduce<Record<string, EditingStandard[]>>((acc, item) => {
    const existing = acc[item.category];
    acc[item.category] = existing ? [...existing, item] : [item];
    return acc;
  }, {});

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Ruler className="h-4 w-4" />
          Editing Standards
        </CardTitle>
        <CardDescription>Reference specs for the team — file sizes, color codes, export settings.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Category — e.g. Video Export" />
          <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Label — e.g. Reels Format" />
          <div className="flex gap-2">
            <Input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Value — e.g. MP4, 1080x1920" />
            <Button
              type="button"
              size="icon"
              className="shrink-0"
              onClick={handleAdd}
              disabled={isAdding || !category.trim() || !label.trim() || !value.trim()}
            >
              {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {Object.keys(grouped).length === 0 ? (
          <p className="text-sm text-muted-foreground">No standards added yet — add your first spec above.</p>
        ) : (
          <div className="space-y-4">
            {Object.entries(grouped).map(([cat, specs]) => (
              <div key={cat}>
                <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{cat}</p>
                <div className="space-y-1">
                  {specs.map((spec) => (
                    <div key={spec.id} className="group flex items-center justify-between gap-2 rounded-lg px-1.5 py-1 hover:bg-secondary/50">
                      <span className="text-sm">
                        <span className="font-medium">{spec.label}:</span>{" "}
                        <span className="text-muted-foreground">{spec.value}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDelete(spec)}
                        disabled={deletingId === spec.id}
                        aria-label="Remove"
                        className="shrink-0 text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                      >
                        {deletingId === spec.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
