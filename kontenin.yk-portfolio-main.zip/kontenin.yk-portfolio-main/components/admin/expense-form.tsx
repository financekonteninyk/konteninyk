"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Printer } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ExpensePreview } from "@/components/admin/expense-preview";
import { ChipInput } from "@/components/admin/chip-input";
import { EXPENSE_TYPES, EXPENSE_TYPE_LABELS } from "@/types/documents";
import type { Expense, ExpenseType } from "@/types/documents";
import type { DocActionState } from "@/lib/actions/documents";
import type { SiteSettings } from "@/types/settings";

interface ExpenseFormProps {
  expense?: Expense;
  action: (state: DocActionState, formData: FormData) => Promise<DocActionState>;
  settings: SiteSettings;
  savedSuggestions: {
    category: string[];
    paidTo: string[];
    role: string[];
    paymentMethod: string[];
  };
}

const initialState: DocActionState = {};

function genVoucherNumber(): string {
  const now = new Date();
  return `EXP-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${Math.floor(1000 + Math.random() * 9000)}`;
}

const OPERATIONAL_CATEGORIES = ["Employee Salary", "Freelancer Payment", "Software & Subscriptions", "Marketing & Advertising", "Office & Operational", "Transport", "Other"];
const CAPITAL_CATEGORIES = ["Equipment Investment", "Studio/Office Setup", "Vehicle", "Other Investment"];
const ROLE_SUGGESTIONS = ["Video Editor", "Design Carousel", "Videographer", "Photographer", "Scriptwriter", "Social Media Admin", "Motion Graphic Artist", "Voice Over"];

function mergeSuggestions(staticList: string[], learned: string[]): string[] {
  const seen = new Set<string>();
  const merged: string[] = [];
  for (const item of [...staticList, ...learned]) {
    const key = item.trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    merged.push(item);
  }
  return merged;
}

export function ExpenseForm({ expense, action, settings, savedSuggestions }: ExpenseFormProps) {
  const [state, formAction] = useActionState(action, initialState);
  const [voucherNumber, setVoucherNumber] = React.useState(expense?.voucher_number ?? genVoucherNumber());
  const [expenseType, setExpenseType] = React.useState<ExpenseType>(expense?.expense_type ?? "operational");

  const [paidTo, setPaidTo] = React.useState(expense?.paid_to ?? "");
  const [role, setRole] = React.useState(expense?.role ?? "");
  const [category, setCategory] = React.useState(expense?.category ?? "Employee Salary");
  const [workPeriod, setWorkPeriod] = React.useState(expense?.work_period ?? "");
  const [amount, setAmount] = React.useState(expense?.amount ?? 0);
  const [paymentDate, setPaymentDate] = React.useState(expense?.payment_date ?? new Date().toISOString().slice(0, 10));
  const [paymentMethod, setPaymentMethod] = React.useState(expense?.payment_method ?? "");
  const [transactionCode, setTransactionCode] = React.useState(expense?.transaction_code ?? "");
  const [senderBank, setSenderBank] = React.useState(expense?.sender_bank ?? "");
  const [receiverBank, setReceiverBank] = React.useState(expense?.receiver_bank ?? "");
  const [description, setDescription] = React.useState(expense?.description ?? "");
  const [personalNote, setPersonalNote] = React.useState(expense?.personal_note ?? "");

  const staticCategoryOptions = expenseType === "capital" ? CAPITAL_CATEGORIES : OPERATIONAL_CATEGORIES;
  const categoryOptions = mergeSuggestions(staticCategoryOptions, savedSuggestions.category);
  const paidToOptions = mergeSuggestions([], savedSuggestions.paidTo);
  const roleOptions = mergeSuggestions(ROLE_SUGGESTIONS, savedSuggestions.role);
  const paymentMethodOptions = mergeSuggestions(["Bank Transfer", "Cash", "QRIS"], savedSuggestions.paymentMethod);

  return (
    <div className="grid grid-cols-1 gap-8 xl:grid-cols-[1.05fr_0.95fr] xl:items-start">
      <form action={formAction} className="min-w-0 space-y-6">
        <input type="hidden" name="voucher_number" value={voucherNumber} />
        <input type="hidden" name="expense_type" value={expenseType} />

        {state.error && <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>}

        <div className="space-y-2">
          <Label>Reference Number</Label>
          <Input value={voucherNumber} onChange={(e) => setVoucherNumber(e.target.value)} />
        </div>

        <div className="space-y-2">
          <Label>Expense Type</Label>
          <Select value={expenseType} onValueChange={(v) => setExpenseType(v as ExpenseType)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {EXPENSE_TYPES.map((t) => <SelectItem key={t} value={t}>{EXPENSE_TYPE_LABELS[t]}</SelectItem>)}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Operational = day-to-day running costs (salaries, subscriptions). Capital / Investment =
            money put into assets for the business (cameras, equipment). This is how Finance splits
            your Profit from your Capital.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="paid_to">Paid To</Label>
            <ChipInput id="paid_to" name="paid_to" value={paidTo} onChange={setPaidTo} suggestions={paidToOptions} placeholder="e.g. Budi" required />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="role">Role (optional)</Label>
            <ChipInput id="role" name="role" value={role} onChange={setRole} suggestions={roleOptions} placeholder="e.g. Design Carousel" />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="category">Category</Label>
            <ChipInput id="category" name="category" value={category} onChange={setCategory} suggestions={categoryOptions} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="work_period">Work Period (optional)</Label>
            <Input id="work_period" name="work_period" value={workPeriod} onChange={(e) => setWorkPeriod(e.target.value)} placeholder="e.g. 1 - 31 July 2026" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="amount">Amount (IDR)</Label>
            <Input id="amount" name="amount" type="number" min={0} value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="payment_date">Payment Date</Label>
            <Input id="payment_date" name="payment_date" type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} required />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="payment_method">Payment Method (optional)</Label>
            <ChipInput id="payment_method" name="payment_method" value={paymentMethod} onChange={setPaymentMethod} suggestions={paymentMethodOptions} placeholder="e.g. Bank Transfer" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="transaction_code">Transaction Code (optional)</Label>
            <Input id="transaction_code" name="transaction_code" value={transactionCode} onChange={(e) => setTransactionCode(e.target.value)} placeholder="e.g. TRX20260723002" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sender_bank">Sending Bank (optional)</Label>
            <Input id="sender_bank" name="sender_bank" value={senderBank} onChange={(e) => setSenderBank(e.target.value)} placeholder="e.g. BCA (Kontenin.yk)" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="receiver_bank">Receiving Bank (optional)</Label>
            <Input id="receiver_bank" name="receiver_bank" value={receiverBank} onChange={(e) => setReceiverBank(e.target.value)} placeholder="e.g. BRI (Budi)" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description (optional)</Label>
          <Textarea id="description" name="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="e.g. Editing jasa untuk proyek Bjaya Land bulan Juli" />
        </div>

        <div className="space-y-2 rounded-2xl border border-amber-200 bg-amber-50/40 p-4">
          <Label htmlFor="personal_note">A Personal Note (optional)</Label>
          <p className="text-xs text-muted-foreground">
            Shown prominently on the remittance advice itself — a nice place for a genuine "thank
            you" or "great work this month" when this is a salary or freelancer payment. Leave
            empty for a plain, purely transactional document.
          </p>
          <Textarea
            id="personal_note"
            name="personal_note"
            value={personalNote}
            onChange={(e) => setPersonalNote(e.target.value)}
            rows={2}
            placeholder="e.g. Terima kasih atas kerja keras kamu bulan ini — hasilnya luar biasa! 🎉"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Internal Notes (optional)</Label>
          <Textarea id="notes" name="notes" defaultValue={expense?.notes ?? ""} rows={2} />
        </div>

        <SubmitButton isEdit={Boolean(expense)} />
      </form>

      <div className="min-w-0 xl:sticky xl:top-8">
        {expense && (
          <div className="mb-3 flex gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/admin/dashboard/expenses/${expense.id}/print`} target="_blank">
                <Printer className="h-3.5 w-3.5" />
                Print / PDF
              </Link>
            </Button>
          </div>
        )}
        <ExpensePreview
          voucherNumber={voucherNumber}
          paidTo={paidTo}
          role={role}
          category={category}
          workPeriod={workPeriod}
          description={description}
          personalNote={personalNote}
          amount={amount}
          paymentDate={paymentDate}
          paymentMethod={paymentMethod}
          transactionCode={transactionCode}
          senderBank={senderBank}
          receiverBank={receiverBank}
          companyName={settings.invoice_company_name || "Kontenin.yk"}
          companyLogoUrl={settings.site_logo_url}
        />
      </div>
    </div>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Record Expense"}
    </Button>
  );
}
