"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Plus, X, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import type { PricingCategory, PricingTier, PricingFeature } from "@/types/pricing";
import type { PricingActionState } from "@/lib/actions/pricing";

interface PricingCategoryFormProps {
  category?: PricingCategory;
  action: (state: PricingActionState, formData: FormData) => Promise<PricingActionState>;
}

const initialState: PricingActionState = {};

const EMPTY_FEATURE: PricingFeature = { label: "", value: "true" };
const EMPTY_TIER: PricingTier = { name: "", price: 0, period: null, badge: null, description: null, features: [] };

/** Formats a number with Indonesian thousand separators for display — e.g. 1500000 -> "1.500.000". */
function formatPriceDisplay(value: number): string {
  if (!value) return "";
  return value.toLocaleString("id-ID");
}

/** Strips everything except digits, so "Rp1.500.000", "1,500,000", or "1500000" all parse the same way. */
function parsePriceInput(raw: string): number {
  const digitsOnly = raw.replace(/[^0-9]/g, "");
  return digitsOnly ? Number(digitsOnly) : 0;
}

export function PricingCategoryForm({ category, action }: PricingCategoryFormProps) {
  const [state, formAction] = useActionState(action, initialState);

  const [name, setName] = React.useState(category?.name ?? "");
  const [subtitle, setSubtitle] = React.useState(category?.subtitle ?? "");
  const [isPublished, setIsPublished] = React.useState(category?.is_published ?? true);
  const [tiers, setTiers] = React.useState<PricingTier[]>(
    category?.tiers && category.tiers.length > 0 ? category.tiers : [{ ...EMPTY_TIER }]
  );

  function updateTier(tierIndex: number, patch: Partial<PricingTier>) {
    setTiers((prev) => prev.map((t, i) => (i === tierIndex ? { ...t, ...patch } : t)));
  }

  function addTier() {
    setTiers((prev) => [...prev, { ...EMPTY_TIER, features: [] }]);
  }

  function removeTier(tierIndex: number) {
    setTiers((prev) => (prev.length > 1 ? prev.filter((_, i) => i !== tierIndex) : prev));
  }

  function addFeature(tierIndex: number) {
    setTiers((prev) =>
      prev.map((t, i) => (i === tierIndex ? { ...t, features: [...t.features, { ...EMPTY_FEATURE }] } : t))
    );
  }

  function updateFeature(tierIndex: number, featureIndex: number, patch: Partial<PricingFeature>) {
    setTiers((prev) =>
      prev.map((t, i) =>
        i === tierIndex
          ? { ...t, features: t.features.map((f, j) => (j === featureIndex ? { ...f, ...patch } : f)) }
          : t
      )
    );
  }

  function removeFeature(tierIndex: number, featureIndex: number) {
    setTiers((prev) =>
      prev.map((t, i) => (i === tierIndex ? { ...t, features: t.features.filter((_, j) => j !== featureIndex) } : t))
    );
  }

  /** Copies the feature LABELS from Tier 1, so you don't have to retype row names for every tier in a comparison table. */
  function copyFeatureLabelsFrom(targetTierIndex: number, sourceTierIndex: number) {
    setTiers((prev) => {
      const source = prev[sourceTierIndex];
      if (!source) return prev;
      return prev.map((t, i) =>
        i === targetTierIndex
          ? { ...t, features: source.features.map((f) => ({ label: f.label, value: "false" })) }
          : t
      );
    });
  }

  return (
    <form action={formAction} className="space-y-8">
      <input type="hidden" name="tiers" value={JSON.stringify(tiers)} />
      <input type="hidden" name="is_published" value={String(isPublished)} />

      {state.error && (
        <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>
      )}

      <div className="grid grid-cols-1 gap-4 rounded-2xl border border-border p-5 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">Category Name</Label>
          <Input
            id="name"
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Content Packages, Editing Only"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="subtitle">Subtitle (optional)</Label>
          <Input
            id="subtitle"
            name="subtitle"
            value={subtitle}
            onChange={(e) => setSubtitle(e.target.value)}
            placeholder="e.g. Bantu Brand Kamu Ngonten Lebih Masif"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="sort_order">Display Order</Label>
          <Input id="sort_order" name="sort_order" type="number" defaultValue={category?.sort_order ?? 0} />
        </div>
        <div className="flex items-end pb-2.5">
          <label className="flex cursor-pointer items-center gap-2.5 text-sm font-medium">
            <Checkbox checked={isPublished} onCheckedChange={(c) => setIsPublished(c === true)} />
            Published (visible on the public Pricing page)
          </label>
        </div>
      </div>

      <div className="space-y-6">
        {tiers.map((tier, tierIndex) => (
          <div key={tierIndex} className="space-y-4 rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <GripVertical className="h-4 w-4 text-muted-foreground" />
                Tier {tierIndex + 1}
              </p>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => removeTier(tierIndex)}
                aria-label="Remove tier"
                className="text-muted-foreground hover:text-destructive"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Input
                className="col-span-2 md:col-span-1"
                value={tier.name}
                onChange={(e) => updateTier(tierIndex, { name: e.target.value })}
                placeholder="Tier name — e.g. Starter"
              />
              {/* Was type="number" — the browser's native validation rejected
                  Indonesian-formatted prices like "1.500.000" as invalid
                  (multiple decimal points aren't a valid number to it). Now
                  a text field that displays with thousand separators and
                  strips non-digit characters on input, so "1.500.000",
                  "1,500,000", or "1500000" all work the same. */}
              <Input
                type="text"
                inputMode="numeric"
                value={formatPriceDisplay(tier.price)}
                onChange={(e) => updateTier(tierIndex, { price: parsePriceInput(e.target.value) })}
                placeholder="Price (IDR) — e.g. 1.500.000"
              />
              <Input
                value={tier.period ?? ""}
                onChange={(e) => updateTier(tierIndex, { period: e.target.value || null })}
                placeholder="Period (optional) — e.g. /bulan, /project"
              />
              <Input
                value={tier.badge ?? ""}
                onChange={(e) => updateTier(tierIndex, { badge: e.target.value || null })}
                placeholder="Badge (optional) — e.g. Most Popular"
              />
            </div>
            <Textarea
              value={tier.description ?? ""}
              onChange={(e) => updateTier(tierIndex, { description: e.target.value || null })}
              placeholder='Description (optional) — e.g. "Ideal for: UMKM, bisnis lokal..."'
              rows={2}
            />

            <div className="space-y-2 rounded-xl bg-secondary/40 p-4">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground">Features</Label>
                {tierIndex > 0 && tiers[0]!.features.length > 0 && (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="h-7 text-xs"
                    onClick={() => copyFeatureLabelsFrom(tierIndex, 0)}
                  >
                    Copy row labels from Tier 1
                  </Button>
                )}
              </div>

              {tier.features.map((feature, featureIndex) => (
                <div key={featureIndex} className="grid grid-cols-12 gap-2">
                  <Input
                    className="col-span-6"
                    value={feature.label}
                    onChange={(e) => updateFeature(tierIndex, featureIndex, { label: e.target.value })}
                    placeholder="Feature label — e.g. Cutting & Trimming"
                  />
                  <Input
                    className="col-span-5"
                    value={feature.value}
                    onChange={(e) => updateFeature(tierIndex, featureIndex, { value: e.target.value })}
                    placeholder='"true" = checkmark, "false" = dash, or a value like "4"'
                  />
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    className="col-span-1 text-muted-foreground hover:text-destructive"
                    onClick={() => removeFeature(tierIndex, featureIndex)}
                    aria-label="Remove feature"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}

              <Button type="button" size="sm" variant="outline" onClick={() => addFeature(tierIndex)}>
                <Plus className="h-3.5 w-3.5" />
                Add Feature Row
              </Button>
            </div>
          </div>
        ))}

        <Button type="button" variant="outline" onClick={addTier}>
          <Plus className="h-4 w-4" />
          Add Tier
        </Button>
      </div>

      <SubmitButton isEdit={Boolean(category)} />
    </form>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Create Pricing Category"}
    </Button>
  );
}
