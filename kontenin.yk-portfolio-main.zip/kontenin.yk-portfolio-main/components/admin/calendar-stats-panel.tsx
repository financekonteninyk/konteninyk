import { BarChart3 } from "lucide-react";
import type { ContentCalendarEntry } from "@/types/calendar";

export function CalendarStatsPanel({ entries }: { entries: ContentCalendarEntry[] }) {
  const total = entries.length;
  const approved = entries.filter((e) => e.approval_status === "approved").length;
  const pending = entries.filter((e) => e.approval_status === "pending").length;
  const published = entries.filter((e) => e.status === "published").length;

  if (total === 0) return null;

  return (
    <div className="rounded-2xl border border-border p-4">
      <p className="mb-3 flex items-center gap-1.5 text-sm font-semibold">
        <BarChart3 className="h-4 w-4" />
        Sekilas
      </p>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <p className="text-2xl font-bold tracking-tight">{total}</p>
          <p className="text-[11px] text-muted-foreground">Total Konten</p>
        </div>
        <div>
          <p className="text-2xl font-bold tracking-tight text-emerald-600">{published}</p>
          <p className="text-[11px] text-muted-foreground">Sudah Tayang</p>
        </div>
        <div>
          <p className="text-2xl font-bold tracking-tight text-primary">{approved}</p>
          <p className="text-[11px] text-muted-foreground">Disetujui</p>
        </div>
        <div>
          <p className="text-2xl font-bold tracking-tight text-muted-foreground">{pending}</p>
          <p className="text-[11px] text-muted-foreground">Menunggu Review</p>
        </div>
      </div>
    </div>
  );
}
