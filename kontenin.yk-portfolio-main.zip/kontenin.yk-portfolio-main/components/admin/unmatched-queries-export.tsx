"use client";

import { Download, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { UnmatchedQuery } from "@/types/chat";

function escapeCsvField(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

function downloadCsv(items: UnmatchedQuery[]) {
  const header = "question,date,time,locale";
  const lines = items.map((item) => {
    const date = new Date(item.created_at);
    const dateStr = date.toLocaleDateString("en-CA"); // YYYY-MM-DD
    const timeStr = date.toLocaleTimeString("en-GB"); // HH:MM:SS
    return [
      escapeCsvField(item.query_text),
      escapeCsvField(dateStr),
      escapeCsvField(timeStr),
      escapeCsvField(item.locale ?? ""),
    ].join(",");
  });

  const csv = [header, ...lines].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `kontenin-unanswered-questions-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

interface UnmatchedQueriesExportProps {
  items: UnmatchedQuery[];
  onClearAll: () => Promise<{ error?: string }>;
}

export function UnmatchedQueriesExport({ items, onClearAll }: UnmatchedQueriesExportProps) {
  async function handleClearAll() {
    if (items.length === 0) return;
    if (!confirm(`Clear all ${items.length} logged questions? This can't be undone.`)) return;

    const result = await onClearAll();
    if (result.error) {
      toast.error(result.error);
      return;
    }
    toast.success("Cleared.");
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Unanswered Questions</CardTitle>
        <CardDescription>
          Questions CS Kontenin.yk couldn't match to an answer, logged with the date they came in.
          Download the list, use it to write new rows for your Q&A CSV, then clear the log.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap items-center gap-3">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">{items.length}</span> question
          {items.length === 1 ? "" : "s"} logged
        </p>
        <div className="ml-auto flex gap-2">
          <Button type="button" size="sm" variant="outline" onClick={() => downloadCsv(items)} disabled={items.length === 0}>
            <Download className="h-3.5 w-3.5" />
            Download CSV
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={handleClearAll}
            disabled={items.length === 0}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Clear All
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
