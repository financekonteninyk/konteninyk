import Image from "next/image";
import Link from "next/link";
import { ImageOff, Pencil, Eye, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DeleteVideoButton } from "@/components/admin/delete-video-button";
import type { Video } from "@/types/video";
import { PLATFORM_LABELS } from "@/types/video";

export function AdminVideoCard({ video, clientId }: { video: Video; clientId: string }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
      <div className={`relative w-full overflow-hidden bg-muted ${video.content_type === "carousel" ? "aspect-[4/5]" : "aspect-[9/16]"}`}>
        {video.thumbnail_url ? (
          <Image
            src={video.thumbnail_url}
            alt={video.title ?? "Video thumbnail"}
            fill
            sizes="(max-width: 768px) 45vw, 220px"
            className="object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <ImageOff className="h-8 w-8" />
          </div>
        )}

        <div className="absolute inset-0 flex items-start justify-between bg-gradient-to-b from-black/50 via-transparent to-black/60 p-2 opacity-0 transition-opacity group-hover:opacity-100">
          <div className="flex gap-1.5">
            <Button asChild variant="secondary" size="icon" className="h-8 w-8">
              <Link
                href={`/admin/dashboard/clients/${clientId}/videos/${video.id}/edit`}
                aria-label="Edit video"
              >
                <Pencil className="h-3.5 w-3.5" />
              </Link>
            </Button>
          </div>
          <DeleteVideoButton
            videoId={video.id}
            clientId={clientId}
            videoLabel={video.title ?? "this video"}
          />
        </div>

        {video.platform && (
          <Badge className="absolute bottom-2 left-2 bg-background/90 text-foreground shadow-sm">
            {PLATFORM_LABELS[video.platform]}
          </Badge>
        )}

        {video.content_type === "carousel" && (
          <div className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-background/90 px-2 py-1 text-[10px] font-medium text-foreground shadow-sm">
            <Layers className="h-3 w-3" />
            {video.carousel_images.length + 1}
          </div>
        )}
      </div>

      {(video.title || video.views_count != null) && (
        <div className="p-2.5">
          {video.title && <p className="line-clamp-1 text-xs font-medium">{video.title}</p>}
          {video.views_count != null && (
            <div className="mt-1 flex items-center gap-1 text-[11px] text-muted-foreground">
              <Eye className="h-3 w-3" />
              {video.views_count.toLocaleString()}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
