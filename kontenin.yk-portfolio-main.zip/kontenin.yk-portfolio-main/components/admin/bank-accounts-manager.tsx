"use client";

import * as React from "react";
import { Plus, Loader2, X, CreditCard } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { addBankAccountAction, deleteBankAccountAction } from "@/lib/actions/tools";
import type { InvoiceBankAccount } from "@/types/tools";

export function BankAccountsManager({ items: initialItems }: { items: InvoiceBankAccount[] }) {
  const [items, setItems] = React.useState(initialItems);
  const [bankName, setBankName] = React.useState("");
  const [accountNumber, setAccountNumber] = React.useState("");
  const [accountHolder, setAccountHolder] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!bankName.trim() || !accountNumber.trim() || !accountHolder.trim()) return;

    setIsAdding(true);
    const result = await addBankAccountAction(bankName.trim(), accountNumber.trim(), accountHolder.trim(), description.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      {
        id: crypto.randomUUID(),
        bank_name: bankName.trim(),
        account_number: accountNumber.trim(),
        account_holder: accountHolder.trim(),
        description: description.trim() || null,
        created_at: new Date().toISOString(),
      },
      ...prev,
    ]);
    setBankName("");
    setAccountNumber("");
    setAccountHolder("");
    setDescription("");
    toast.success("Bank account added.");
  }

  async function handleDelete(item: InvoiceBankAccount) {
    setDeletingId(item.id);
    const result = await deleteBankAccountAction(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add Gateway</CardTitle>
          <CardDescription>Bank details that appear on invoices as remittance instructions.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="Bank/Platform Name — e.g. BCA" />
            <Input value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} placeholder="Account Number" />
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Input value={accountHolder} onChange={(e) => setAccountHolder(e.target.value)} placeholder="Account Holder Name" />
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description (optional) — e.g. Primary IDR Gateway" />
          </div>
          <Button
            type="button"
            size="sm"
            onClick={handleAdd}
            disabled={isAdding || !bankName.trim() || !accountNumber.trim() || !accountHolder.trim()}
          >
            {isAdding ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            Save Account
          </Button>
        </CardContent>
      </Card>

      {items.length === 0 ? (
        <EmptyState title="No bank accounts yet" description="Add one above to use it on invoices." />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {items.map((item) => (
            <div key={item.id} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <CreditCard className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-medium">{item.bank_name}</p>
                <p className="text-sm text-muted-foreground">{item.account_number}</p>
                <p className="text-xs text-muted-foreground">{item.account_holder}</p>
                {item.description && <p className="mt-1 text-xs text-muted-foreground">{item.description}</p>}
              </div>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => handleDelete(item)}
                disabled={deletingId === item.id}
                aria-label={`Remove ${item.bank_name}`}
                className="shrink-0 text-muted-foreground hover:text-destructive"
              >
                {deletingId === item.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
