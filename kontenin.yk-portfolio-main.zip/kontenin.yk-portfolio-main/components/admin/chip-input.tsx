"use client";

import { Input } from "@/components/ui/input";

interface ChipInputProps {
  id?: string;
  name?: string;
  value: string;
  onChange: (value: string) => void;
  suggestions: string[];
  placeholder?: string;
  required?: boolean;
}

export function ChipInput({ id, name, value, onChange, suggestions, placeholder, required }: ChipInputProps) {
  return (
    <div className="space-y-2">
      <Input
        id={id}
        name={name}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
      />
      <div className="flex flex-wrap gap-1.5">
        {suggestions.map((s) => {
          const active = s.toLowerCase() === value.trim().toLowerCase();
          return (
            <button
              key={s}
              type="button"
              onClick={() => onChange(s)}
              className={`rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                active
                  ? "border-foreground bg-foreground text-background"
                  : "border-border bg-background text-muted-foreground hover:border-foreground/40 hover:text-foreground"
              }`}
            >
              {s}
            </button>
          );
        })}
      </div>
    </div>
  );
}
