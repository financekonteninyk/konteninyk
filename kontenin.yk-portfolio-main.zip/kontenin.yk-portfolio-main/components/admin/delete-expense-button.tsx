"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteExpenseAction } from "@/lib/actions/documents";

export function DeleteExpenseButton({ id, label }: { id: string; label: string }) {
  const router = useRouter();

  return <DeleteButton itemLabel={label} onDelete={() => deleteExpenseAction(id)} onDeleted={() => router.refresh()} />;
}
