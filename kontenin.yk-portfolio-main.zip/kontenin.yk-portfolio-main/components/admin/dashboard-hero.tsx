"use client";

import Image from "next/image";
import { motion } from "framer-motion";

export function DashboardHero({ logoUrl }: { logoUrl: string | null }) {
  return (
    <div className="relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-secondary/60 via-background to-secondary/30 p-8 sm:p-10">
      {/* Subtle grid texture */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.4] [mask-image:radial-gradient(ellipse_60%_60%_at_30%_40%,black,transparent)]"
        style={{
          backgroundImage:
            "linear-gradient(hsl(var(--foreground)/0.06) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--foreground)/0.06) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      {/* Animated glow blobs */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -left-16 -top-16 h-64 w-64 rounded-full bg-primary/20 blur-3xl"
        animate={{ x: [0, 30, 0], y: [0, 20, 0] }}
        transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -bottom-20 right-0 h-72 w-72 rounded-full bg-primary/10 blur-3xl"
        animate={{ x: [0, -30, 0], y: [0, -20, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />

      <div className="relative flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-5">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="relative flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-border bg-background shadow-lg sm:h-20 sm:w-20"
          >
            {logoUrl ? (
              <Image src={logoUrl} alt="Kontenin.yk" fill sizes="80px" className="object-contain p-2" />
            ) : (
              <span className="text-2xl font-black text-primary">K</span>
            )}
          </motion.div>
          <div>
            <p className="eyebrow text-xs text-muted-foreground">Command Center</p>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Kontenin.yk Dashboard</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Clients, content, invoices, and everything else — all in one place.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
