"use client";

import * as React from "react";
import { Plus, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { SERVICE_STAGES, SERVICE_STAGE_LABELS } from "@/types/settings";
import type { Service, ServiceStage } from "@/types/settings";

interface ServiceManagerProps {
  services: Service[];
  onAdd: (name: string, stage: ServiceStage) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
  onUpdateStage: (id: string, stage: ServiceStage) => Promise<{ error?: string }>;
}

export function ServiceManager({ services: initialServices, onAdd, onDelete, onUpdateStage }: ServiceManagerProps) {
  const [services, setServices] = React.useState(initialServices);
  const [newName, setNewName] = React.useState("");
  const [newStage, setNewStage] = React.useState<ServiceStage>("production");
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    const trimmed = newName.trim();
    if (!trimmed) return;

    setIsAdding(true);
    const result = await onAdd(trimmed, newStage);
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    if (!services.some((s) => s.name.toLowerCase() === trimmed.toLowerCase())) {
      setServices((prev) =>
        [
          ...prev,
          { id: crypto.randomUUID(), name: trimmed, stage: newStage, created_at: new Date().toISOString() },
        ].sort((a, b) => a.name.localeCompare(b.name))
      );
    }
    setNewName("");
    toast.success(`"${trimmed}" added.`);
  }

  async function handleDelete(service: Service) {
    setDeletingId(service.id);
    const result = await onDelete(service.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setServices((prev) => prev.filter((s) => s.id !== service.id));
    toast.success(`"${service.name}" removed.`);
  }

  async function handleStageChange(service: Service, stage: ServiceStage) {
    setServices((prev) => prev.map((s) => (s.id === service.id ? { ...s, stage } : s)));
    const result = await onUpdateStage(service.id, stage);
    if (result.error) {
      toast.error(result.error);
      setServices((prev) => prev.map((s) => (s.id === service.id ? { ...s, stage: service.stage } : s)));
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Services</CardTitle>
        <CardDescription>
          Service offerings, grouped by stage of the Growth Loop System (Strategy, Production,
          Growth Loop).
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Add a new service..."
            className="flex-1"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAdd();
              }
            }}
          />
          <Select value={newStage} onValueChange={(v) => setNewStage(v as ServiceStage)}>
            <SelectTrigger className="sm:w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SERVICE_STAGES.map((stage) => (
                <SelectItem key={stage} value={stage}>
                  {SERVICE_STAGE_LABELS[stage]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="button" onClick={handleAdd} disabled={isAdding || !newName.trim()}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add
          </Button>
        </div>

        {services.length === 0 ? (
          <EmptyState title="No services yet" description="Add your first one above." />
        ) : (
          <div className="space-y-2">
            {services.map((service) => (
              <div
                key={service.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-border px-3.5 py-2.5"
              >
                <span className="truncate text-sm font-medium">{service.name}</span>
                <div className="flex items-center gap-2">
                  <Select
                    value={service.stage}
                    onValueChange={(v) => handleStageChange(service, v as ServiceStage)}
                  >
                    <SelectTrigger className="h-8 w-36 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SERVICE_STAGES.map((stage) => (
                        <SelectItem key={stage} value={stage}>
                          {SERVICE_STAGE_LABELS[stage]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <button
                    type="button"
                    onClick={() => handleDelete(service)}
                    disabled={deletingId === service.id}
                    aria-label={`Remove ${service.name}`}
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-destructive hover:text-destructive-foreground"
                  >
                    {deletingId === service.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <X className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
