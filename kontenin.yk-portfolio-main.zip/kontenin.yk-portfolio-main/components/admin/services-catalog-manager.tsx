"use client";

import * as React from "react";
import { Plus, Loader2, X, Tag } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { addInvoiceServiceAction, deleteInvoiceServiceAction } from "@/lib/actions/tools";
import type { InvoiceService } from "@/types/tools";

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);
}

export function ServicesCatalogManager({ items: initialItems }: { items: InvoiceService[] }) {
  const [items, setItems] = React.useState(initialItems);
  const [name, setName] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [category, setCategory] = React.useState("");
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!name.trim() || !price) return;
    setIsAdding(true);
    const result = await addInvoiceServiceAction(name.trim(), Number(price), category.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      { id: crypto.randomUUID(), name: name.trim(), price: Number(price), category: category.trim() || null, created_at: new Date().toISOString() },
    ]);
    setName("");
    setPrice("");
    setCategory("");
  }

  async function handleDelete(item: InvoiceService) {
    setDeletingId(item.id);
    const result = await deleteInvoiceServiceAction(item.id);
    setDeletingId(null);
    if (result.error) {
      toast.error(result.error);
      return;
    }
    setItems((prev) => prev.filter((i) => i.id !== item.id));
  }

  const grouped = items.reduce<Record<string, InvoiceService[]>>((acc, item) => {
    const key = item.category || "General";
    const existing = acc[key];
    acc[key] = existing ? [...existing, item] : [item];
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add a Service</CardTitle>
          <CardDescription>
            Build a price list once — pick from it when creating invoices instead of retyping.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Service name — e.g. Editing Only - Basic" />
            <Input value={price} onChange={(e) => setPrice(e.target.value)} type="number" min={0} placeholder="Price (IDR)" />
            <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Category (optional) — e.g. Editing Only" />
          </div>
          <Button type="button" size="sm" onClick={handleAdd} disabled={isAdding || !name.trim() || !price}>
            {isAdding ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            Add Service
          </Button>
        </CardContent>
      </Card>

      {Object.keys(grouped).length === 0 ? (
        <p className="text-sm text-muted-foreground">No services in your price list yet — add your first one above.</p>
      ) : (
        Object.entries(grouped).map(([cat, services]) => (
          <div key={cat}>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              <Tag className="h-3 w-3" />
              {cat}
            </h3>
            <div className="space-y-1">
              {services.map((service) => (
                <div key={service.id} className="group flex items-center justify-between gap-2 rounded-lg border border-border px-3 py-2">
                  <span className="text-sm font-medium">{service.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{formatIDR(service.price)}</span>
                    <button
                      type="button"
                      onClick={() => handleDelete(service)}
                      disabled={deletingId === service.id}
                      aria-label={`Remove ${service.name}`}
                      className="text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                    >
                      {deletingId === service.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
