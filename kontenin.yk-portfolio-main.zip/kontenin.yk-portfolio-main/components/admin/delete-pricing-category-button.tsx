"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deletePricingCategoryAction } from "@/lib/actions/pricing";

export function DeletePricingCategoryButton({ id, name }: { id: string; name: string }) {
  const router = useRouter();

  return (
    <DeleteButton
      itemLabel={name}
      onDelete={() => deletePricingCategoryAction(id)}
      onDeleted={() => router.refresh()}
    />
  );
}
