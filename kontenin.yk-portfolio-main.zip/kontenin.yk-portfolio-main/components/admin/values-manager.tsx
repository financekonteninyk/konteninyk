"use client";

import * as React from "react";
import { Plus, Loader2, X, Pencil, Check } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import type { Value } from "@/types/about";

interface ValuesManagerProps {
  items: Value[];
  onAdd: (title: string, description: string) => Promise<{ error?: string }>;
  onUpdate: (id: string, title: string, description: string) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
}

interface Draft {
  title: string;
  description: string;
}

const EMPTY_DRAFT: Draft = { title: "", description: "" };

export function ValuesManager({ items: initialItems, onAdd, onUpdate, onDelete }: ValuesManagerProps) {
  const [items, setItems] = React.useState(initialItems);
  const [newItem, setNewItem] = React.useState<Draft>(EMPTY_DRAFT);
  const [isAdding, setIsAdding] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [editDraft, setEditDraft] = React.useState<Draft>(EMPTY_DRAFT);
  const [isSaving, setIsSaving] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!newItem.title.trim()) return;
    setIsAdding(true);
    const result = await onAdd(newItem.title.trim(), newItem.description.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        title: newItem.title.trim(),
        description: newItem.description.trim() || null,
        sort_order: prev.length,
        created_at: new Date().toISOString(),
      },
    ]);
    setNewItem(EMPTY_DRAFT);
    toast.success("Value added.");
  }

  function startEdit(item: Value) {
    setEditingId(item.id);
    setEditDraft({ title: item.title, description: item.description ?? "" });
  }

  async function handleSaveEdit(id: string) {
    if (!editDraft.title.trim()) return;
    setIsSaving(true);
    const result = await onUpdate(id, editDraft.title.trim(), editDraft.description.trim());
    setIsSaving(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) =>
      prev.map((i) =>
        i.id === id
          ? { ...i, title: editDraft.title.trim(), description: editDraft.description.trim() || null }
          : i
      )
    );
    setEditingId(null);
    toast.success("Value updated.");
  }

  async function handleDelete(item: Value) {
    setDeletingId(item.id);
    const result = await onDelete(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
    toast.success(`"${item.title}" removed.`);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Values</CardTitle>
        <CardDescription>Core brand values, shown on the /about page.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2 rounded-xl border border-dashed border-border p-4">
          <Input
            value={newItem.title}
            onChange={(e) => setNewItem((d) => ({ ...d, title: e.target.value }))}
            placeholder="Value, e.g. Consistency over virality"
          />
          <Textarea
            value={newItem.description}
            onChange={(e) => setNewItem((d) => ({ ...d, description: e.target.value }))}
            placeholder="Description (optional)"
            rows={2}
          />
          <Button type="button" size="sm" onClick={handleAdd} disabled={isAdding || !newItem.title.trim()}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add Value
          </Button>
        </div>

        {items.length === 0 ? (
          <EmptyState title="No values yet" description="Add your first one above." />
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="rounded-xl border border-border p-4">
                {editingId === item.id ? (
                  <div className="space-y-2">
                    <Input
                      value={editDraft.title}
                      onChange={(e) => setEditDraft((d) => ({ ...d, title: e.target.value }))}
                    />
                    <Textarea
                      value={editDraft.description}
                      onChange={(e) => setEditDraft((d) => ({ ...d, description: e.target.value }))}
                      rows={2}
                    />
                    <div className="flex gap-2">
                      <Button type="button" size="sm" onClick={() => handleSaveEdit(item.id)} disabled={isSaving}>
                        {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                        Save
                      </Button>
                      <Button type="button" size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                        <X className="h-3.5 w-3.5" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="font-semibold">{item.title}</h4>
                      {item.description && (
                        <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>
                      )}
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <Button type="button" size="icon" variant="ghost" onClick={() => startEdit(item)} aria-label="Edit">
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDelete(item)}
                        disabled={deletingId === item.id}
                        aria-label="Delete"
                        className="text-muted-foreground hover:text-destructive"
                      >
                        {deletingId === item.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <X className="h-3.5 w-3.5" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
