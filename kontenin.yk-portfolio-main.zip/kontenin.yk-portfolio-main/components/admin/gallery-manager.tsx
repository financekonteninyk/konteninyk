"use client";

import * as React from "react";
import Image from "next/image";
import { Plus, Loader2, X, ImageOff } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { ImageUpload } from "@/components/admin/image-upload";
import { STORAGE_BUCKETS } from "@/lib/constants";
import type { GalleryImage } from "@/types/about";

interface GalleryManagerProps {
  items: GalleryImage[];
  onAdd: (imageUrl: string, caption: string) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
}

export function GalleryManager({ items: initialItems, onAdd, onDelete }: GalleryManagerProps) {
  const [items, setItems] = React.useState(initialItems);
  const [newImageUrl, setNewImageUrl] = React.useState<string | null>(null);
  const [newCaption, setNewCaption] = React.useState("");
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!newImageUrl) return;
    setIsAdding(true);
    const result = await onAdd(newImageUrl, newCaption.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        image_url: newImageUrl,
        caption: newCaption.trim() || null,
        sort_order: prev.length,
        created_at: new Date().toISOString(),
      },
    ]);
    setNewImageUrl(null);
    setNewCaption("");
    toast.success("Image added.");
  }

  async function handleDelete(item: GalleryImage) {
    setDeletingId(item.id);
    const result = await onDelete(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
    toast.success("Image removed.");
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Gallery</CardTitle>
        <CardDescription>Behind-the-scenes photos, shown on the /about page.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-3 rounded-xl border border-dashed border-border p-4">
          <ImageUpload
            label="New photo"
            bucket={STORAGE_BUCKETS.ABOUT_ASSETS}
            value={newImageUrl}
            onChange={setNewImageUrl}
            aspectClassName="aspect-video max-w-xs"
          />
          <Input
            value={newCaption}
            onChange={(e) => setNewCaption(e.target.value)}
            placeholder="Caption (optional)"
          />
          <Button type="button" size="sm" onClick={handleAdd} disabled={isAdding || !newImageUrl}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add to Gallery
          </Button>
        </div>

        {items.length === 0 ? (
          <EmptyState title="No photos yet" description="Add your first one above." />
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {items.map((item) => (
              <div key={item.id} className="group relative overflow-hidden rounded-xl border border-border">
                <div className="relative aspect-video w-full bg-muted">
                  {item.image_url ? (
                    <Image src={item.image_url} alt={item.caption ?? ""} fill sizes="200px" className="object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                      <ImageOff className="h-5 w-5" />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => handleDelete(item)}
                    disabled={deletingId === item.id}
                    aria-label="Remove photo"
                    className="absolute right-1.5 top-1.5 flex h-7 w-7 items-center justify-center rounded-full bg-background/90 text-foreground opacity-0 shadow-sm transition-opacity hover:bg-destructive hover:text-destructive-foreground group-hover:opacity-100"
                  >
                    {deletingId === item.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <X className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
                {item.caption && (
                  <p className="truncate p-2 text-xs text-muted-foreground">{item.caption}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
