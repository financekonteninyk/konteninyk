"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteMouAction } from "@/lib/actions/documents";

export function DeleteMouButton({ id, label }: { id: string; label: string }) {
  const router = useRouter();

  return <DeleteButton itemLabel={label} onDelete={() => deleteMouAction(id)} onDeleted={() => router.refresh()} />;
}
