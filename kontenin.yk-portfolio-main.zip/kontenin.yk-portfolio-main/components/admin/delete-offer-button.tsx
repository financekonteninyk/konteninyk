"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteFreelancerOfferAction } from "@/lib/actions/documents";

export function DeleteOfferButton({ id, label }: { id: string; label: string }) {
  const router = useRouter();

  return <DeleteButton itemLabel={label} onDelete={() => deleteFreelancerOfferAction(id)} onDeleted={() => router.refresh()} />;
}
