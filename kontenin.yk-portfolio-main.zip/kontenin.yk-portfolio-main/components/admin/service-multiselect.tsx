"use client";

import * as React from "react";
import { Plus, Loader2, Check, X } from "lucide-react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addServiceAction } from "@/lib/actions/settings";
import type { Service } from "@/types/settings";

interface ServiceMultiSelectProps {
  services: Service[];
  value: string[];
  onChange: (value: string[]) => void;
}

export function ServiceMultiSelect({ services: initialServices, value, onChange }: ServiceMultiSelectProps) {
  const [services, setServices] = React.useState(initialServices);
  const [adding, setAdding] = React.useState(false);
  const [newName, setNewName] = React.useState("");
  const [isSaving, setIsSaving] = React.useState(false);

  function toggle(name: string, checked: boolean) {
    onChange(checked ? [...value, name] : value.filter((s) => s !== name));
  }

  async function handleAdd() {
    const trimmed = newName.trim();
    if (!trimmed) return;

    setIsSaving(true);
    const result = await addServiceAction(trimmed);
    setIsSaving(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    if (!services.some((s) => s.name.toLowerCase() === trimmed.toLowerCase())) {
      setServices((prev) =>
        [...prev, { id: crypto.randomUUID(), name: trimmed, stage: "production" as const, created_at: new Date().toISOString() }].sort(
          (a, b) => a.name.localeCompare(b.name)
        )
      );
    }
    onChange([...value, trimmed]);
    setNewName("");
    setAdding(false);
    toast.success(`Service "${trimmed}" added.`);
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {services.map((service) => (
          <label
            key={service.id}
            className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-border px-3.5 py-2.5 text-sm transition-colors hover:bg-accent"
          >
            <Checkbox
              checked={value.includes(service.name)}
              onCheckedChange={(checked) => toggle(service.name, checked === true)}
            />
            {service.name}
          </label>
        ))}
      </div>

      {adding ? (
        <div className="flex items-center gap-2">
          <Input
            autoFocus
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="New service name"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAdd();
              }
            }}
          />
          <Button type="button" size="icon" variant="outline" onClick={handleAdd} disabled={isSaving}>
            {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
          </Button>
          <Button
            type="button"
            size="icon"
            variant="ghost"
            onClick={() => {
              setAdding(false);
              setNewName("");
            }}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <Button type="button" size="sm" variant="outline" onClick={() => setAdding(true)}>
          <Plus className="h-3.5 w-3.5" />
          Add custom service
        </Button>
      )}
    </div>
  );
}
