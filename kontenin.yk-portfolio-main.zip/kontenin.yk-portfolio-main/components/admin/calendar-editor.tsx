"use client";

import * as React from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Copy, Check, ExternalLink, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CalendarGrid } from "@/components/admin/calendar-grid";
import { CalendarEntryModal } from "@/components/admin/calendar-entry-modal";
import { CalendarRequestsPanel } from "@/components/admin/calendar-requests-panel";
import { CalendarInfoPanel } from "@/components/admin/calendar-info-panel";
import { CalendarStatsPanel } from "@/components/admin/calendar-stats-panel";
import { CalendarStrategyGallery } from "@/components/admin/calendar-strategy-gallery";
import { CalendarGlsAdminPanel } from "@/components/admin/calendar-gls-admin-panel";
import { ContentSummaryList } from "@/components/public/content-summary-list";
import { createCalendarEntryAction, updateCalendarEntryAction, deleteCalendarEntryAction } from "@/lib/actions/calendar";
import type { ContentCalendar, ContentCalendarEntry, ContentCalendarRequest, CalendarStrategy, CalendarEntryComment, CalendarGlsEntry } from "@/types/calendar";

interface CalendarEditorProps {
  calendar: ContentCalendar;
  entries: ContentCalendarEntry[];
  requests: ContentCalendarRequest[];
  strategies: CalendarStrategy[];
  commentsByEntry: Record<string, CalendarEntryComment[]>;
  glsEntries: CalendarGlsEntry[];
  initialYear: number;
  initialMonth: number;
  shareUrl: string;
}

const MONTH_NAMES = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];

export function CalendarEditor({ calendar, entries, requests, strategies, commentsByEntry, glsEntries, initialYear, initialMonth, shareUrl }: CalendarEditorProps) {
  const [year, setYear] = React.useState(initialYear);
  const [month, setMonth] = React.useState(initialMonth);
  const [modalDate, setModalDate] = React.useState<string | null>(null);
  const [editingEntry, setEditingEntry] = React.useState<ContentCalendarEntry | null>(null);
  const [copied, setCopied] = React.useState(false);

  function goToMonth(delta: number) {
    let newMonth = month + delta;
    let newYear = year;
    if (newMonth < 0) {
      newMonth = 11;
      newYear -= 1;
    } else if (newMonth > 11) {
      newMonth = 0;
      newYear += 1;
    }
    setMonth(newMonth);
    setYear(newYear);
  }

  function handleDayClick(isoDate: string) {
    setEditingEntry(null);
    setModalDate(isoDate);
  }

  function handleEntryClick(entry: ContentCalendarEntry) {
    setEditingEntry(entry);
    setModalDate(entry.entry_date);
  }

  async function handleCopyLink() {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const boundCreateAction = modalDate ? createCalendarEntryAction.bind(null, calendar.id) : null;
  const boundUpdateAction = editingEntry
    ? updateCalendarEntryAction.bind(null, editingEntry.id, calendar.id)
    : null;
  // Only one of these is ever relevant at a time — adding new content uses
  // create, editing an existing one uses update. Requiring BOTH to be
  // truthy (the previous bug) meant the modal could never open for new
  // content, since boundUpdateAction is intentionally null in that case.
  const activeAction = editingEntry ? boundUpdateAction : boundCreateAction;

  return (
    <div className="space-y-6">
      {/* Client info + share link */}
      <div className="flex flex-col gap-4 rounded-2xl border border-border p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          {calendar.client_logo_url && (
            <span className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl border border-border bg-secondary/40">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={calendar.client_logo_url} alt={calendar.client_name} className="h-full w-full object-contain" />
            </span>
          )}
          <div>
            <p className="font-semibold">{calendar.client_name}</p>
            {calendar.strategy_note && <p className="max-w-md text-sm text-muted-foreground">{calendar.strategy_note}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link href={`/admin/dashboard/calendars/${calendar.id}/edit`}>
              <Pencil className="h-3.5 w-3.5" />
              Edit
            </Link>
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={handleCopyLink}>
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? "Tersalin!" : "Salin Link Klien"}
          </Button>
          <Button asChild variant="ghost" size="sm">
            <Link href={shareUrl} target="_blank">
              <ExternalLink className="h-3.5 w-3.5" />
              Pratinjau
            </Link>
          </Button>
        </div>
      </div>

      <CalendarStrategyGallery calendarId={calendar.id} strategies={strategies} />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
        <div>
          {/* Month navigation */}
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">
              {MONTH_NAMES[month]} {year}
            </h2>
            <div className="flex items-center gap-1">
              <Button type="button" variant="outline" size="icon" onClick={() => goToMonth(-1)} aria-label="Bulan sebelumnya">
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  const now = new Date();
                  setYear(now.getFullYear());
                  setMonth(now.getMonth());
                }}
              >
                Hari Ini
              </Button>
              <Button type="button" variant="outline" size="icon" onClick={() => goToMonth(1)} aria-label="Bulan berikutnya">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <CalendarGrid
            year={year}
            month={month}
            entries={entries}
            onDayClick={handleDayClick}
            onEntryClick={handleEntryClick}
          />
        </div>

        <div className="space-y-4">
          <ContentSummaryList calendarId={calendar.id} entries={entries} editable={false} />
          <CalendarStatsPanel entries={entries} />
          <CalendarInfoPanel calendar={calendar} />
          <CalendarRequestsPanel calendarId={calendar.id} requests={requests} />
          <CalendarGlsAdminPanel calendarId={calendar.id} entries={glsEntries} />
        </div>
      </div>

      {modalDate && activeAction && (
        <CalendarEntryModal
          isoDate={modalDate}
          entry={editingEntry ?? undefined}
          calendarId={calendar.id}
          comments={editingEntry ? commentsByEntry[editingEntry.id] ?? [] : []}
          onClose={() => {
            setModalDate(null);
            setEditingEntry(null);
          }}
          onDelete={
            editingEntry
              ? async () => {
                  await deleteCalendarEntryAction(editingEntry.id, calendar.id);
                  setModalDate(null);
                  setEditingEntry(null);
                }
              : undefined
          }
          action={activeAction}
        />
      )}
    </div>
  );
}
