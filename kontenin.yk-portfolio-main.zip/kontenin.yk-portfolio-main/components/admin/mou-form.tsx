"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MOU_PARTY_TYPES, MOU_STATUSES, MOU_STATUS_LABELS } from "@/types/documents";
import type { MouDocument, MouPartyType, MouStatus } from "@/types/documents";
import type { DocActionState } from "@/lib/actions/documents";

interface MouFormProps {
  mou?: MouDocument;
  action: (state: DocActionState, formData: FormData) => Promise<DocActionState>;
}

const initialState: DocActionState = {};

function genMouNumber(): string {
  const now = new Date();
  return `MOU-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${Math.floor(1000 + Math.random() * 9000)}`;
}

const DEFAULT_TERMS_CLIENT = `1. Kontenin.yk akan menyediakan jasa sesuai lingkup kerja (scope) yang disepakati di bawah.
2. Revisi mengikuti ketentuan paket yang dipilih.
3. Materi/aset yang diberikan klien menjadi tanggung jawab klien atas hak penggunaannya.
4. Pembatalan proyek setelah pekerjaan dimulai tidak mengembalikan pembayaran yang sudah dilakukan.
5. Kerahasiaan: kedua pihak sepakat menjaga kerahasiaan informasi bisnis yang dibagikan selama kerja sama.`;

const DEFAULT_TERMS_FREELANCER = `1. Freelancer akan mengerjakan proyek sesuai lingkup kerja (scope) dan tenggat yang disepakati di bawah.
2. Hasil pekerjaan yang sudah dibayar penuh menjadi hak milik Kontenin.yk / klien terkait, kecuali disepakati lain.
3. Freelancer wajib menjaga kerahasiaan materi dan data klien yang diakses selama pengerjaan.
4. Keterlambatan tanpa konfirmasi dapat memengaruhi kompensasi sesuai kesepakatan.
5. Pembayaran dilakukan sesuai termin yang disepakati di bagian Compensation.`;

export function MouForm({ mou, action }: MouFormProps) {
  const [state, formAction] = useActionState(action, initialState);
  const [mouNumber, setMouNumber] = React.useState(mou?.mou_number ?? genMouNumber());
  const [partyType, setPartyType] = React.useState<MouPartyType>(mou?.party_type ?? "client");
  const [status, setStatus] = React.useState<MouStatus>(mou?.status ?? "draft");
  const [terms, setTerms] = React.useState(mou?.terms ?? DEFAULT_TERMS_CLIENT);

  function handlePartyTypeChange(v: MouPartyType) {
    setPartyType(v);
    // Only swap in the default template if the user hasn't customized it yet.
    if (!mou && (terms === DEFAULT_TERMS_CLIENT || terms === DEFAULT_TERMS_FREELANCER)) {
      setTerms(v === "client" ? DEFAULT_TERMS_CLIENT : DEFAULT_TERMS_FREELANCER);
    }
  }

  return (
    <form action={formAction} className="space-y-6">
      <input type="hidden" name="mou_number" value={mouNumber} />
      <input type="hidden" name="party_type" value={partyType} />
      <input type="hidden" name="status" value={status} />

      {state.error && <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label>MOU Number</Label>
          <Input value={mouNumber} onChange={(e) => setMouNumber(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>For</Label>
          <Select value={partyType} onValueChange={(v) => handlePartyTypeChange(v as MouPartyType)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {MOU_PARTY_TYPES.map((t) => (
                <SelectItem key={t} value={t}>{t === "client" ? "Client" : "Freelancer"}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="party_name">{partyType === "client" ? "Client" : "Freelancer"} Name</Label>
          <Input id="party_name" name="party_name" defaultValue={mou?.party_name ?? ""} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="party_company">Company (optional)</Label>
          <Input id="party_company" name="party_company" defaultValue={mou?.party_company ?? ""} />
        </div>
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="project_title">Project Title</Label>
          <Input id="project_title" name="project_title" defaultValue={mou?.project_title ?? ""} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="effective_date">Effective Date</Label>
          <Input id="effective_date" name="effective_date" type="date" defaultValue={mou?.effective_date ?? new Date().toISOString().slice(0, 10)} required />
        </div>
        <div className="space-y-2">
          <Label>Status</Label>
          <Select value={status} onValueChange={(v) => setStatus(v as MouStatus)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {MOU_STATUSES.map((s) => <SelectItem key={s} value={s}>{MOU_STATUS_LABELS[s]}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="scope">Scope of Work</Label>
        <Textarea id="scope" name="scope" defaultValue={mou?.scope ?? ""} rows={4} placeholder="Deskripsi pekerjaan yang dicakup — misal: editing 8 video short form per bulan untuk klien Falisha Laundry" />
      </div>

      <div className="space-y-2">
        <Label htmlFor="terms">Terms & Conditions</Label>
        <p className="text-xs text-muted-foreground">Draft standar sudah diisi otomatis — edit sesuai kebutuhan.</p>
        <Textarea
          id="terms"
          name="terms"
          value={terms}
          onChange={(e) => setTerms(e.target.value)}
          rows={8}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="compensation">Compensation / Payment Terms</Label>
          <Textarea id="compensation" name="compensation" defaultValue={mou?.compensation ?? ""} rows={3} placeholder="e.g. Rp1.500.000 per proyek, dibayarkan 50% di awal dan 50% setelah selesai" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="duration">Duration</Label>
          <Textarea id="duration" name="duration" defaultValue={mou?.duration ?? ""} rows={3} placeholder="e.g. 1 bulan, mulai 1 Agustus 2026" />
        </div>
      </div>

      <SubmitButton isEdit={Boolean(mou)} />
    </form>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Create MOU"}
    </Button>
  );
}
