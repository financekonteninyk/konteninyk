import Link from "next/link";
import Image from "next/image";
import { MessageCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Client } from "@/types/client";

function toWaLink(number: string): string {
  const digits = number.replace(/\D/g, "");
  const normalized = digits.startsWith("0") ? `62${digits.slice(1)}` : digits;
  return `https://wa.me/${normalized}`;
}

export function ClientContactsPanel({
  clients,
}: {
  clients: Pick<Client, "id" | "name" | "logo_url" | "whatsapp_number">[];
}) {
  const withContact = clients.filter((c) => c.whatsapp_number);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="h-4 w-4" />
          Client Contacts
        </CardTitle>
      </CardHeader>
      <CardContent>
        {withContact.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No client WhatsApp numbers saved yet — add one from the client's edit page.
          </p>
        ) : (
          <div className="max-h-64 space-y-1 overflow-y-auto">
            {withContact.map((client) => (
              <Link
                key={client.id}
                href={toWaLink(client.whatsapp_number!)}
                target="_blank"
                rel="noreferrer noopener"
                className="flex items-center gap-3 rounded-lg px-1.5 py-1.5 transition-colors hover:bg-secondary/50"
              >
                <span className="relative flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-secondary">
                  {client.logo_url ? (
                    <Image src={client.logo_url} alt="" fill sizes="32px" className="object-cover" />
                  ) : (
                    <span className="text-[10px] font-semibold text-muted-foreground">
                      {client.name.slice(0, 2).toUpperCase()}
                    </span>
                  )}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{client.name}</p>
                  <p className="text-xs text-muted-foreground">{client.whatsapp_number}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
