"use client";

import * as React from "react";
import { Plus, Loader2, X, Pencil, Check } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import type { TimelineItem } from "@/types/about";

interface TimelineManagerProps {
  items: TimelineItem[];
  onAdd: (year: string, title: string, description: string) => Promise<{ error?: string }>;
  onUpdate: (id: string, year: string, title: string, description: string) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
}

interface DraftFields {
  year: string;
  title: string;
  description: string;
}

const EMPTY_DRAFT: DraftFields = { year: "", title: "", description: "" };

export function TimelineManager({ items: initialItems, onAdd, onUpdate, onDelete }: TimelineManagerProps) {
  const [items, setItems] = React.useState(initialItems);
  const [newItem, setNewItem] = React.useState<DraftFields>(EMPTY_DRAFT);
  const [isAdding, setIsAdding] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [editDraft, setEditDraft] = React.useState<DraftFields>(EMPTY_DRAFT);
  const [isSaving, setIsSaving] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!newItem.year.trim() || !newItem.title.trim()) return;

    setIsAdding(true);
    const result = await onAdd(newItem.year.trim(), newItem.title.trim(), newItem.description.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        year: newItem.year.trim(),
        title: newItem.title.trim(),
        description: newItem.description.trim() || null,
        sort_order: prev.length,
        created_at: new Date().toISOString(),
      },
    ]);
    setNewItem(EMPTY_DRAFT);
    toast.success("Timeline item added.");
  }

  function startEdit(item: TimelineItem) {
    setEditingId(item.id);
    setEditDraft({ year: item.year, title: item.title, description: item.description ?? "" });
  }

  async function handleSaveEdit(id: string) {
    if (!editDraft.year.trim() || !editDraft.title.trim()) return;

    setIsSaving(true);
    const result = await onUpdate(id, editDraft.year.trim(), editDraft.title.trim(), editDraft.description.trim());
    setIsSaving(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) =>
      prev.map((i) =>
        i.id === id
          ? {
              ...i,
              year: editDraft.year.trim(),
              title: editDraft.title.trim(),
              description: editDraft.description.trim() || null,
            }
          : i
      )
    );
    setEditingId(null);
    toast.success("Timeline item updated.");
  }

  async function handleDelete(item: TimelineItem) {
    setDeletingId(item.id);
    const result = await onDelete(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
    toast.success(`"${item.title}" removed.`);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Timeline</CardTitle>
        <CardDescription>
          Milestones in the brand&apos;s journey, shown on the /about page in order.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2 rounded-xl border border-dashed border-border p-4">
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-[100px_1fr]">
            <Input
              value={newItem.year}
              onChange={(e) => setNewItem((d) => ({ ...d, year: e.target.value }))}
              placeholder="Year, e.g. 2023"
            />
            <Input
              value={newItem.title}
              onChange={(e) => setNewItem((d) => ({ ...d, title: e.target.value }))}
              placeholder="Title, e.g. Kontenin.yk founded"
            />
          </div>
          <Textarea
            value={newItem.description}
            onChange={(e) => setNewItem((d) => ({ ...d, description: e.target.value }))}
            placeholder="Description (optional)"
            rows={2}
          />
          <Button
            type="button"
            size="sm"
            onClick={handleAdd}
            disabled={isAdding || !newItem.year.trim() || !newItem.title.trim()}
          >
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add Timeline Item
          </Button>
        </div>

        {items.length === 0 ? (
          <EmptyState title="No timeline items yet" description="Add your first milestone above." />
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="rounded-xl border border-border p-4">
                {editingId === item.id ? (
                  <div className="space-y-2">
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-[100px_1fr]">
                      <Input
                        value={editDraft.year}
                        onChange={(e) => setEditDraft((d) => ({ ...d, year: e.target.value }))}
                      />
                      <Input
                        value={editDraft.title}
                        onChange={(e) => setEditDraft((d) => ({ ...d, title: e.target.value }))}
                      />
                    </div>
                    <Textarea
                      value={editDraft.description}
                      onChange={(e) => setEditDraft((d) => ({ ...d, description: e.target.value }))}
                      rows={2}
                    />
                    <div className="flex gap-2">
                      <Button type="button" size="sm" onClick={() => handleSaveEdit(item.id)} disabled={isSaving}>
                        {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                        Save
                      </Button>
                      <Button type="button" size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                        <X className="h-3.5 w-3.5" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-xs font-medium text-muted-foreground">{item.year}</span>
                      <h4 className="font-semibold">{item.title}</h4>
                      {item.description && (
                        <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>
                      )}
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <Button type="button" size="icon" variant="ghost" onClick={() => startEdit(item)} aria-label="Edit">
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDelete(item)}
                        disabled={deletingId === item.id}
                        aria-label="Delete"
                        className="text-muted-foreground hover:text-destructive"
                      >
                        {deletingId === item.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <X className="h-3.5 w-3.5" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
