"use client";

import * as React from "react";
import { Plus, Loader2, X, Pencil, Check } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import type { Award } from "@/types/about";

interface AwardsManagerProps {
  items: Award[];
  onAdd: (title: string, issuer: string, year: string) => Promise<{ error?: string }>;
  onUpdate: (id: string, title: string, issuer: string, year: string) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
}

interface Draft {
  title: string;
  issuer: string;
  year: string;
}

const EMPTY_DRAFT: Draft = { title: "", issuer: "", year: "" };

export function AwardsManager({ items: initialItems, onAdd, onUpdate, onDelete }: AwardsManagerProps) {
  const [items, setItems] = React.useState(initialItems);
  const [newItem, setNewItem] = React.useState<Draft>(EMPTY_DRAFT);
  const [isAdding, setIsAdding] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [editDraft, setEditDraft] = React.useState<Draft>(EMPTY_DRAFT);
  const [isSaving, setIsSaving] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!newItem.title.trim()) return;
    setIsAdding(true);
    const result = await onAdd(newItem.title.trim(), newItem.issuer.trim(), newItem.year.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        title: newItem.title.trim(),
        issuer: newItem.issuer.trim() || null,
        year: newItem.year.trim() || null,
        sort_order: prev.length,
        created_at: new Date().toISOString(),
      },
    ]);
    setNewItem(EMPTY_DRAFT);
    toast.success("Award added.");
  }

  function startEdit(item: Award) {
    setEditingId(item.id);
    setEditDraft({ title: item.title, issuer: item.issuer ?? "", year: item.year ?? "" });
  }

  async function handleSaveEdit(id: string) {
    if (!editDraft.title.trim()) return;
    setIsSaving(true);
    const result = await onUpdate(id, editDraft.title.trim(), editDraft.issuer.trim(), editDraft.year.trim());
    setIsSaving(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) =>
      prev.map((i) =>
        i.id === id
          ? {
              ...i,
              title: editDraft.title.trim(),
              issuer: editDraft.issuer.trim() || null,
              year: editDraft.year.trim() || null,
            }
          : i
      )
    );
    setEditingId(null);
    toast.success("Award updated.");
  }

  async function handleDelete(item: Award) {
    setDeletingId(item.id);
    const result = await onDelete(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
    toast.success(`"${item.title}" removed.`);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Awards</CardTitle>
        <CardDescription>Recognitions and achievements, shown on the /about page.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2 rounded-xl border border-dashed border-border p-4">
          <Input
            value={newItem.title}
            onChange={(e) => setNewItem((d) => ({ ...d, title: e.target.value }))}
            placeholder="Award title"
          />
          <div className="grid grid-cols-2 gap-2">
            <Input
              value={newItem.issuer}
              onChange={(e) => setNewItem((d) => ({ ...d, issuer: e.target.value }))}
              placeholder="Issued by (optional)"
            />
            <Input
              value={newItem.year}
              onChange={(e) => setNewItem((d) => ({ ...d, year: e.target.value }))}
              placeholder="Year (optional)"
            />
          </div>
          <Button type="button" size="sm" onClick={handleAdd} disabled={isAdding || !newItem.title.trim()}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add Award
          </Button>
        </div>

        {items.length === 0 ? (
          <EmptyState title="No awards yet" description="Add your first one above." />
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="rounded-xl border border-border p-4">
                {editingId === item.id ? (
                  <div className="space-y-2">
                    <Input
                      value={editDraft.title}
                      onChange={(e) => setEditDraft((d) => ({ ...d, title: e.target.value }))}
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        value={editDraft.issuer}
                        onChange={(e) => setEditDraft((d) => ({ ...d, issuer: e.target.value }))}
                      />
                      <Input
                        value={editDraft.year}
                        onChange={(e) => setEditDraft((d) => ({ ...d, year: e.target.value }))}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button type="button" size="sm" onClick={() => handleSaveEdit(item.id)} disabled={isSaving}>
                        {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                        Save
                      </Button>
                      <Button type="button" size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                        <X className="h-3.5 w-3.5" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="font-semibold">{item.title}</h4>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {[item.issuer, item.year].filter(Boolean).join(" · ")}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <Button type="button" size="icon" variant="ghost" onClick={() => startEdit(item)} aria-label="Edit">
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDelete(item)}
                        disabled={deletingId === item.id}
                        aria-label="Delete"
                        className="text-muted-foreground hover:text-destructive"
                      >
                        {deletingId === item.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <X className="h-3.5 w-3.5" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
