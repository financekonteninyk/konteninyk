import Image from "next/image";
import type { ElementType } from "react";
import { ArrowUpRight, Tag, Calendar, Hash, Landmark, ArrowRightLeft, ShieldCheck, Heart, PartyPopper } from "lucide-react";

export interface ExpensePreviewProps {
  voucherNumber: string;
  paidTo: string;
  role: string;
  category: string;
  workPeriod: string;
  description: string;
  personalNote?: string;
  amount: number;
  paymentDate: string;
  paymentMethod: string;
  transactionCode: string;
  senderBank: string;
  receiverBank: string;
  companyName: string;
  companyLogoUrl: string | null;
  printTargetId?: string;
  theme?: "light" | "dark";
}

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);
}

function formatDate(value: string): string {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

function DetailRow({ icon: Icon, label, value }: { icon: ElementType; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-500">
        <Icon className="h-3.5 w-3.5" />
      </span>
      <div>
        <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">{label}</span>
        <strong className="text-sm text-slate-900">{value || "-"}</strong>
      </div>
    </div>
  );
}

export function ExpensePreview({
  voucherNumber,
  paidTo,
  role,
  category,
  workPeriod,
  description,
  personalNote,
  amount,
  paymentDate,
  paymentMethod,
  transactionCode,
  senderBank,
  receiverBank,
  companyName,
  companyLogoUrl,
  printTargetId,
  theme = "light",
}: ExpensePreviewProps) {
  return (
    <div
      id={printTargetId}
      data-print-theme={theme}
      className="relative overflow-hidden rounded-lg border-t-[10px] border-t-amber-500 bg-white text-[13px] leading-relaxed text-slate-800 shadow-2xl"
    >
      {/* Decorative watermark */}
      <div aria-hidden className="pointer-events-none absolute -right-10 -top-6 select-none text-[160px] font-black leading-none text-slate-900/[0.03]">
        $
      </div>

      <div className="relative p-10 sm:p-14 print:p-8">
        <div className="mb-8 flex items-center justify-between print:mb-5">
          <div className="flex items-center gap-3">
            {companyLogoUrl && (
              <span className="relative h-10 w-10 overflow-hidden rounded-lg border border-slate-100 bg-slate-50 p-1.5">
                <Image src={companyLogoUrl} alt="" fill sizes="40px" className="object-contain" />
              </span>
            )}
            <div>
              <p className="text-base font-extrabold tracking-tight text-slate-900">{companyName}</p>
              <p className="flex items-center gap-1 text-[10px] text-slate-400">
                {personalNote ? (
                  <>
                    <Heart className="h-3 w-3 text-rose-400" />
                    With Appreciation
                  </>
                ) : (
                  <>
                    <ShieldCheck className="h-3 w-3" />
                    Verified Internal Record
                  </>
                )}
              </p>
            </div>
          </div>
          <div className="text-right">
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-amber-800">
              <ArrowUpRight className="h-3 w-3 rotate-90" />
              Outgoing Payment
            </span>
            <p className="mt-1.5 flex items-center justify-end gap-1 text-xs font-medium uppercase tracking-wide text-slate-400">
              <Hash className="h-3 w-3" />
              {voucherNumber || "-"}
            </p>
          </div>
        </div>

        <div className="mb-8 h-px bg-gradient-to-r from-transparent via-slate-200 to-transparent print:mb-4" />

        <div className="mb-8 text-center print:mb-4">
          <h1 className="text-2xl font-bold text-slate-900">Remittance Advice</h1>
          <p className="mt-1 text-sm text-slate-500">
            {personalNote ? `With thanks, from ${companyName}` : `Official proof of payment issued by ${companyName}`}
          </p>
        </div>

        <div className="mb-8 rounded-2xl bg-gradient-to-br from-slate-50 via-white to-amber-50/50 p-8 text-center ring-1 ring-slate-100 print:mb-4 print:p-5 print:break-inside-avoid">
          <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500">Amount Transferred</span>
          <span className="mt-2 block text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            {formatIDR(amount)}
          </span>
          <div className="mx-auto mt-3 h-px w-16 bg-amber-300" />
          <span className="mt-3 block text-sm text-slate-600">
            to <strong className="text-slate-900">{paidTo || "-"}</strong>
            {role && <span className="text-slate-400"> — {role}</span>}
          </span>
        </div>

        <p className="mb-8 text-center leading-relaxed text-slate-700 print:mb-4">
          This confirms that <strong>{companyName}</strong> has transferred the amount above to{" "}
          <strong>{paidTo || "the recipient"}</strong>
          {role && <> for their work as {role.toLowerCase()}</>}
          {workPeriod && <> covering the period of {workPeriod}</>}
          {description && <>. {description}</>}.
        </p>

        {personalNote && (
          <div className="mb-8 rounded-2xl border border-rose-200 bg-gradient-to-br from-rose-50 to-amber-50/60 p-6 text-center print:mb-4 print:p-4 print:break-inside-avoid">
            <PartyPopper className="mx-auto mb-2 h-5 w-5 text-rose-400" />
            <p className="text-[15px] font-medium leading-relaxed text-slate-800">{personalNote}</p>
          </div>
        )}

        <div className="mb-6 grid grid-cols-1 gap-5 rounded-2xl border border-slate-200 p-6 sm:grid-cols-2 print:mb-0 print:gap-3 print:p-4 print:break-inside-avoid">
          <DetailRow icon={Calendar} label="Date" value={formatDate(paymentDate)} />
          <DetailRow icon={Tag} label="Category" value={category} />
          <DetailRow icon={Hash} label="Transaction Code" value={transactionCode} />
          <DetailRow icon={ArrowRightLeft} label="Payment Method" value={paymentMethod} />
          <DetailRow icon={Landmark} label="Sent From" value={senderBank} />
          <DetailRow icon={Landmark} label="Sent To" value={receiverBank} />
        </div>
      </div>

      <div className="relative border-t border-slate-100 bg-slate-50 px-10 py-4 text-center text-[10px] uppercase tracking-wide text-slate-400 sm:px-14">
        {companyName} — Internal Payment Record — Generated automatically
      </div>
    </div>
  );
}
