"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, X, Trash2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  CALENDAR_ENTRY_STATUSES,
  CALENDAR_ENTRY_STATUS_LABELS,
  CALENDAR_ENTRY_SOURCES,
  CALENDAR_ENTRY_SOURCE_LABELS,
  APPROVAL_STATUS_LABELS,
} from "@/types/calendar";
import type { ContentCalendarEntry, CalendarEntryStatus, CalendarEntrySource, CalendarEntryComment } from "@/types/calendar";
import type { CalendarActionState } from "@/lib/actions/calendar";
import { postEntryCommentAction } from "@/lib/actions/calendar";

const CONTENT_TYPE_SUGGESTIONS = ["Reels", "Carousel", "Story", "Foto", "Post Statis", "Video"];

// Preset content-function tags with sensible default colors — funnel-stage
// categorization so a busy calendar can be scanned at a glance. Fully
// customizable: pick a preset, type your own tag name, or pick your own
// color — none of this is locked to the list below.
const FUNCTION_TAG_PRESETS: { name: string; color: string }[] = [
  { name: "Trust", color: "#22C55E" },
  { name: "Awareness", color: "#6075F1" },
  { name: "Engagement", color: "#F59E0B" },
  { name: "Conversion", color: "#EC4899" },
  { name: "Retention", color: "#A855F7" },
];

interface CalendarEntryModalProps {
  isoDate: string;
  entry?: ContentCalendarEntry;
  calendarId: string;
  comments: CalendarEntryComment[];
  onClose: () => void;
  onDelete?: () => void;
  action: (state: CalendarActionState, formData: FormData) => Promise<CalendarActionState>;
}

const initialState: CalendarActionState = {};

export function CalendarEntryModal({ isoDate, entry, calendarId, comments, onClose, onDelete, action }: CalendarEntryModalProps) {
  const [state, formAction] = useActionState(action, initialState);
  const [contentType, setContentType] = React.useState(entry?.content_type ?? "");
  const [status, setStatus] = React.useState<CalendarEntryStatus>(entry?.status ?? "planned");
  const [source, setSource] = React.useState<CalendarEntrySource>(entry?.source ?? "admin");
  const [functionTag, setFunctionTag] = React.useState(entry?.function_tag ?? "");
  const [functionColor, setFunctionColor] = React.useState(entry?.function_color ?? "");
  const [referenceImageUrl, setReferenceImageUrl] = React.useState(entry?.reference_image_url ?? "");

  const prevSuccess = React.useRef(false);
  React.useEffect(() => {
    // Once the action completes without an error, close the modal.
    if (!state.error && prevSuccess.current) onClose();
    if (!state.error) prevSuccess.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="glass-panel max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-border p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">{entry ? "Edit Konten" : "Tambah Konten"}</h3>
            <p className="text-sm text-muted-foreground">
              {new Date(isoDate + "T00:00:00").toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}
            </p>
          </div>
          <button type="button" onClick={onClose} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {state.error && (
          <p className="mb-4 rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>
        )}

        <form action={formAction} className="space-y-4">
          <input type="hidden" name="entry_date" value={isoDate} />
          <input type="hidden" name="status" value={status} />
          <input type="hidden" name="source" value={source} />
          <input type="hidden" name="function_tag" value={functionTag} />
          <input type="hidden" name="function_color" value={functionColor} />
          <input type="hidden" name="reference_image_url" value={referenceImageUrl} />

          <div className="space-y-2">
            <Label htmlFor="content_type">Jenis Konten</Label>
            <Input
              id="content_type"
              name="content_type"
              value={contentType}
              onChange={(e) => setContentType(e.target.value)}
              placeholder="cth. Reels"
              required
            />
            <div className="flex flex-wrap gap-1.5">
              {CONTENT_TYPE_SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setContentType(s)}
                  className={`rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                    s.toLowerCase() === contentType.trim().toLowerCase()
                      ? "border-foreground bg-foreground text-background"
                      : "border-border text-muted-foreground hover:border-foreground/40"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Rencana / Brief</Label>
            <Textarea id="description" name="description" defaultValue={entry?.description ?? ""} rows={6} placeholder="Konten ini tentang apa? Tulis brief selengkap mungkin di sini." />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reference_url">Referensi (opsional)</Label>
            <Input id="reference_url" name="reference_url" defaultValue={entry?.reference_url ?? ""} placeholder="Link inspirasi/referensi" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reference_image_url_display">Thumbnail Referensi (opsional)</Label>
            <p className="text-xs text-muted-foreground">Tempel link gambar — muncul kecil di tanggal pada kalender.</p>
            <div className="flex items-center gap-2">
              <Input
                id="reference_image_url_display"
                value={referenceImageUrl ?? ""}
                onChange={(e) => setReferenceImageUrl(e.target.value)}
                placeholder="Link gambar referensi"
              />
              {referenceImageUrl && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={referenceImageUrl} alt="" className="h-9 w-9 shrink-0 rounded-lg border border-border object-cover" />
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="drive_url">Link Drive Konten Jadi (opsional)</Label>
            <Input id="drive_url" name="drive_url" defaultValue={entry?.drive_url ?? ""} placeholder="Link Google Drive untuk konten yang sudah selesai" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="function_tag_display">Kategori Fungsi (opsional)</Label>
            <p className="text-xs text-muted-foreground">Kategorikan berdasarkan tujuannya — pilih preset, atau ketik & warnai sendiri.</p>
            <div className="flex items-center gap-2">
              <Input
                id="function_tag_display"
                value={functionTag}
                onChange={(e) => setFunctionTag(e.target.value)}
                placeholder="cth. Trust, Awareness"
                className="max-w-[200px]"
              />
              <Input
                type="text"
                value={functionColor}
                onChange={(e) => setFunctionColor(e.target.value)}
                placeholder="#6075F1"
                className="max-w-[110px]"
              />
              {functionColor && <span className="h-9 w-9 shrink-0 rounded-lg border border-border" style={{ backgroundColor: functionColor }} />}
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {FUNCTION_TAG_PRESETS.map((preset) => (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => {
                    setFunctionTag(preset.name);
                    setFunctionColor(preset.color);
                  }}
                  className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                    preset.name.toLowerCase() === functionTag.trim().toLowerCase()
                      ? "border-foreground"
                      : "border-border text-muted-foreground hover:border-foreground/40"
                  }`}
                >
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: preset.color }} />
                  {preset.name}
                </button>
              ))}
              {(functionTag || functionColor) && (
                <button
                  type="button"
                  onClick={() => {
                    setFunctionTag("");
                    setFunctionColor("");
                  }}
                  className="rounded-full border border-border px-2.5 py-1 text-xs font-medium text-muted-foreground hover:border-foreground/40"
                >
                  Hapus
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as CalendarEntryStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="z-[100]">
                  {CALENDAR_ENTRY_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>{CALENDAR_ENTRY_STATUS_LABELS[s]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sumber</Label>
              <Select value={source} onValueChange={(v) => setSource(v as CalendarEntrySource)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="z-[100]">
                  {CALENDAR_ENTRY_SOURCES.map((s) => (
                    <SelectItem key={s} value={s}>{CALENDAR_ENTRY_SOURCE_LABELS[s]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            {entry && onDelete ? (
              <Button type="button" variant="ghost" onClick={onDelete} className="text-destructive hover:text-destructive">
                <Trash2 className="h-4 w-4" />
                Hapus
              </Button>
            ) : (
              <span />
            )}
            <SubmitButton isEdit={Boolean(entry)} />
          </div>
        </form>

        {entry && (
          <div className="mt-6 border-t border-border pt-5">
            <div className="mb-4 flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Status Persetujuan Klien</p>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                  entry.approval_status === "approved"
                    ? "bg-emerald-500/10 text-emerald-600"
                    : entry.approval_status === "rejected"
                    ? "bg-destructive/10 text-destructive"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                {APPROVAL_STATUS_LABELS[entry.approval_status]}
              </span>
            </div>

            <AdminCommentsThread entryId={entry.id} calendarId={calendarId} initialComments={comments} />
          </div>
        )}
      </div>
    </div>
  );
}

function AdminCommentsThread({
  entryId,
  calendarId,
  initialComments,
}: {
  entryId: string;
  calendarId: string;
  initialComments: CalendarEntryComment[];
}) {
  const [comments, setComments] = React.useState(initialComments);
  const [message, setMessage] = React.useState("");
  const [sending, setSending] = React.useState(false);

  async function handleSend() {
    const trimmed = message.trim();
    if (!trimmed) return;
    setSending(true);

    const formData = new FormData();
    formData.set("message", trimmed);
    const boundAction = postEntryCommentAction.bind(null, entryId, calendarId, "admin");
    await boundAction({}, formData);

    setComments((prev) => [
      ...prev,
      { id: `local-${Date.now()}`, entry_id: entryId, author: "admin", message: trimmed, created_at: new Date().toISOString() },
    ]);
    setMessage("");
    setSending(false);
  }

  return (
    <div>
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Komentar & Feedback Klien</p>
      {comments.length > 0 ? (
        <div className="mb-3 max-h-48 space-y-2 overflow-y-auto">
          {comments.map((c) => (
            <div key={c.id} className={`rounded-lg p-2.5 text-sm ${c.author === "admin" ? "bg-primary/5" : "bg-secondary/50"}`}>
              <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                {c.author === "admin" ? "Kamu (Kontenin.yk)" : "Klien"}
              </p>
              {c.message}
            </div>
          ))}
        </div>
      ) : (
        <p className="mb-3 text-sm text-muted-foreground">Belum ada komentar untuk konten ini.</p>
      )}
      <div className="flex items-center gap-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Balas sebagai Kontenin.yk..."
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              handleSend();
            }
          }}
        />
        <Button type="button" size="icon" disabled={sending} onClick={handleSend} aria-label="Kirim balasan">
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Simpan Perubahan" : "Tambahkan ke Kalender"}
    </Button>
  );
}
