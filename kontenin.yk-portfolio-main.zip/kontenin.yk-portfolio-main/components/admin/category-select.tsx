"use client";

import * as React from "react";
import { Plus, Loader2, Check, X } from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addCategoryAction } from "@/lib/actions/settings";
import type { Category } from "@/types/settings";

interface CategorySelectProps {
  categories: Category[];
  value: string;
  onChange: (value: string) => void;
}

export function CategorySelect({ categories: initialCategories, value, onChange }: CategorySelectProps) {
  const [categories, setCategories] = React.useState(initialCategories);
  const [adding, setAdding] = React.useState(false);
  const [newName, setNewName] = React.useState("");
  const [isSaving, setIsSaving] = React.useState(false);

  async function handleAdd() {
    const trimmed = newName.trim();
    if (!trimmed) return;

    setIsSaving(true);
    const result = await addCategoryAction(trimmed);
    setIsSaving(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    if (!categories.some((c) => c.name.toLowerCase() === trimmed.toLowerCase())) {
      setCategories((prev) =>
        [...prev, { id: crypto.randomUUID(), name: trimmed, created_at: new Date().toISOString() }].sort(
          (a, b) => a.name.localeCompare(b.name)
        )
      );
    }
    onChange(trimmed);
    setNewName("");
    setAdding(false);
    toast.success(`Category "${trimmed}" added.`);
  }

  if (adding) {
    return (
      <div className="flex items-center gap-2">
        <Input
          autoFocus
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="New category name"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              handleAdd();
            }
          }}
        />
        <Button type="button" size="icon" variant="outline" onClick={handleAdd} disabled={isSaving}>
          {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
        </Button>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          onClick={() => {
            setAdding(false);
            setNewName("");
          }}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="flex-1">
          <SelectValue placeholder="Select a category" />
        </SelectTrigger>
        <SelectContent>
          {categories.map((c) => (
            <SelectItem key={c.id} value={c.name}>
              {c.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Button type="button" size="icon" variant="outline" onClick={() => setAdding(true)} aria-label="Add category">
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );
}
