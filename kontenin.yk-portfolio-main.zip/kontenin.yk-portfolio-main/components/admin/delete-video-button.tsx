"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteVideoAction } from "@/lib/actions/videos";

export function DeleteVideoButton({
  videoId,
  clientId,
  videoLabel,
}: {
  videoId: string;
  clientId: string;
  videoLabel: string;
}) {
  const router = useRouter();

  return (
    <DeleteButton
      itemLabel={videoLabel}
      onDelete={() => deleteVideoAction(videoId, clientId)}
      onDeleted={() => router.refresh()}
    />
  );
}
