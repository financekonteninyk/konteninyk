"use client";

import * as React from "react";
import { Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PrintButton } from "@/components/admin/print-button";
import { ExpensePreview, type ExpensePreviewProps } from "@/components/admin/expense-preview";

type PreviewData = Omit<ExpensePreviewProps, "theme" | "printTargetId">;

export function ExpensePrintView(props: PreviewData) {
  const [theme, setTheme] = React.useState<"light" | "dark">("light");

  return (
    <div className="mx-auto max-w-2xl py-8 print:py-0">
      <div className="mb-4 flex items-center justify-end gap-2 print:hidden">
        <Button type="button" variant="outline" onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}>
          {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          {theme === "light" ? "Switch to Dark" : "Switch to Light"}
        </Button>
        <PrintButton />
      </div>
      <ExpensePreview {...props} printTargetId="expense-print-area" theme={theme} />
    </div>
  );
}
