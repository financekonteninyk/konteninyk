import Image from "next/image";
import { CheckCircle2 } from "lucide-react";
import type { InvoiceLineItem, InvoiceCurrency, InvoiceBankAccount } from "@/types/tools";

export interface PaymentConfirmationPreviewProps {
  invoiceNumber: string;
  clientName: string;
  clientCompany: string | null;
  clientEmail: string | null;
  clientWhatsapp: string | null;
  total: number;
  currency: InvoiceCurrency;
  paymentPurpose: string | null;
  paidDate: string | null;
  transactionCode: string | null;
  senderBank: string | null;
  receivingBank: InvoiceBankAccount | null;
  items: InvoiceLineItem[];
  companyName: string;
  companyAddress: string;
  companyLogoUrl: string | null;
  companyContact: string;
  printTargetId?: string;
  theme?: "light" | "dark";
}

function formatMoney(value: number, currency: string): string {
  const localeMap: Record<string, string> = { IDR: "id-ID", USD: "en-US", SGD: "en-SG", EUR: "de-DE", MYR: "ms-MY" };
  return new Intl.NumberFormat(localeMap[currency] ?? "id-ID", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatDate(value: string | null): string {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

export function PaymentConfirmationPreview({
  invoiceNumber,
  clientName,
  clientCompany,
  clientEmail,
  clientWhatsapp,
  total,
  currency,
  paymentPurpose,
  paidDate,
  transactionCode,
  senderBank,
  receivingBank,
  items,
  companyName,
  companyAddress,
  companyLogoUrl,
  companyContact,
  printTargetId,
  theme = "light",
}: PaymentConfirmationPreviewProps) {
  return (
    <div
      id={printTargetId}
      data-print-theme={theme}
      className="rounded-lg bg-white p-10 text-[13px] leading-relaxed text-slate-800 shadow-2xl sm:p-14"
    >
      <div className="mb-10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {companyLogoUrl && (
            <span className="relative h-9 w-9">
              <Image src={companyLogoUrl} alt="" fill sizes="36px" className="object-contain" />
            </span>
          )}
          <div>
            <p className="text-base font-extrabold tracking-tight text-slate-900">{companyName}</p>
            <p className="text-[11px] text-slate-500">{companyAddress}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Invoice Reference</p>
          <p className="text-sm font-semibold text-slate-800">{invoiceNumber}</p>
        </div>
      </div>

      <div className="mb-8 flex flex-col items-center text-center">
        <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
          <CheckCircle2 className="h-7 w-7" />
        </span>
        <h1 className="text-2xl font-bold text-slate-900">Payment Received</h1>
        <p className="mt-1 text-sm text-slate-500">Confirmation of funds received</p>
      </div>

      <div className="mb-8 rounded-xl bg-slate-50 p-6 text-center">
        <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500">Amount Received</span>
        <span className="mt-1 block text-4xl font-extrabold tracking-tight text-emerald-700">
          {formatMoney(total, currency)}
        </span>
        <span className="mt-2 inline-block rounded-full bg-emerald-100 px-3 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-emerald-700">
          Paid in Full
        </span>
      </div>

      <p className="mb-8 text-center text-slate-700">
        Thank you for your prompt payment. We have successfully received your funds for{" "}
        <strong>{paymentPurpose || `Invoice ${invoiceNumber}`}</strong>, and this confirms our
        records are up to date.
      </p>

      {items.length > 0 && (
        <div className="mb-6">
          <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Items Purchased</h4>
          <table className="w-full border-collapse overflow-hidden rounded-lg border border-slate-200">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wide text-slate-500">Description</th>
                <th className="px-4 py-2.5 text-center text-[10px] font-semibold uppercase tracking-wide text-slate-500">Qty</th>
                <th className="px-4 py-2.5 text-right text-[10px] font-semibold uppercase tracking-wide text-slate-500">Amount</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, i) => (
                <tr key={i} className="border-t border-slate-200">
                  <td className="px-4 py-2.5 text-slate-700">{item.description}</td>
                  <td className="px-4 py-2.5 text-center text-slate-700">{item.quantity}</td>
                  <td className="px-4 py-2.5 text-right font-medium text-slate-900">
                    {formatMoney(item.quantity * item.unit_price, currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="mb-6">
        <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Received From</h4>
        <div className="rounded-lg border border-slate-200 p-4">
          <p className="text-sm font-bold text-slate-900">{clientName}</p>
          {clientCompany && <p className="text-sm text-slate-600">{clientCompany}</p>}
          {(clientEmail || clientWhatsapp) && (
            <p className="mt-1 text-xs text-slate-500">{[clientEmail, clientWhatsapp].filter(Boolean).join("  •  ")}</p>
          )}
        </div>
      </div>

      <div className="mb-6">
        <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Transaction Details</h4>
        <div className="grid grid-cols-2 gap-4 rounded-lg border border-slate-200 p-5">
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Date Received</span>
            <strong className="text-sm text-slate-900">{formatDate(paidDate)}</strong>
          </div>
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Transaction Code</span>
            <strong className="text-sm text-slate-900">{transactionCode || "-"}</strong>
          </div>
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Payment Purpose</span>
            <strong className="text-sm text-slate-900">{paymentPurpose || "-"}</strong>
          </div>
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Currency</span>
            <strong className="text-sm text-slate-900">{currency}</strong>
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Bank Routing</h4>
        <div className="grid grid-cols-2 gap-4 rounded-lg border border-slate-200 p-5">
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Sent From</span>
            <strong className="text-sm text-slate-900">{senderBank || "-"}</strong>
          </div>
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Received To</span>
            <strong className="text-sm text-slate-900">{receivingBank ? receivingBank.bank_name : "-"}</strong>
            {receivingBank && (
              <p className="text-xs text-slate-500">
                {receivingBank.account_number} — {receivingBank.account_holder}
              </p>
            )}
          </div>
        </div>
      </div>

      <p className="text-center text-xs italic text-slate-500">
        We appreciate your trust in {companyName}. Should you have any questions about this
        transaction, feel free to reach out to us anytime.
      </p>

      {companyContact && <p className="mt-4 text-center text-[11px] text-slate-400">{companyContact}</p>}
    </div>
  );
}
