"use client";

import * as React from "react";
import { Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PrintButton } from "@/components/admin/print-button";
import { FreelancerOfferPreview, type FreelancerOfferPreviewProps } from "@/components/admin/freelancer-offer-preview";

type PreviewData = Omit<FreelancerOfferPreviewProps, "theme" | "printTargetId">;

export function FreelancerOfferPrintView(props: PreviewData) {
  const [theme, setTheme] = React.useState<"light" | "dark">("light");

  return (
    <div className="mx-auto max-w-2xl py-8 print:py-0">
      <div className="mb-4 flex items-center justify-end gap-2 print:hidden">
        <Button type="button" variant="outline" onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}>
          {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          {theme === "light" ? "Switch to Dark" : "Switch to Light"}
        </Button>
        <PrintButton />
      </div>
      <FreelancerOfferPreview {...props} printTargetId="offer-print-area" theme={theme} />
    </div>
  );
}
