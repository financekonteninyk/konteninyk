import { Badge } from "@/components/ui/badge";
import { INVOICE_STATUS_LABELS } from "@/types/tools";
import type { InvoiceStatus } from "@/types/tools";

const VARIANT_MAP: Record<InvoiceStatus, "success" | "secondary" | "warning" | "destructive"> = {
  paid: "success",
  unpaid: "warning",
  partially_paid: "warning",
  draft: "secondary",
  cancelled: "destructive",
};

export function InvoiceStatusBadge({ status }: { status: InvoiceStatus }) {
  return <Badge variant={VARIANT_MAP[status]}>{INVOICE_STATUS_LABELS[status]}</Badge>;
}
