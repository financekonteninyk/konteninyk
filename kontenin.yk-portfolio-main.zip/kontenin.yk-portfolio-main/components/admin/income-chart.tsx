"use client";

import { motion } from "framer-motion";

interface IncomeChartProps {
  data: { label: string; total: number }[];
}

function formatIDR(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}jt`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(0)}rb`;
  return String(value);
}

export function IncomeChart({ data }: IncomeChartProps) {
  const max = Math.max(...data.map((d) => d.total), 1);

  return (
    <div className="flex h-48 items-end gap-3 sm:gap-4">
      {data.map((d, i) => {
        const heightPercent = (d.total / max) * 100;
        return (
          <div key={d.label} className="flex flex-1 flex-col items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground">
              {d.total > 0 ? formatIDR(d.total) : ""}
            </span>
            <div className="flex h-32 w-full items-end overflow-hidden rounded-lg bg-secondary/40">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${Math.max(heightPercent, d.total > 0 ? 4 : 0)}%` }}
                transition={{ duration: 0.6, delay: i * 0.06, ease: "easeOut" }}
                className="w-full rounded-t-lg bg-foreground"
              />
            </div>
            <span className="text-xs text-muted-foreground">{d.label}</span>
          </div>
        );
      })}
    </div>
  );
}
