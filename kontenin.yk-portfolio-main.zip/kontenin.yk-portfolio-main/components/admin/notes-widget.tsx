"use client";

import * as React from "react";
import { Plus, Loader2, X, StickyNote } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { addAdminNoteAction, toggleAdminNoteAction, deleteAdminNoteAction } from "@/lib/actions/tools";
import type { AdminNote } from "@/types/tools";

export function NotesWidget({ items: initialItems }: { items: AdminNote[] }) {
  const [items, setItems] = React.useState(initialItems);
  const [content, setContent] = React.useState("");
  const [isAdding, setIsAdding] = React.useState(false);

  async function handleAdd() {
    if (!content.trim()) return;
    setIsAdding(true);
    const result = await addAdminNoteAction(content.trim());
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      { id: crypto.randomUUID(), content: content.trim(), is_done: false, sort_order: 0, created_at: new Date().toISOString() },
      ...prev,
    ]);
    setContent("");
  }

  async function handleToggle(item: AdminNote) {
    setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, is_done: !i.is_done } : i)));
    const result = await toggleAdminNoteAction(item.id, !item.is_done);
    if (result.error) {
      toast.error(result.error);
      setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, is_done: item.is_done } : i)));
    }
  }

  async function handleDelete(item: AdminNote) {
    setItems((prev) => prev.filter((i) => i.id !== item.id));
    const result = await deleteAdminNoteAction(item.id);
    if (result.error) toast.error(result.error);
  }

  const pending = items.filter((i) => !i.is_done);
  const done = items.filter((i) => i.is_done);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <StickyNote className="h-4 w-4" />
          Notes & Tasks
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAdd();
              }
            }}
            placeholder="Add a task or note..."
            className="h-9"
          />
          <Button type="button" size="icon" className="h-9 w-9 shrink-0" onClick={handleAdd} disabled={isAdding || !content.trim()}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          </Button>
        </div>

        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nothing here yet — add your first note above.</p>
        ) : (
          <div className="max-h-72 space-y-1 overflow-y-auto">
            {[...pending, ...done].map((item) => (
              <div key={item.id} className="group flex items-center gap-2.5 rounded-lg px-1.5 py-1.5 hover:bg-secondary/50">
                <Checkbox checked={item.is_done} onCheckedChange={() => handleToggle(item)} />
                <span className={`flex-1 text-sm ${item.is_done ? "text-muted-foreground line-through" : ""}`}>
                  {item.content}
                </span>
                <button
                  type="button"
                  onClick={() => handleDelete(item)}
                  aria-label="Delete"
                  className="text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
