import Image from "next/image";
import Link from "next/link";
import { ImageOff, Pencil, Film, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/admin/status-badge";
import { DeleteClientButton } from "@/components/admin/delete-client-button";
import { formatDate } from "@/lib/utils";
import type { Client } from "@/types/client";

export function ClientsTable({ clients }: { clients: Client[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-border">
      <table className="w-full min-w-[820px] text-left text-sm">
        <thead className="border-b border-border bg-secondary/40 text-xs uppercase tracking-wide text-muted-foreground">
          <tr>
            <th className="px-4 py-3 font-medium">Client</th>
            <th className="px-4 py-3 font-medium">Category</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium">Created</th>
            <th className="px-4 py-3 font-medium text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {clients.map((client) => (
            <tr key={client.id} className="transition-colors hover:bg-accent/30">
              <td className="px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="relative h-11 w-14 shrink-0 overflow-hidden rounded-lg bg-muted">
                    {client.cover_thumbnail_url ? (
                      <Image
                        src={client.cover_thumbnail_url}
                        alt={client.name}
                        fill
                        sizes="56px"
                        className="object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                        <ImageOff className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="truncate font-medium">{client.name}</p>
                      {client.featured && (
                        <Star className="h-3.5 w-3.5 shrink-0 fill-amber-400 text-amber-400" />
                      )}
                    </div>
                    {client.industry && (
                      <p className="truncate text-xs text-muted-foreground">{client.industry}</p>
                    )}
                  </div>
                </div>
              </td>
              <td className="px-4 py-3">
                <Badge variant="outline">{client.category}</Badge>
              </td>
              <td className="px-4 py-3">
                <StatusBadge status={client.status} />
              </td>
              <td className="px-4 py-3 text-muted-foreground">{formatDate(client.created_at)}</td>
              <td className="px-4 py-3">
                <div className="flex items-center justify-end gap-1">
                  <Button
                    asChild
                    variant="ghost"
                    size="icon"
                    aria-label={`Manage videos for ${client.name}`}
                  >
                    <Link href={`/admin/dashboard/clients/${client.id}/videos`}>
                      <Film className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" size="icon" aria-label={`Edit ${client.name}`}>
                    <Link href={`/admin/dashboard/clients/${client.id}/edit`}>
                      <Pencil className="h-4 w-4" />
                    </Link>
                  </Button>
                  <DeleteClientButton clientId={client.id} clientName={client.name} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
