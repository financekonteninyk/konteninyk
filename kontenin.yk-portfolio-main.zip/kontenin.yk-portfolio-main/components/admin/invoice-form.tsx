"use client";

import * as React from "react";
import Link from "next/link";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Plus, X, Printer, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ImageUpload } from "@/components/admin/image-upload";
import { InvoicePreview } from "@/components/admin/invoice-preview";
import { STORAGE_BUCKETS } from "@/lib/constants";
import {
  INVOICE_STATUSES,
  INVOICE_STATUS_LABELS,
  INVOICE_DOC_TYPES,
  INVOICE_DOC_TYPE_LABELS,
  INVOICE_CURRENCIES,
} from "@/types/tools";
import type {
  Invoice,
  InvoiceLineItem,
  InvoiceStatus,
  InvoiceDocType,
  InvoiceCurrency,
  InvoiceBankAccount,
} from "@/types/tools";
import type { ToolActionState } from "@/lib/actions/tools";
import type { SiteSettings } from "@/types/settings";
import type { Client } from "@/types/client";
import type { InvoiceService } from "@/types/tools";

interface InvoiceFormProps {
  invoice?: Invoice;
  action: (state: ToolActionState, formData: FormData) => Promise<ToolActionState>;
  bankAccounts: InvoiceBankAccount[];
  settings: SiteSettings;
  clients: Pick<Client, "id" | "name" | "logo_url" | "whatsapp_number">[];
  services: InvoiceService[];
}

const initialState: ToolActionState = {};
const EMPTY_ITEM: InvoiceLineItem = { description: "", quantity: 1, unit_price: 0 };

function generateInvoiceNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const suffix = Math.floor(1000 + Math.random() * 9000);
  return `KNT-${y}${m}-${suffix}`;
}

export function InvoiceForm({ invoice, action, bankAccounts, settings, clients, services }: InvoiceFormProps) {
  const [state, formAction] = useActionState(action, initialState);

  const [clientId, setClientId] = React.useState<string>(invoice?.client_id ?? "");

  const [invoiceNumber, setInvoiceNumber] = React.useState(invoice?.invoice_number ?? generateInvoiceNumber());
  const [docType, setDocType] = React.useState<InvoiceDocType>(invoice?.doc_type ?? "keluar");
  const [currency, setCurrency] = React.useState<InvoiceCurrency>(invoice?.currency ?? "IDR");
  const [status, setStatus] = React.useState<InvoiceStatus>(invoice?.status ?? "draft");
  const [issueDate, setIssueDate] = React.useState(invoice?.issue_date ?? new Date().toISOString().slice(0, 10));
  const [dueDate, setDueDate] = React.useState(invoice?.due_date ?? "");
  const [paidDate, setPaidDate] = React.useState(invoice?.paid_date ?? "");
  const [transactionCode, setTransactionCode] = React.useState(invoice?.transaction_code ?? "");
  const [senderBank, setSenderBank] = React.useState(invoice?.sender_bank ?? "");
  const [paymentPurpose, setPaymentPurpose] = React.useState(invoice?.payment_purpose ?? "");

  const [clientName, setClientName] = React.useState(invoice?.client_name ?? "");
  const [clientCompany, setClientCompany] = React.useState(invoice?.client_company ?? "");
  const [clientWhatsapp, setClientWhatsapp] = React.useState(invoice?.client_whatsapp ?? "");
  const [clientEmail, setClientEmail] = React.useState(invoice?.client_email ?? "");
  const [clientLogoUrl, setClientLogoUrl] = React.useState<string | null>(invoice?.client_logo_url ?? null);

  const [items, setItems] = React.useState<InvoiceLineItem[]>(invoice?.items ?? [{ ...EMPTY_ITEM }]);
  const [discountPercent, setDiscountPercent] = React.useState<number>(invoice?.discount_percent ?? 0);
  const [taxPercent, setTaxPercent] = React.useState<number>(invoice?.tax_percent ?? 0);
  const [bankAccountId, setBankAccountId] = React.useState<string>(invoice?.bank_account_id ?? "");
  const [showQris, setShowQris] = React.useState<boolean>(invoice?.show_qris ?? true);
  const [notes, setNotes] = React.useState(invoice?.notes ?? "");

  function updateItem(index: number, patch: Partial<InvoiceLineItem>) {
    setItems((prev) => prev.map((item, i) => (i === index ? { ...item, ...patch } : item)));
  }

  function addItem() {
    setItems((prev) => [...prev, { ...EMPTY_ITEM }]);
  }

  function quickAddFromCatalog(serviceId: string) {
    const service = services.find((s) => s.id === serviceId);
    if (!service) return;
    setItems((prev) => {
      // Replace a single still-empty first row instead of stacking a blank one underneath.
      if (prev.length === 1 && !prev[0]!.description && !prev[0]!.unit_price) {
        return [{ description: service.name, quantity: 1, unit_price: service.price }];
      }
      return [...prev, { description: service.name, quantity: 1, unit_price: service.price }];
    });
  }

  function removeItem(index: number) {
    setItems((prev) => (prev.length > 1 ? prev.filter((_, i) => i !== index) : prev));
  }

  const clientContact = [clientWhatsapp, clientEmail].filter(Boolean).join(" | ");
  const selectedBank = bankAccounts.find((b) => b.id === bankAccountId) ?? null;
  const companyContact = [settings.invoice_company_email, settings.invoice_company_wa].filter(Boolean).join(" | ");

  return (
    <div className="grid grid-cols-1 gap-8 xl:grid-cols-[1.05fr_0.95fr] xl:items-start">
      <form action={formAction} className="min-w-0 space-y-8 print:hidden">
        <input type="hidden" name="invoice_number" value={invoiceNumber} />
        <input type="hidden" name="doc_type" value={docType} />
        <input type="hidden" name="currency" value={currency} />
        <input type="hidden" name="status" value={status} />
        <input type="hidden" name="items" value={JSON.stringify(items)} />
        <input type="hidden" name="client_logo_url" value={clientLogoUrl ?? ""} />
        <input type="hidden" name="bank_account_id" value={bankAccountId} />
        <input type="hidden" name="show_qris" value={String(showQris)} />
        <input type="hidden" name="client_id" value={clientId} />

        {state.error && (
          <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>
        )}

        <div className="space-y-4 rounded-2xl border border-border p-5">
          <p className="text-sm font-semibold">Document Configuration</p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Document Type</Label>
              <Select value={docType} onValueChange={(v) => setDocType(v as InvoiceDocType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {INVOICE_DOC_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {INVOICE_DOC_TYPE_LABELS[t]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Currency</Label>
              <Select value={currency} onValueChange={(v) => setCurrency(v as InvoiceCurrency)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {INVOICE_CURRENCIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="invoice_number_input">Invoice Identifier</Label>
              <div className="flex gap-2">
                <Input
                  id="invoice_number_input"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  placeholder="e.g. KNT-BILL-2026-0001"
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => setInvoiceNumber(generateInvoiceNumber())}
                  aria-label="Generate new number"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Payment Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as InvoiceStatus)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {INVOICE_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {INVOICE_STATUS_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="payment_purpose">Payment Purpose / Project Description</Label>
              <Input
                id="payment_purpose"
                name="payment_purpose"
                value={paymentPurpose}
                onChange={(e) => setPaymentPurpose(e.target.value)}
                placeholder="e.g. Social Media Management - June 2026 Batch"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="issue_date">Issue Date</Label>
              <Input
                id="issue_date"
                name="issue_date"
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="due_date">Due Date</Label>
              <Input
                id="due_date"
                name="due_date"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="paid_date">
                Payment Received Date <span className="text-muted-foreground">(for proof-of-transfer / bukti transfer)</span>
              </Label>
              <Input
                id="paid_date"
                name="paid_date"
                type="date"
                value={paidDate}
                onChange={(e) => setPaidDate(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Set this to the actual date the transfer landed — it doesn't have to match when you
                mark the invoice as Paid.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transaction_code">Transaction Code (optional)</Label>
              <Input
                id="transaction_code"
                name="transaction_code"
                value={transactionCode}
                onChange={(e) => setTransactionCode(e.target.value)}
                placeholder="e.g. TRX20260723001"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sender_bank">Client's Sending Bank (optional)</Label>
              <Input
                id="sender_bank"
                name="sender_bank"
                value={senderBank}
                onChange={(e) => setSenderBank(e.target.value)}
                placeholder="e.g. BCA"
              />
              <p className="text-xs text-muted-foreground">
                Used on the Payment Confirmation document, alongside your receiving bank.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4 rounded-2xl border border-border p-5">
          <p className="text-sm font-semibold">Target Entity (Client / Vendor)</p>

          <div className="space-y-2">
            <Label>Link to Existing Client (optional)</Label>
            <Select
              value={clientId}
              onValueChange={(v) => {
                setClientId(v);
                const client = clients.find((c) => c.id === v);
                if (client) {
                  setClientName(client.name);
                  setClientLogoUrl(client.logo_url);
                  if (client.whatsapp_number) setClientWhatsapp(client.whatsapp_number);
                }
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Pick a client to auto-fill name, logo & WhatsApp" />
              </SelectTrigger>
              <SelectContent>
                {clients.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Fields below stay editable either way — this just saves typing for repeat clients.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="client_name">Name</Label>
              <Input
                id="client_name"
                name="client_name"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="client_company">Company (optional)</Label>
              <Input
                id="client_company"
                name="client_company"
                value={clientCompany}
                onChange={(e) => setClientCompany(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="client_whatsapp">WhatsApp Contact</Label>
              <Input
                id="client_whatsapp"
                name="client_whatsapp"
                value={clientWhatsapp}
                onChange={(e) => setClientWhatsapp(e.target.value)}
                placeholder="0812..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="client_email">Email</Label>
              <Input
                id="client_email"
                name="client_email"
                type="email"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
              />
            </div>
            <div className="md:col-span-2">
              <ImageUpload
                label="Client Logo (optional)"
                bucket={STORAGE_BUCKETS.SITE_ASSETS}
                value={clientLogoUrl}
                onChange={setClientLogoUrl}
                aspectClassName="aspect-square max-w-[100px]"
              />
            </div>
          </div>
        </div>

        <div className="space-y-3 rounded-2xl border border-border p-5">
          <p className="text-sm font-semibold">Line Items</p>

          {services.length > 0 && (
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Quick add from your price list</Label>
              <Select value="" onValueChange={quickAddFromCatalog}>
                <SelectTrigger>
                  <SelectValue placeholder="Pick a service to add as a line item" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name} — Rp{s.price.toLocaleString("id-ID")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            {items.map((item, i) => (
              <div key={i} className="grid grid-cols-1 gap-2 rounded-lg border border-border p-2 sm:grid-cols-12 sm:border-none sm:p-0">
                <Input
                  className="sm:col-span-6"
                  value={item.description}
                  onChange={(e) => updateItem(i, { description: e.target.value })}
                  placeholder="Description, e.g. Content Package - March"
                />
                <Input
                  className="sm:col-span-2"
                  type="number"
                  min={1}
                  value={item.quantity}
                  onChange={(e) => updateItem(i, { quantity: Number(e.target.value) || 0 })}
                  placeholder="Qty"
                />
                <Input
                  className="sm:col-span-3"
                  type="number"
                  min={0}
                  value={item.unit_price}
                  onChange={(e) => updateItem(i, { unit_price: Number(e.target.value) || 0 })}
                  placeholder="Unit price"
                />
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="justify-self-end text-muted-foreground hover:text-destructive sm:col-span-1 sm:justify-self-auto"
                  onClick={() => removeItem(i)}
                  aria-label="Remove item"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          <Button type="button" size="sm" variant="outline" onClick={addItem}>
            <Plus className="h-3.5 w-3.5" />
            Add Line Item
          </Button>
        </div>

        <div className="space-y-4 rounded-2xl border border-border p-5">
          <p className="text-sm font-semibold">Financial Deductions & Gateways</p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="discount_percent">Discount (%)</Label>
              <Input
                id="discount_percent"
                name="discount_percent"
                type="number"
                min={0}
                max={100}
                value={discountPercent}
                onChange={(e) => setDiscountPercent(Number(e.target.value) || 0)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tax_percent">Tax / VAT (%)</Label>
              <Input
                id="tax_percent"
                name="tax_percent"
                type="number"
                min={0}
                max={100}
                value={taxPercent}
                onChange={(e) => setTaxPercent(Number(e.target.value) || 0)}
              />
            </div>
            <div className="space-y-2">
              <Label>Target Bank Account</Label>
              <Select value={bankAccountId} onValueChange={setBankAccountId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select bank account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.map((b) => (
                    <SelectItem key={b.id} value={b.id}>
                      {b.bank_name} — {b.account_number}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end pb-2.5">
              <label className="flex cursor-pointer items-center gap-2.5 text-sm font-medium">
                <Checkbox checked={showQris} onCheckedChange={(c) => setShowQris(c === true)} />
                Show QRIS Barcode
              </label>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Notes (optional, internal only)</Label>
          <Textarea id="notes" name="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} />
        </div>

        <SubmitButton isEdit={Boolean(invoice)} />
      </form>

      <div className="min-w-0 xl:sticky xl:top-8">
        {invoice && (
          <div className="mb-3 flex flex-wrap gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/admin/dashboard/invoices/${invoice.id}/print`} target="_blank">
                <Printer className="h-3.5 w-3.5" />
                Print / PDF
              </Link>
            </Button>
            {invoice.status === "paid" && (
              <Button asChild variant="outline" size="sm">
                <Link href={`/admin/dashboard/invoices/${invoice.id}/payment-confirmation`} target="_blank">
                  <Printer className="h-3.5 w-3.5" />
                  Payment Confirmation
                </Link>
              </Button>
            )}
          </div>
        )}
        <InvoicePreview
          printTargetId="invoice-print-area"
          invoiceNumber={invoiceNumber}
          docType={docType}
          status={status}
          issueDate={issueDate}
          dueDate={dueDate}
          paymentPurpose={paymentPurpose}
          clientName={clientName}
          clientCompany={clientCompany}
          clientContact={clientContact}
          clientLogoUrl={clientLogoUrl}
          agencyLogoUrl={settings.site_logo_url}
          companyName={settings.invoice_company_name || "Kontenin.yk"}
          companySub={settings.invoice_company_sub || "Creative Agency"}
          companyAddress={settings.invoice_company_address || "Yogyakarta, Indonesia"}
          companyContact={companyContact}
          items={items}
          currency={currency}
          discountPercent={discountPercent}
          taxPercent={taxPercent}
          bankAccount={selectedBank}
          showQris={showQris}
          qrisUrl={settings.invoice_qris_url}
          footerNote={settings.invoice_footer_note || ""}
        />
      </div>
    </div>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Create Invoice"}
    </Button>
  );
}
