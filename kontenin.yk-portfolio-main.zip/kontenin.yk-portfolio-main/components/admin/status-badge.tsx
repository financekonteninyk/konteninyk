import { Badge } from "@/components/ui/badge";
import { STATUS_LABELS } from "@/types/client";
import type { ClientStatus } from "@/types/client";

const VARIANT_MAP: Record<ClientStatus, "success" | "secondary" | "warning"> = {
  published: "success",
  draft: "secondary",
  archived: "warning",
};

export function StatusBadge({ status }: { status: ClientStatus }) {
  return <Badge variant={VARIANT_MAP[status]}>{STATUS_LABELS[status]}</Badge>;
}
