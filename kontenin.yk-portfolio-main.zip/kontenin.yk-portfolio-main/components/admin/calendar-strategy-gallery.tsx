"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Plus, X, Trash2, FileText, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  createCalendarStrategyAction,
  updateCalendarStrategyAction,
  deleteCalendarStrategyAction,
  type CalendarActionState,
} from "@/lib/actions/calendar";
import type { CalendarStrategy } from "@/types/calendar";

const initialState: CalendarActionState = {};

interface CalendarStrategyGalleryProps {
  calendarId: string;
  strategies: CalendarStrategy[];
}

export function CalendarStrategyGallery({ calendarId, strategies }: CalendarStrategyGalleryProps) {
  const [viewing, setViewing] = React.useState<CalendarStrategy | null>(null);
  const [editing, setEditing] = React.useState<CalendarStrategy | "new" | null>(null);

  return (
    <div className="rounded-2xl border border-border p-5">
      <div className="mb-4 flex items-center justify-between">
        <p className="flex items-center gap-1.5 text-sm font-semibold">
          <BookOpen className="h-4 w-4" />
          Galeri Strategi
        </p>
        <Button type="button" size="sm" variant="outline" onClick={() => setEditing("new")}>
          <Plus className="h-3.5 w-3.5" />
          Tambah
        </Button>
      </div>

      {strategies.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          Belum ada dokumen strategi. Tambahkan kalau strateginya cukup panjang untuk dipisah dari catatan singkat di atas.
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {strategies.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setViewing(s)}
              className="flex flex-col items-start gap-1.5 rounded-xl border border-border p-4 text-left transition-colors hover:border-primary/40"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <FileText className="h-4 w-4" />
              </span>
              <p className="font-medium">{s.title}</p>
              <p className="line-clamp-2 text-xs text-muted-foreground">{s.content}</p>
            </button>
          ))}
        </div>
      )}

      {/* Detail viewer */}
      {viewing && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={() => setViewing(null)}>
          <div className="glass-panel w-full max-w-xl rounded-2xl border border-border p-6" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold">{viewing.title}</h3>
              <button type="button" onClick={() => setViewing(null)} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="max-h-[50vh] overflow-y-auto whitespace-pre-line text-sm leading-relaxed">{viewing.content}</p>
            <div className="mt-5 flex justify-between">
              <Button
                type="button"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={async () => {
                  await deleteCalendarStrategyAction(viewing.id, calendarId);
                  setViewing(null);
                }}
              >
                <Trash2 className="h-4 w-4" />
                Hapus
              </Button>
              <Button type="button" variant="outline" onClick={() => { setEditing(viewing); setViewing(null); }}>
                Edit
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add/edit form */}
      {editing && (
        <StrategyFormModal
          calendarId={calendarId}
          strategy={editing === "new" ? undefined : editing}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  );
}

function StrategyFormModal({
  calendarId,
  strategy,
  onClose,
}: {
  calendarId: string;
  strategy?: CalendarStrategy;
  onClose: () => void;
}) {
  const action = strategy
    ? updateCalendarStrategyAction.bind(null, strategy.id, calendarId)
    : createCalendarStrategyAction.bind(null, calendarId);
  const [state, formAction] = useActionState(action, initialState);
  const isFirstRender = React.useRef(true);

  React.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    if (!state.error) onClose();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="glass-panel w-full max-w-lg rounded-2xl border border-border p-6" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold">{strategy ? "Edit Strategi" : "Tambah Strategi"}</h3>
          <button type="button" onClick={onClose} aria-label="Tutup" className="text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {state.error && (
          <p className="mb-4 rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>
        )}

        <form action={formAction} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Judul</Label>
            <Input id="title" name="title" defaultValue={strategy?.title ?? ""} placeholder="cth. Strategi Bulan Januari" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="content">Isi Strategi</Label>
            <Textarea id="content" name="content" defaultValue={strategy?.content ?? ""} rows={10} placeholder="Tulis strategi lengkap di sini..." required />
          </div>
          <SubmitButton isEdit={Boolean(strategy)} />
        </form>
      </div>
    </div>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Simpan Perubahan" : "Tambahkan"}
    </Button>
  );
}
