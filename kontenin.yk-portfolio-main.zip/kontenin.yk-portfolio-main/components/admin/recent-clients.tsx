import Image from "next/image";
import Link from "next/link";
import { ImageOff } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/admin/status-badge";
import { EmptyState } from "@/components/shared/empty-state";
import { formatDate } from "@/lib/utils";
import type { Client } from "@/types/client";

export function RecentClients({ clients }: { clients: Client[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Clients</CardTitle>
      </CardHeader>
      <CardContent>
        {clients.length === 0 ? (
          <EmptyState
            title="No clients yet"
            description="Create your first client to see it appear here."
          />
        ) : (
          <div className="divide-y divide-border">
            {clients.map((client) => (
              <Link
                key={client.id}
                href={`/admin/dashboard/clients/${client.id}/edit`}
                className="flex items-center gap-4 py-4 transition-colors hover:bg-accent/40 -mx-2 px-2 rounded-lg first:pt-0 last:pb-0"
              >
                <div className="relative h-12 w-16 shrink-0 overflow-hidden rounded-lg bg-muted">
                  {client.cover_thumbnail_url ? (
                    <Image
                      src={client.cover_thumbnail_url}
                      alt={client.name}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                      <ImageOff className="h-4 w-4" />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{client.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {client.category} · {formatDate(client.created_at)}
                  </p>
                </div>
                <StatusBadge status={client.status} />
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
