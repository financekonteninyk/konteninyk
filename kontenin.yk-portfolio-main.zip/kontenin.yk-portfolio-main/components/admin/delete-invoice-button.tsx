"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteInvoiceAction } from "@/lib/actions/tools";

export function DeleteInvoiceButton({ invoiceId, invoiceNumber }: { invoiceId: string; invoiceNumber: string }) {
  const router = useRouter();

  return (
    <DeleteButton
      itemLabel={invoiceNumber}
      onDelete={() => deleteInvoiceAction(invoiceId)}
      onDeleted={() => router.refresh()}
    />
  );
}
