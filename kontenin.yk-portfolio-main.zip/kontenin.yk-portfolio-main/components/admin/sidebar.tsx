"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Tags, Settings, LogOut, Menu, X, ExternalLink, MessageCircle, Link2, Wallet, FileSignature, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/shared/logo";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/shared/theme-toggle";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { signOutAction } from "@/lib/actions/auth";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
  { label: "Categories & Services", href: "/admin/dashboard/taxonomy", icon: Tags },
  { label: "Agreements", href: "/admin/dashboard/agreements", icon: FileSignature },
  { label: "CFS (Kalender)", href: "/admin/dashboard/calendars", icon: Calendar },
  { label: "Finance", href: "/admin/dashboard/finance", icon: Wallet },
  { label: "Tools", href: "/admin/dashboard/tools", icon: Link2 },
  { label: "Chat Assistant", href: "/admin/dashboard/chat", icon: MessageCircle },
  { label: "Settings", href: "/admin/dashboard/settings", icon: Settings },
];

export function AdminSidebar({ userEmail, logoUrl }: { userEmail: string; logoUrl?: string | null }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const initials = userEmail.slice(0, 2).toUpperCase();

  const NavLinks = (
    <nav className="flex flex-1 flex-col gap-1 px-3">
      {NAV_ITEMS.map((item) => {
        const isActive =
          item.href === "/admin/dashboard"
            ? pathname === item.href
            : pathname.startsWith(item.href);
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={() => setMobileOpen(false)}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
              isActive
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-accent hover:text-foreground"
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <>
      {/* Mobile top bar */}
      <div className="flex items-center justify-between border-b border-border px-4 py-3 print:hidden md:hidden">
        <Logo href="/admin/dashboard" logoUrl={logoUrl} />
        <div className="flex items-center gap-1">
          <Button asChild variant="ghost" size="icon" aria-label="View live site">
            <Link href="/" target="_blank" rel="noreferrer noopener">
              <ExternalLink className="h-4 w-4" />
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="flex flex-col border-b border-border bg-background py-4 md:hidden">
          {NavLinks}
          <div className="mt-4 border-t border-border px-3 pt-4">
            <SidebarFooter userEmail={userEmail} initials={initials} />
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-border bg-background print:hidden md:flex">
        <div className="px-5 py-6">
          <Logo href="/admin/dashboard" logoUrl={logoUrl} />
        </div>
        <div className="px-3 pb-3">
          <Button asChild variant="outline" size="sm" className="w-full justify-start gap-2">
            <Link href="/" target="_blank" rel="noreferrer noopener">
              <ExternalLink className="h-4 w-4" />
              View Live Site
            </Link>
          </Button>
        </div>
        {NavLinks}
        <div className="border-t border-border p-4">
          <SidebarFooter userEmail={userEmail} initials={initials} />
        </div>
      </aside>
    </>
  );
}

function SidebarFooter({ userEmail, initials }: { userEmail: string; initials: string }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2.5 rounded-xl bg-secondary/60 px-3 py-2.5">
        <Avatar className="h-8 w-8">
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <span className="truncate text-sm font-medium">{userEmail}</span>
      </div>
      <div className="flex items-center gap-2">
        <form action={signOutAction} className="flex-1">
          <Button type="submit" variant="outline" className="w-full justify-start gap-2">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </form>
        <ThemeToggle />
      </div>
    </div>
  );
}
