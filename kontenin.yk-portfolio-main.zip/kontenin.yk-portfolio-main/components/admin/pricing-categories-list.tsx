"use client";

import Link from "next/link";
import { Pencil, Eye, EyeOff, Printer, PlusCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DeletePricingCategoryButton } from "@/components/admin/delete-pricing-category-button";
import { togglePricingPublishedAction, addTierToInvoiceServicesAction } from "@/lib/actions/pricing";
import type { PricingCategory } from "@/types/pricing";

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);
}

async function handleToggle(id: string, next: boolean) {
  const result = await togglePricingPublishedAction(id, next);
  if (result.error) toast.error(result.error);
}

async function handleAddToInvoiceCatalog(tierName: string, price: number, categoryName: string) {
  const result = await addTierToInvoiceServicesAction(tierName, price, categoryName);
  if (result.error) {
    toast.error(result.error);
    return;
  }
  toast.success(`"${tierName}" added to your invoice price list.`);
}

export function PricingCategoriesList({ categories }: { categories: PricingCategory[] }) {
  return (
    <div className="space-y-4">
      {categories.map((category) => (
        <div key={category.id} className="rounded-2xl border border-border p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-semibold">{category.name}</h3>
                <Badge variant={category.is_published ? "success" : "secondary"}>
                  {category.is_published ? "Published" : "Hidden"}
                </Badge>
              </div>
              {category.subtitle && <p className="text-sm text-muted-foreground">{category.subtitle}</p>}
            </div>
            <div className="flex items-center gap-1">
              <Button asChild size="icon" variant="ghost" aria-label={`Print ${category.name}`}>
                <Link href={`/admin/dashboard/pricing/${category.id}/print`} target="_blank">
                  <Printer className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => handleToggle(category.id, !category.is_published)}
                aria-label={category.is_published ? "Hide from public site" : "Publish to public site"}
              >
                {category.is_published ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
              <Button asChild size="icon" variant="ghost" aria-label={`Edit ${category.name}`}>
                <Link href={`/admin/dashboard/pricing/${category.id}/edit`}>
                  <Pencil className="h-4 w-4" />
                </Link>
              </Button>
              <DeletePricingCategoryButton id={category.id} name={category.name} />
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-3">
            {category.tiers.map((tier, i) => (
              <div key={i} className="flex items-center gap-2 rounded-xl border border-border bg-secondary/30 px-4 py-2.5">
                <div>
                  <p className="text-sm font-medium">
                    {tier.name} {tier.badge && <span className="text-xs text-primary">★ {tier.badge}</span>}
                  </p>
                  <p className="text-sm text-muted-foreground">{formatIDR(tier.price)}</p>
                </div>
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7 text-muted-foreground hover:text-foreground"
                  onClick={() => handleAddToInvoiceCatalog(tier.name, tier.price, category.name)}
                  aria-label={`Add ${tier.name} to invoice price list`}
                  title="Add to invoice price list"
                >
                  <PlusCircle className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
