"use client";

interface Series {
  data: { label: string; total: number }[];
  color: string;
  name: string;
}

interface LineChartProps {
  data?: { label: string; total: number }[];
  color?: string;
  series?: Series[];
}

export function LineChart({ data, color = "currentColor", series }: LineChartProps) {
  const allSeries: Series[] = series ?? [{ data: data ?? [], color, name: "" }];
  const labels = allSeries[0]?.data.map((d) => d.label) ?? [];
  const max = Math.max(...allSeries.flatMap((s) => s.data.map((d) => d.total)), 1);
  const width = 100;
  const height = 40;

  function toPoints(seriesData: { label: string; total: number }[]) {
    const stepX = seriesData.length > 1 ? width / (seriesData.length - 1) : 0;
    return seriesData.map((d, i) => {
      const x = seriesData.length > 1 ? i * stepX : width / 2;
      const y = height - (d.total / max) * (height - 6) - 3;
      return { x, y };
    });
  }

  return (
    <div>
      {allSeries.length > 1 && (
        <div className="mb-3 flex gap-4">
          {allSeries.map((s) => (
            <span key={s.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: s.color }} />
              {s.name}
            </span>
          ))}
        </div>
      )}
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="h-32 w-full overflow-visible">
        {allSeries.map((s, si) => {
          const points = toPoints(s.data);
          const linePath = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
          const areaPath = `${linePath} L ${points[points.length - 1]?.x ?? 0} ${height} L ${points[0]?.x ?? 0} ${height} Z`;
          return (
            <g key={si}>
              {allSeries.length === 1 && <path d={areaPath} fill={s.color} fillOpacity={0.08} stroke="none" />}
              <path d={linePath} fill="none" stroke={s.color} strokeWidth={1.2} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
              {points.map((p, i) => (
                <circle key={i} cx={p.x} cy={p.y} r={1.4} fill={s.color} vectorEffect="non-scaling-stroke" />
              ))}
            </g>
          );
        })}
      </svg>
      <div className="mt-2 flex justify-between">
        {labels.map((label, i) => (
          <span key={i} className="text-[10px] text-muted-foreground">
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}
