"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Send, CheckCircle2, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { resolveGlsEntryAction, type CalendarActionState } from "@/lib/actions/calendar";
import type { CalendarGlsEntry } from "@/types/calendar";

const initialState: CalendarActionState = {};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
}

export function CalendarGlsAdminPanel({ calendarId, entries }: { calendarId: string; entries: CalendarGlsEntry[] }) {
  if (entries.length === 0) return null;

  const unresolved = entries.filter((e) => !e.is_resolved);
  const resolved = entries.filter((e) => e.is_resolved);

  return (
    <div className="rounded-2xl border border-border p-5">
      <p className="mb-4 text-sm font-semibold">GLS — Growth Loop System</p>
      <div className="space-y-3">
        {unresolved.map((entry) => (
          <ResolveRow key={entry.id} entry={entry} calendarId={calendarId} />
        ))}
        {resolved.map((entry) => (
          <div key={entry.id} className="rounded-xl border border-border bg-secondary/30 p-3.5">
            <p className="mb-1 text-sm">{entry.client_comment}</p>
            <p className="mb-2 text-sm text-muted-foreground">{entry.resolution}</p>
            <div className="flex items-center justify-between text-[10px] text-muted-foreground">
              <span>{formatDate(entry.created_at)}</span>
              <span className="flex items-center gap-1 font-semibold uppercase tracking-wide text-emerald-600">
                <CheckCircle2 className="h-3 w-3" /> Teratasi
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ResolveRow({ entry, calendarId }: { entry: CalendarGlsEntry; calendarId: string }) {
  const boundAction = resolveGlsEntryAction.bind(null, entry.id, calendarId);
  const [state, formAction] = useActionState(boundAction, initialState);

  return (
    <div className="rounded-xl border border-amber-500/30 bg-amber-500/[0.05] p-3.5">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-sm">{entry.client_comment}</p>
      </div>
      <div className="mb-2 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-amber-600">
        <Circle className="h-3 w-3" /> Menunggu · {formatDate(entry.created_at)}
      </div>
      {state.error && <p className="mb-2 text-xs text-destructive">{state.error}</p>}
      <form action={formAction} className="flex items-center gap-2">
        <Input name="resolution" placeholder="Tulis penyelesaiannya..." required />
        <SubmitButton />
      </form>
    </div>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="icon" disabled={pending} aria-label="Kirim penyelesaian">
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
    </Button>
  );
}
