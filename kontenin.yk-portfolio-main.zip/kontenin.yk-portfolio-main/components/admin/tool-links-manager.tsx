"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { Plus, Loader2, X, ExternalLink, Link2 } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ImageUpload } from "@/components/admin/image-upload";
import { STORAGE_BUCKETS } from "@/lib/constants";
import { addToolLinkAction, deleteToolLinkAction } from "@/lib/actions/tools";
import type { ToolLink } from "@/types/tools";

export function ToolLinksManager({ items: initialItems }: { items: ToolLink[] }) {
  const [items, setItems] = React.useState(initialItems);
  const [name, setName] = React.useState("");
  const [url, setUrl] = React.useState("");
  const [category, setCategory] = React.useState("");
  const [iconUrl, setIconUrl] = React.useState<string | null>(null);
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!name.trim() || !url.trim()) return;

    setIsAdding(true);
    const result = await addToolLinkAction(name.trim(), url.trim(), category.trim(), iconUrl);
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      {
        id: crypto.randomUUID(),
        name: name.trim(),
        url: url.trim(),
        category: category.trim() || null,
        icon_url: iconUrl,
        sort_order: 0,
        created_at: new Date().toISOString(),
      },
      ...prev,
    ]);
    setName("");
    setUrl("");
    setCategory("");
    setIconUrl(null);
    toast.success("Link added.");
  }

  async function handleDelete(item: ToolLink) {
    setDeletingId(item.id);
    const result = await deleteToolLinkAction(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
  }

  const grouped = items.reduce<Record<string, ToolLink[]>>((acc, item) => {
    const key = item.category || "General";
    const existing = acc[key];
    acc[key] = existing ? [...existing, item] : [item];
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add a Link</CardTitle>
          <CardDescription>
            Any resource your team needs quick access to — Drive folders, VFX assets, schedules,
            brand files, anything.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name — e.g. Mentahan Bjaya Land" />
            <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://drive.google.com/..." />
          </div>
          <Input
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="Category (optional) — e.g. Mentahan, VFX & Overlay, Jadwal, Brand Assets"
          />
          <ImageUpload
            label="Icon (optional)"
            bucket={STORAGE_BUCKETS.SITE_ASSETS}
            value={iconUrl}
            onChange={setIconUrl}
            aspectClassName="aspect-square max-w-[80px]"
          />
          <Button type="button" size="sm" onClick={handleAdd} disabled={isAdding || !name.trim() || !url.trim()}>
            {isAdding ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            Add Link
          </Button>
        </CardContent>
      </Card>

      {Object.keys(grouped).length === 0 ? (
        <p className="text-sm text-muted-foreground">No links yet — add your first one above.</p>
      ) : (
        Object.entries(grouped).map(([category, links]) => (
          <div key={category}>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              {category}
            </h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {links.map((link) => (
                <div
                  key={link.id}
                  className="group flex items-center gap-3 rounded-xl border border-border bg-card p-3 transition-colors hover:border-foreground/30"
                >
                  <span className="relative flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-secondary">
                    {link.icon_url ? (
                      <Image src={link.icon_url} alt="" fill sizes="36px" className="object-cover" />
                    ) : (
                      <Link2 className="h-4 w-4 text-muted-foreground" />
                    )}
                  </span>
                  <Link
                    href={link.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="flex min-w-0 flex-1 items-center gap-1.5 text-sm font-medium hover:underline"
                  >
                    <span className="truncate">{link.name}</span>
                    <ExternalLink className="h-3 w-3 shrink-0 text-muted-foreground" />
                  </Link>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={() => handleDelete(link)}
                    disabled={deletingId === link.id}
                    aria-label={`Remove ${link.name}`}
                    className="shrink-0 text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                  >
                    {deletingId === link.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <X className="h-3.5 w-3.5" />
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
