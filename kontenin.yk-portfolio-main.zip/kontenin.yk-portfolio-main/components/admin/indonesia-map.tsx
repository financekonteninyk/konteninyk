"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import type { Client } from "@/types/client";

/** Approximate illustrative positions (percent of the map image's width/height) for major Indonesian cities, calibrated against /public/images/indonesia-map.png specifically. */
const CITY_POSITIONS: Record<string, { x: number; y: number }> = {
  yogyakarta: { x: 42, y: 58 },
  jogja: { x: 42, y: 58 },
  jakarta: { x: 32, y: 54 },
  bandung: { x: 35, y: 55 },
  semarang: { x: 43, y: 55 },
  surabaya: { x: 48, y: 55 },
  malang: { x: 49, y: 58 },
  solo: { x: 43, y: 57 },
  surakarta: { x: 43, y: 57 },
  medan: { x: 3, y: 19 },
  palembang: { x: 13, y: 39 },
  pekanbaru: { x: 8, y: 25 },
  padang: { x: 5, y: 29 },
  batam: { x: 20, y: 19 },
  denpasar: { x: 56, y: 59 },
  bali: { x: 56, y: 59 },
  makassar: { x: 61, y: 46 },
  balikpapan: { x: 50, y: 33 },
  pontianak: { x: 37, y: 26 },
  banjarmasin: { x: 47, y: 41 },
  manado: { x: 65, y: 21 },
  jayapura: { x: 96, y: 41 },
};

const DEFAULT_POSITION: { x: number; y: number } = { x: 42, y: 58 };

function resolvePosition(city: string | null): { x: number; y: number } {
  if (!city) return DEFAULT_POSITION;
  const key = city.trim().toLowerCase();
  return CITY_POSITIONS[key] ?? DEFAULT_POSITION;
}

interface IndonesiaMapProps {
  clients: Pick<Client, "id" | "name" | "logo_url" | "city">[];
}

export function IndonesiaMap({ clients }: IndonesiaMapProps) {
  const hub = DEFAULT_POSITION;

  return (
    <div className="relative aspect-[16/9] w-full overflow-hidden rounded-2xl border border-border bg-black">
      <Image
        src="/images/indonesia-map.png"
        alt="Indonesia"
        fill
        sizes="(max-width: 1024px) 100vw, 900px"
        className="object-cover opacity-90"
        priority
      />

      {/* Connection lines + nodes, in an SVG overlay matching the image's own coordinate space */}
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
        {clients.map((client) => {
          const pos = resolvePosition(client.city);
          return (
            <motion.line
              key={`line-${client.id}`}
              x1={hub.x}
              y1={hub.y}
              x2={pos.x}
              y2={pos.y}
              stroke="#f472b6"
              strokeWidth={0.25}
              strokeDasharray="1.2 1.2"
              initial={{ pathLength: 0, opacity: 0 }}
              whileInView={{ pathLength: 1, opacity: 0.8 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, ease: "easeOut" }}
            />
          );
        })}

        <motion.circle
          cx={hub.x}
          cy={hub.y}
          r={1.4}
          fill="#f472b6"
          fillOpacity={0.25}
          animate={{ r: [1.4, 2.2, 1.4], opacity: [0.5, 0.05, 0.5] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
        />
        <circle cx={hub.x} cy={hub.y} r={0.7} fill="#f472b6" />
      </svg>

      {/* Client logo nodes */}
      <div className="pointer-events-none absolute inset-0">
        <span
          className="absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap rounded-full bg-black/80 px-2 py-0.5 text-[10px] font-semibold text-white shadow-sm"
          style={{ left: `${hub.x}%`, top: `${hub.y - 7}%` }}
        >
          Kontenin.yk HQ
        </span>
        {clients.map((client, i) => {
          const pos = resolvePosition(client.city);
          return (
            <motion.div
              key={client.id}
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.3 + i * 0.08 }}
              className="pointer-events-auto absolute -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
              title={client.name}
            >
              <span className="relative flex h-7 w-7 items-center justify-center overflow-hidden rounded-full border-2 border-white/80 bg-black shadow-[0_0_0_2px_rgba(244,114,182,0.5),0_4px_10px_-2px_rgba(0,0,0,0.6)] sm:h-8 sm:w-8">
                {client.logo_url ? (
                  <Image src={client.logo_url} alt={client.name} fill sizes="32px" className="object-cover" />
                ) : (
                  <span className="text-[9px] font-bold text-white">{client.name.slice(0, 2).toUpperCase()}</span>
                )}
              </span>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
