"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";

const MONTH_NAMES = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];

const WEEKDAY_LABELS = ["M", "S", "S", "R", "K", "J", "S"];

interface CalendarMiniNavProps {
  year: number;
  month: number; // 0-11
  onNavigate: (year: number, month: number) => void;
  /** Dates (YYYY-MM-DD) that have at least one entry — shown as a small dot. */
  markedDates?: Set<string>;
}

function toIsoDate(year: number, month: number, day: number): string {
  const y = String(year).padStart(4, "0");
  const m = String(month + 1).padStart(2, "0");
  const d = String(day).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function CalendarMiniNav({ year, month, onNavigate, markedDates }: CalendarMiniNavProps) {
  function goToMonth(delta: number) {
    let newMonth = month + delta;
    let newYear = year;
    if (newMonth < 0) {
      newMonth = 11;
      newYear -= 1;
    } else if (newMonth > 11) {
      newMonth = 0;
      newYear += 1;
    }
    onNavigate(newYear, newMonth);
  }

  const firstOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leadingBlanks = firstOfMonth.getDay();
  const todayIso = toIsoDate(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

  const cells: { day: number | null; iso: string | null }[] = [];
  for (let i = 0; i < leadingBlanks; i++) cells.push({ day: null, iso: null });
  for (let d = 1; d <= daysInMonth; d++) cells.push({ day: d, iso: toIsoDate(year, month, d) });

  return (
    <div className="rounded-2xl border border-border p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold">
          {MONTH_NAMES[month]} {year}
        </p>
        <div className="flex items-center gap-0.5">
          <button
            type="button"
            onClick={() => goToMonth(-1)}
            aria-label="Bulan sebelumnya"
            className="flex h-6 w-6 items-center justify-center rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => goToMonth(1)}
            aria-label="Bulan berikutnya"
            className="flex h-6 w-6 items-center justify-center rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-y-1">
        {WEEKDAY_LABELS.map((label, i) => (
          <div key={i} className="text-center text-[10px] font-medium text-muted-foreground">
            {label}
          </div>
        ))}
        {cells.map((cell, i) => {
          const isToday = cell.iso === todayIso;
          const hasEntries = cell.iso ? markedDates?.has(cell.iso) : false;
          return (
            <div key={i} className="flex items-center justify-center py-0.5">
              {cell.day !== null && (
                <button
                  type="button"
                  onClick={() => onNavigate(year, month)}
                  className={`relative flex h-6 w-6 items-center justify-center rounded-full text-[11px] transition-colors ${
                    isToday ? "bg-primary font-semibold text-primary-foreground" : "text-foreground hover:bg-secondary"
                  }`}
                >
                  {cell.day}
                  {hasEntries && !isToday && (
                    <span className="absolute bottom-0.5 h-1 w-1 rounded-full bg-primary" />
                  )}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
