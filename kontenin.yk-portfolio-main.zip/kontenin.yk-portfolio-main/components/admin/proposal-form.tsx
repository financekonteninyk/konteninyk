"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PROPOSAL_STATUSES, PROPOSAL_STATUS_LABELS } from "@/types/documents";
import type { Proposal, ScopeItem, InvestmentItem, ProposalStatus } from "@/types/documents";
import type { DocActionState } from "@/lib/actions/documents";

interface ProposalFormProps {
  proposal?: Proposal;
  action: (state: DocActionState, formData: FormData) => Promise<DocActionState>;
}

const initialState: DocActionState = {};

function genProposalNumber(): string {
  const now = new Date();
  return `PROP-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${Math.floor(1000 + Math.random() * 9000)}`;
}

export function ProposalForm({ proposal, action }: ProposalFormProps) {
  const [state, formAction] = useActionState(action, initialState);

  const [proposalNumber, setProposalNumber] = React.useState(proposal?.proposal_number ?? genProposalNumber());
  const [status, setStatus] = React.useState<ProposalStatus>(proposal?.status ?? "draft");
  const [scopeItems, setScopeItems] = React.useState<ScopeItem[]>(
    proposal?.scope_items && proposal.scope_items.length > 0 ? proposal.scope_items : [{ label: "" }]
  );
  const [investmentItems, setInvestmentItems] = React.useState<InvestmentItem[]>(
    proposal?.investment_items && proposal.investment_items.length > 0
      ? proposal.investment_items
      : [{ description: "", price: 0 }]
  );

  return (
    <form action={formAction} className="space-y-8">
      <input type="hidden" name="proposal_number" value={proposalNumber} />
      <input type="hidden" name="status" value={status} />
      <input type="hidden" name="scope_items" value={JSON.stringify(scopeItems.filter((s) => s.label.trim()))} />
      <input
        type="hidden"
        name="investment_items"
        value={JSON.stringify(investmentItems.filter((i) => i.description.trim()))}
      />

      {state.error && <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">{state.error}</p>}

      <div className="space-y-4 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Proposal Info</p>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Proposal Number</Label>
            <Input value={proposalNumber} onChange={(e) => setProposalNumber(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as ProposalStatus)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {PROPOSAL_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>{PROPOSAL_STATUS_LABELS[s]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="client_name">Client Name</Label>
            <Input id="client_name" name="client_name" defaultValue={proposal?.client_name ?? ""} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="client_company">Client Company (optional)</Label>
            <Input id="client_company" name="client_company" defaultValue={proposal?.client_company ?? ""} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="project_title">Project Title</Label>
            <Input id="project_title" name="project_title" defaultValue={proposal?.project_title ?? ""} placeholder="e.g. Instagram Growth Strategy — Kedai Kopi X" required />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="objective">Objective</Label>
            <Input id="objective" name="objective" defaultValue={proposal?.objective ?? ""} placeholder="e.g. Meningkatkan engagement dan penjualan lewat konten konsisten" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="valid_until">Valid Until (optional)</Label>
            <Input id="valid_until" name="valid_until" type="date" defaultValue={proposal?.valid_until ?? ""} />
          </div>
        </div>
      </div>

      <div className="space-y-4 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Background</p>
        <p className="text-xs text-muted-foreground">Konteks singkat — kenapa proposal ini dibuat, situasi brand saat ini.</p>
        <Textarea name="background" defaultValue={proposal?.background ?? ""} rows={4} />
      </div>

      <div className="space-y-4 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Account Analysis (optional)</p>
        <p className="text-xs text-muted-foreground">Kalau kamu audit akun mereka, tulis temuannya di sini.</p>
        <Textarea name="account_analysis" defaultValue={proposal?.account_analysis ?? ""} rows={5} />
      </div>

      <div className="space-y-4 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Proposed Strategy</p>
        <p className="text-xs text-muted-foreground">Ide dan konsep inti yang kamu tawarkan.</p>
        <Textarea name="strategy" defaultValue={proposal?.strategy ?? ""} rows={6} />
      </div>

      <div className="space-y-3 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Scope of Work</p>
        {scopeItems.map((item, i) => (
          <div key={i} className="flex gap-2">
            <Input
              value={item.label}
              onChange={(e) => setScopeItems((prev) => prev.map((s, j) => (j === i ? { label: e.target.value } : s)))}
              placeholder="e.g. 8 konten short form per bulan"
            />
            <Button type="button" size="icon" variant="ghost" onClick={() => setScopeItems((prev) => prev.filter((_, j) => j !== i))}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <Button type="button" size="sm" variant="outline" onClick={() => setScopeItems((prev) => [...prev, { label: "" }])}>
          <Plus className="h-3.5 w-3.5" /> Add Item
        </Button>
      </div>

      <div className="space-y-3 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Investment</p>
        {investmentItems.map((item, i) => (
          <div key={i} className="grid grid-cols-12 gap-2">
            <Input
              className="col-span-8"
              value={item.description}
              onChange={(e) => setInvestmentItems((prev) => prev.map((it, j) => (j === i ? { ...it, description: e.target.value } : it)))}
              placeholder="e.g. Content Strategy + Production (1 bulan)"
            />
            <Input
              className="col-span-3"
              type="number"
              value={item.price}
              onChange={(e) => setInvestmentItems((prev) => prev.map((it, j) => (j === i ? { ...it, price: Number(e.target.value) || 0 } : it)))}
              placeholder="Rp"
            />
            <Button type="button" size="icon" variant="ghost" className="col-span-1" onClick={() => setInvestmentItems((prev) => prev.filter((_, j) => j !== i))}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <Button type="button" size="sm" variant="outline" onClick={() => setInvestmentItems((prev) => [...prev, { description: "", price: 0 }])}>
          <Plus className="h-3.5 w-3.5" /> Add Item
        </Button>
        <div className="space-y-2 pt-2">
          <Label htmlFor="investment_note">Investment Note (optional)</Label>
          <Input id="investment_note" name="investment_note" defaultValue={proposal?.investment_note ?? ""} placeholder="e.g. Harga berlaku untuk 1 bulan pertama" />
        </div>
      </div>

      <div className="space-y-4 rounded-2xl border border-border p-5">
        <p className="text-sm font-semibold">Timeline (optional)</p>
        <Textarea name="timeline" defaultValue={proposal?.timeline ?? ""} rows={4} placeholder={"Minggu 1: Riset & strategi\nMinggu 2: Produksi konten pertama\n..."} />
      </div>

      <SubmitButton isEdit={Boolean(proposal)} />
    </form>
  );
}

function SubmitButton({ isEdit }: { isEdit: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {isEdit ? "Save Changes" : "Create Proposal"}
    </Button>
  );
}
