import { StickyNote, CalendarClock } from "lucide-react";
import type { ContentCalendar } from "@/types/calendar";

function formatDate(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
}

function daysRemaining(endDateIso: string): number {
  const end = new Date(endDateIso + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffMs = end.getTime() - today.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

export function CalendarInfoPanel({ calendar }: { calendar: ContentCalendar }) {
  const hasContractDates = calendar.contract_start_date && calendar.contract_end_date;
  const remaining = calendar.contract_end_date ? daysRemaining(calendar.contract_end_date) : null;

  if (!hasContractDates && !calendar.notes) return null;

  return (
    <div className="space-y-4">
      {hasContractDates && (
        <div className="rounded-2xl border border-border p-4">
          <p className="mb-3 flex items-center gap-1.5 text-sm font-semibold">
            <CalendarClock className="h-4 w-4" />
            Durasi Kerja Sama
          </p>
          {remaining !== null && (
            <div className="mb-3 text-center">
              {remaining > 0 ? (
                <>
                  <p className="text-3xl font-bold tracking-tight text-primary">{remaining}</p>
                  <p className="text-xs text-muted-foreground">hari lagi</p>
                </>
              ) : remaining === 0 ? (
                <p className="text-sm font-semibold text-primary">Berakhir hari ini</p>
              ) : (
                <p className="text-sm font-semibold text-muted-foreground">Kerja sama telah berakhir</p>
              )}
            </div>
          )}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{formatDate(calendar.contract_start_date!)}</span>
            <span>—</span>
            <span>{formatDate(calendar.contract_end_date!)}</span>
          </div>
        </div>
      )}

      {calendar.notes && (
        <div className="rounded-2xl border border-border p-4">
          <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
            <StickyNote className="h-4 w-4" />
            Catatan
          </p>
          <p className="whitespace-pre-line text-sm text-muted-foreground">{calendar.notes}</p>
        </div>
      )}
    </div>
  );
}
