"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ImageUpload } from "@/components/admin/image-upload";
import { TimelineManager } from "@/components/admin/timeline-manager";
import { ValuesManager } from "@/components/admin/values-manager";
import { AwardsManager } from "@/components/admin/awards-manager";
import { GalleryManager } from "@/components/admin/gallery-manager";
import { ActivityPhotosManager } from "@/components/admin/activity-photos-manager";
import { ToolsManager } from "@/components/admin/tools-manager";
import { STORAGE_BUCKETS } from "@/lib/constants";
import { updateSiteSettingsAction, type SettingsActionState } from "@/lib/actions/settings";
import {
  addTimelineItemAction,
  updateTimelineItemAction,
  deleteTimelineItemAction,
  addValueAction,
  updateValueAction,
  deleteValueAction,
  addAwardAction,
  updateAwardAction,
  deleteAwardAction,
  addGalleryImageAction,
  deleteGalleryImageAction,
  addToolAction,
  deleteToolAction,
} from "@/lib/actions/about";
import { addActivityPhotoAction, deleteActivityPhotoAction } from "@/lib/actions/activity";
import type { SiteSettings } from "@/types/settings";
import type { TimelineItem, Value, Award, GalleryImage, Tool } from "@/types/about";
import type { ActivityPhoto } from "@/types/activity";

const initialState: SettingsActionState = {};

interface SettingsFormProps {
  settings: SiteSettings;
  timelineItems: TimelineItem[];
  values: Value[];
  awards: Award[];
  galleryImages: GalleryImage[];
  tools: Tool[];
  activityPhotos: ActivityPhoto[];
}

function BilingualField({
  label,
  idName,
  enName,
  idDefault,
  enDefault,
  idError,
  enError,
  multiline = false,
  rows = 3,
  placeholderId,
  placeholderEn,
}: {
  label: string;
  idName: string;
  enName: string;
  idDefault: string;
  enDefault: string;
  idError?: string;
  enError?: string;
  multiline?: boolean;
  rows?: number;
  placeholderId?: string;
  placeholderEn?: string;
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">🇮🇩 Indonesian</span>
          {multiline ? (
            <Textarea
              name={idName}
              defaultValue={idDefault}
              placeholder={placeholderId}
              rows={rows}
              aria-label={`${label} (Indonesian)`}
            />
          ) : (
            <Input
              name={idName}
              defaultValue={idDefault}
              placeholder={placeholderId}
              aria-label={`${label} (Indonesian)`}
            />
          )}
          {idError && <p className="text-xs text-destructive">{idError}</p>}
        </div>
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">🇬🇧 English</span>
          {multiline ? (
            <Textarea
              name={enName}
              defaultValue={enDefault}
              placeholder={placeholderEn}
              rows={rows}
              aria-label={`${label} (English)`}
            />
          ) : (
            <Input
              name={enName}
              defaultValue={enDefault}
              placeholder={placeholderEn}
              aria-label={`${label} (English)`}
            />
          )}
          {enError && <p className="text-xs text-destructive">{enError}</p>}
        </div>
      </div>
    </div>
  );
}

export function SettingsForm({
  settings,
  timelineItems,
  values,
  awards,
  galleryImages,
  tools,
  activityPhotos,
}: SettingsFormProps) {
  const [state, formAction] = useActionState(updateSiteSettingsAction, initialState);
  const [logoUrl, setLogoUrl] = React.useState<string | null>(settings.site_logo_url);
  const [heroLogoUrl, setHeroLogoUrl] = React.useState<string | null>(settings.hero_logo_url);
  const [chatBotLogoUrl, setChatBotLogoUrl] = React.useState<string | null>(settings.chat_bot_logo_url);
  const [whatsappIconUrl, setWhatsappIconUrl] = React.useState<string | null>(settings.whatsapp_icon_url);
  const [glsIconUrl, setGlsIconUrl] = React.useState<string | null>(settings.gls_icon_url);
  const [qrisUrl, setQrisUrl] = React.useState<string | null>(settings.invoice_qris_url);

  React.useEffect(() => {
    if (state.success) toast.success("Settings saved.");
  }, [state.success]);

  const fieldError = (key: string) => state.fieldErrors?.[key];

  return (
    <div className="space-y-8">
      <form action={formAction} className="space-y-8">
        <input type="hidden" name="site_logo_url" value={logoUrl ?? ""} />
        <input type="hidden" name="hero_logo_url" value={heroLogoUrl ?? ""} />
        <input type="hidden" name="chat_bot_logo_url" value={chatBotLogoUrl ?? ""} />
        <input type="hidden" name="whatsapp_icon_url" value={whatsappIconUrl ?? ""} />
        <input type="hidden" name="gls_icon_url" value={glsIconUrl ?? ""} />
        <input type="hidden" name="invoice_qris_url" value={qrisUrl ?? ""} />

        {state.error && (
          <p className="rounded-lg bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive">
            {state.error}
          </p>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Brand</CardTitle>
            <CardDescription>
              Your header logo (shown in the nav bar and admin sidebar) and site-wide tagline —
              editable in both languages.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <ImageUpload
              label="Header Logo"
              bucket={STORAGE_BUCKETS.SITE_ASSETS}
              value={logoUrl}
              onChange={setLogoUrl}
              aspectClassName="aspect-square max-w-[160px]"
            />

            <BilingualField
              label="Tagline"
              idName="tagline_id"
              enName="tagline_en"
              idDefault={settings.tagline_id ?? ""}
              enDefault={settings.tagline_en ?? ""}
              idError={fieldError("tagline_id")}
              enError={fieldError("tagline_en")}
              placeholderId="Membantu brand membangun konten yang konsisten..."
              placeholderEn="Helping brands build consistent content..."
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Main Menu</CardTitle>
            <CardDescription>Every label in the header navigation, in both languages.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <BilingualField
              label="Portfolio Link"
              idName="nav_portfolio_id"
              enName="nav_portfolio_en"
              idDefault={settings.nav_portfolio_id ?? ""}
              enDefault={settings.nav_portfolio_en ?? ""}
              idError={fieldError("nav_portfolio_id")}
              enError={fieldError("nav_portfolio_en")}
            />
            <BilingualField
              label="How We Work Link"
              idName="nav_process_id"
              enName="nav_process_en"
              idDefault={settings.nav_process_id ?? ""}
              enDefault={settings.nav_process_en ?? ""}
              idError={fieldError("nav_process_id")}
              enError={fieldError("nav_process_en")}
            />
            <BilingualField
              label="Services Link"
              idName="nav_services_id"
              enName="nav_services_en"
              idDefault={settings.nav_services_id ?? ""}
              enDefault={settings.nav_services_en ?? ""}
              idError={fieldError("nav_services_id")}
              enError={fieldError("nav_services_en")}
            />
            <BilingualField
              label="About Link"
              idName="nav_about_id"
              enName="nav_about_en"
              idDefault={settings.nav_about_id ?? ""}
              enDefault={settings.nav_about_en ?? ""}
              idError={fieldError("nav_about_id")}
              enError={fieldError("nav_about_en")}
            />
            <BilingualField
              label="Header CTA Button (links to your WhatsApp)"
              idName="nav_cta_id"
              enName="nav_cta_en"
              idDefault={settings.nav_cta_id ?? ""}
              enDefault={settings.nav_cta_en ?? ""}
              idError={fieldError("nav_cta_id")}
              enError={fieldError("nav_cta_en")}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hero Logo</CardTitle>
            <CardDescription>
              A larger logo shown at the top of the homepage Hero. Optional — leave empty to reuse
              the Header Logo above. You control its exact size here.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <ImageUpload
              label="Hero Logo (optional)"
              bucket={STORAGE_BUCKETS.SITE_ASSETS}
              value={heroLogoUrl}
              onChange={setHeroLogoUrl}
              aspectClassName="aspect-square max-w-[200px]"
            />

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="hero_logo_width">Width (px)</Label>
                <Input
                  id="hero_logo_width"
                  name="hero_logo_width"
                  type="number"
                  min={40}
                  max={600}
                  defaultValue={settings.hero_logo_width}
                />
                {fieldError("hero_logo_width") && (
                  <p className="text-xs text-destructive">{fieldError("hero_logo_width")}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="hero_logo_height">Height (px)</Label>
                <Input
                  id="hero_logo_height"
                  name="hero_logo_height"
                  type="number"
                  min={20}
                  max={600}
                  defaultValue={settings.hero_logo_height}
                />
                {fieldError("hero_logo_height") && (
                  <p className="text-xs text-destructive">{fieldError("hero_logo_height")}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hero Section</CardTitle>
            <CardDescription>Editable content for the homepage hero, in both languages.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <BilingualField
              label="Badge Text"
              idName="hero_badge_text_id"
              enName="hero_badge_text_en"
              idDefault={settings.hero_badge_text_id ?? ""}
              enDefault={settings.hero_badge_text_en ?? ""}
              idError={fieldError("hero_badge_text_id")}
              enError={fieldError("hero_badge_text_en")}
              placeholderId="Studio Produksi Konten"
              placeholderEn="Content Production Studio"
            />

            <BilingualField
              label="Heading"
              idName="hero_heading_id"
              enName="hero_heading_en"
              idDefault={settings.hero_heading_id ?? ""}
              enDefault={settings.hero_heading_en ?? ""}
              idError={fieldError("hero_heading_id")}
              enError={fieldError("hero_heading_en")}
            />

            <BilingualField
              label="Description"
              idName="hero_description_id"
              enName="hero_description_en"
              idDefault={settings.hero_description_id ?? ""}
              enDefault={settings.hero_description_en ?? ""}
              idError={fieldError("hero_description_id")}
              enError={fieldError("hero_description_en")}
              multiline
              rows={3}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Growth Loop System Icon</CardTitle>
            <CardDescription>
              Optional custom icon shown for the "Growth Loop" step and closing note in the How We
              Work section. Leave empty to use the default icon.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ImageUpload
              label="GLS Icon"
              bucket={STORAGE_BUCKETS.SITE_ASSETS}
              value={glsIconUrl}
              onChange={setGlsIconUrl}
              aspectClassName="aspect-square max-w-[100px]"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Stats Line</CardTitle>
            <CardDescription>
              A short proof line (e.g. "100+ pieces of content") shown on the homepage. You control
              the number yourself — it isn't calculated automatically.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <BilingualField
              label="Stats Text"
              idName="stats_text_id"
              enName="stats_text_en"
              idDefault={settings.stats_text_id ?? ""}
              enDefault={settings.stats_text_en ?? ""}
              idError={fieldError("stats_text_id")}
              enError={fieldError("stats_text_en")}
              placeholderId="100+ Konten Diproduksi Untuk Klien Kami"
              placeholderEn="100+ Pieces Of Content Produced For Our Clients"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>WhatsApp / Chat Widget</CardTitle>
            <CardDescription>
              A separate WhatsApp button (opens WA directly) plus the "CS Kontenin.yk" chat
              assistant both use this number.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="whatsapp_url">WhatsApp Link</Label>
              <Input
                id="whatsapp_url"
                name="whatsapp_url"
                type="url"
                defaultValue={settings.whatsapp_url ?? ""}
                placeholder="https://wa.me/6281234567890"
              />
              <p className="text-xs text-muted-foreground">
                Format: https://wa.me/62 followed by your number without the leading 0.
              </p>
              {fieldError("whatsapp_url") && (
                <p className="text-xs text-destructive">{fieldError("whatsapp_url")}</p>
              )}
            </div>

            <ImageUpload
              label="WhatsApp Button Icon (optional)"
              bucket={STORAGE_BUCKETS.SITE_ASSETS}
              value={whatsappIconUrl}
              onChange={setWhatsappIconUrl}
              aspectClassName="aspect-square max-w-[100px]"
            />

            <ImageUpload
              label="Chat Assistant Logo (optional)"
              bucket={STORAGE_BUCKETS.SITE_ASSETS}
              value={chatBotLogoUrl}
              onChange={setChatBotLogoUrl}
              aspectClassName="aspect-square max-w-[120px]"
            />
            <p className="text-xs text-muted-foreground">
              CS Kontenin.yk's answers now come entirely from the Q&A CSV you upload in{" "}
              <b>Admin → Chat Assistant</b>.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>About</CardTitle>
            <CardDescription>
              The summary shown on the homepage, plus Vision & Mission shown on the full{" "}
              <code>/about</code> page — in both languages.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <BilingualField
              label="Homepage Summary"
              idName="about_text_id"
              enName="about_text_en"
              idDefault={settings.about_text_id ?? ""}
              enDefault={settings.about_text_en ?? ""}
              idError={fieldError("about_text_id")}
              enError={fieldError("about_text_en")}
              multiline
              rows={4}
            />

            <BilingualField
              label="Vision (optional)"
              idName="about_vision_id"
              enName="about_vision_en"
              idDefault={settings.about_vision_id ?? ""}
              enDefault={settings.about_vision_en ?? ""}
              idError={fieldError("about_vision_id")}
              enError={fieldError("about_vision_en")}
              multiline
              rows={3}
            />

            <BilingualField
              label="Mission (optional)"
              idName="about_mission_id"
              enName="about_mission_en"
              idDefault={settings.about_mission_id ?? ""}
              enDefault={settings.about_mission_en ?? ""}
              idError={fieldError("about_mission_id")}
              enError={fieldError("about_mission_en")}
              multiline
              rows={3}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Invoice Company Profile</CardTitle>
            <CardDescription>
              Shown on every invoice document — the "Issued By" side. Your Header Logo (Brand card
              above) is reused as the invoice logo.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="invoice_company_name">Company Name</Label>
                <Input
                  id="invoice_company_name"
                  name="invoice_company_name"
                  defaultValue={settings.invoice_company_name ?? ""}
                  placeholder="Kontenin.yk"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoice_company_sub">Sub Header</Label>
                <Input
                  id="invoice_company_sub"
                  name="invoice_company_sub"
                  defaultValue={settings.invoice_company_sub ?? ""}
                  placeholder="Creative Agency"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="invoice_company_address">Corporate Address</Label>
              <Textarea
                id="invoice_company_address"
                name="invoice_company_address"
                defaultValue={settings.invoice_company_address ?? ""}
                rows={2}
              />
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="invoice_company_email">Business Email</Label>
                <Input
                  id="invoice_company_email"
                  name="invoice_company_email"
                  type="email"
                  defaultValue={settings.invoice_company_email ?? ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoice_company_wa">WhatsApp Support</Label>
                <Input
                  id="invoice_company_wa"
                  name="invoice_company_wa"
                  defaultValue={settings.invoice_company_wa ?? ""}
                  placeholder="+62 812-3456-789"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoice_company_web">Website</Label>
                <Input
                  id="invoice_company_web"
                  name="invoice_company_web"
                  defaultValue={settings.invoice_company_web ?? ""}
                  placeholder="www.konteninyk.agency"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoice_company_npwp">Tax ID / NPWP (optional)</Label>
                <Input
                  id="invoice_company_npwp"
                  name="invoice_company_npwp"
                  defaultValue={settings.invoice_company_npwp ?? ""}
                />
              </div>
            </div>

            <ImageUpload
              label="Master QRIS Code (optional)"
              bucket={STORAGE_BUCKETS.SITE_ASSETS}
              value={qrisUrl}
              onChange={setQrisUrl}
              aspectClassName="aspect-square max-w-[140px]"
            />

            <div className="space-y-2">
              <Label htmlFor="invoice_footer_note">Invoice Footer Note</Label>
              <Textarea
                id="invoice_footer_note"
                name="invoice_footer_note"
                defaultValue={settings.invoice_footer_note ?? ""}
                rows={2}
              />
            </div>
          </CardContent>
        </Card>

        <SubmitButton />
      </form>

      <TimelineManager
        items={timelineItems}
        onAdd={addTimelineItemAction}
        onUpdate={updateTimelineItemAction}
        onDelete={deleteTimelineItemAction}
      />

      <ValuesManager items={values} onAdd={addValueAction} onUpdate={updateValueAction} onDelete={deleteValueAction} />

      <AwardsManager items={awards} onAdd={addAwardAction} onUpdate={updateAwardAction} onDelete={deleteAwardAction} />

      <GalleryManager items={galleryImages} onAdd={addGalleryImageAction} onDelete={deleteGalleryImageAction} />

      <ActivityPhotosManager items={activityPhotos} onAdd={addActivityPhotoAction} onDelete={deleteActivityPhotoAction} />

      <ToolsManager items={tools} onAdd={addToolAction} onDelete={deleteToolAction} />
    </div>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      Save Settings
    </Button>
  );
}
