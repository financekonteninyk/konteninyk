"use client";

import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import type { ChatQaEntry } from "@/types/chat";

interface QaEntriesSummaryProps {
  items: ChatQaEntry[];
  onClearAll: () => Promise<{ error?: string }>;
}

export function QaEntriesSummary({ items, onClearAll }: QaEntriesSummaryProps) {
  async function handleClearAll() {
    if (items.length === 0) return;
    if (!confirm(`Remove all ${items.length} Q&A entries? Upload a new CSV afterward to replace them.`)) return;

    const result = await onClearAll();
    if (result.error) {
      toast.error(result.error);
      return;
    }
    toast.success("All Q&A entries removed.");
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Currently Loaded Q&A</CardTitle>
        <CardDescription>
          Read-only — all Q&A content is managed by uploading a CSV above. Clear everything here
          first if you want to start fresh with a new file.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {items.length === 0 ? (
          <EmptyState title="No Q&A loaded yet" description="Upload a CSV above to get started." />
        ) : (
          <>
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">{items.length}</span> entr
              {items.length === 1 ? "y" : "ies"} loaded
            </p>
            <div className="flex max-h-64 flex-wrap gap-1.5 overflow-y-auto">
              {items.map((item) => (
                <Badge key={item.id} variant="secondary">
                  {item.keywords[0]}
                  {item.keywords.length > 1 ? ` +${item.keywords.length - 1}` : ""}
                </Badge>
              ))}
            </div>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={handleClearAll}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Clear All
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
