"use client";

import * as React from "react";
import { Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PrintButton } from "@/components/admin/print-button";

interface PrintThemeWrapperProps {
  children: (theme: "light" | "dark") => React.ReactNode;
  maxWidthClassName?: string;
}

export function PrintThemeWrapper({ children, maxWidthClassName = "max-w-2xl" }: PrintThemeWrapperProps) {
  const [theme, setTheme] = React.useState<"light" | "dark">("light");

  return (
    <div className={`mx-auto ${maxWidthClassName} py-8`}>
      <div className="mb-4 flex items-center justify-end gap-2 print:hidden">
        <Button type="button" variant="outline" onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}>
          {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          {theme === "light" ? "Switch to Dark" : "Switch to Light"}
        </Button>
        <PrintButton />
      </div>
      {children(theme)}
    </div>
  );
}
