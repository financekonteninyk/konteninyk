"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Pencil, Printer, Copy, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
} from "@/components/ui/select";
import { InvoiceStatusBadge } from "@/components/admin/invoice-status-badge";
import { DeleteInvoiceButton } from "@/components/admin/delete-invoice-button";
import { updateInvoiceStatusAction, duplicateInvoiceAction } from "@/lib/actions/tools";
import { formatDate } from "@/lib/utils";
import { INVOICE_STATUSES, INVOICE_STATUS_LABELS } from "@/types/tools";
import type { Invoice, InvoiceStatus, InvoiceCurrency } from "@/types/tools";

const CURRENCY_LOCALE: Record<InvoiceCurrency, string> = {
  IDR: "id-ID",
  USD: "en-US",
  SGD: "en-SG",
  EUR: "de-DE",
  MYR: "ms-MY",
};

function formatMoney(value: number, currency: InvoiceCurrency): string {
  return new Intl.NumberFormat(CURRENCY_LOCALE[currency], {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(value);
}

async function handleStatusChange(id: string, status: InvoiceStatus) {
  const result = await updateInvoiceStatusAction(id, status);
  if (result.error) toast.error(result.error);
}

export function InvoicesTable({ invoices }: { invoices: Invoice[] }) {
  const router = useRouter();
  const [duplicatingId, setDuplicatingId] = React.useState<string | null>(null);

  async function handleDuplicate(id: string) {
    setDuplicatingId(id);
    const result = await duplicateInvoiceAction(id);
    setDuplicatingId(null);

    if (result.error || !result.newId) {
      toast.error(result.error ?? "Failed to duplicate invoice.");
      return;
    }

    toast.success("Invoice duplicated — opening the copy now.");
    router.push(`/admin/dashboard/invoices/${result.newId}/edit`);
  }

  return (
    <div className="overflow-x-auto rounded-2xl border border-border">
      <table className="w-full min-w-[760px] text-left text-sm">
        <thead className="border-b border-border bg-secondary/40 text-xs uppercase tracking-wide text-muted-foreground">
          <tr>
            <th className="px-4 py-3 font-medium">Invoice</th>
            <th className="px-4 py-3 font-medium">Client</th>
            <th className="px-4 py-3 font-medium">Type</th>
            <th className="px-4 py-3 font-medium">Issued</th>
            <th className="px-4 py-3 font-medium">Total</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {invoices.map((invoice) => (
            <tr key={invoice.id} className="transition-colors hover:bg-accent/30">
              <td className="px-4 py-3 font-medium">{invoice.invoice_number}</td>
              <td className="px-4 py-3">{invoice.client_name}</td>
              <td className="px-4 py-3 text-xs text-muted-foreground">
                {invoice.doc_type === "keluar" ? "Out" : "In"}
              </td>
              <td className="px-4 py-3 text-muted-foreground">{formatDate(invoice.issue_date)}</td>
              <td className="px-4 py-3 font-medium">{formatMoney(invoice.total, invoice.currency)}</td>
              <td className="px-4 py-3">
                <Select
                  value={invoice.status}
                  onValueChange={(v) => handleStatusChange(invoice.id, v as InvoiceStatus)}
                >
                  <SelectTrigger className="h-8 w-32 border-none bg-transparent p-0 shadow-none">
                    <InvoiceStatusBadge status={invoice.status} />
                  </SelectTrigger>
                  <SelectContent>
                    {INVOICE_STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {INVOICE_STATUS_LABELS[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </td>
              <td className="px-4 py-3">
                <div className="flex items-center justify-end gap-1">
                  <Button asChild variant="ghost" size="icon" aria-label={`Print ${invoice.invoice_number}`}>
                    <Link href={`/admin/dashboard/invoices/${invoice.id}/print`} target="_blank">
                      <Printer className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" size="icon" aria-label={`Edit ${invoice.invoice_number}`}>
                    <Link href={`/admin/dashboard/invoices/${invoice.id}/edit`}>
                      <Pencil className="h-4 w-4" />
                    </Link>
                  </Button>
                  <DeleteInvoiceButton invoiceId={invoice.id} invoiceNumber={invoice.invoice_number} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
