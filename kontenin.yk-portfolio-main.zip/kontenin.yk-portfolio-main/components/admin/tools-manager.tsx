"use client";

import * as React from "react";
import Image from "next/image";
import { Plus, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { ImageUpload } from "@/components/admin/image-upload";
import { STORAGE_BUCKETS } from "@/lib/constants";
import type { Tool } from "@/types/about";

interface ToolsManagerProps {
  items: Tool[];
  onAdd: (name: string, logoUrl: string | null) => Promise<{ error?: string }>;
  onDelete: (id: string) => Promise<{ error?: string }>;
}

export function ToolsManager({ items: initialItems, onAdd, onDelete }: ToolsManagerProps) {
  const [items, setItems] = React.useState(initialItems);
  const [newName, setNewName] = React.useState("");
  const [newLogoUrl, setNewLogoUrl] = React.useState<string | null>(null);
  const [isAdding, setIsAdding] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  async function handleAdd() {
    if (!newName.trim()) return;
    setIsAdding(true);
    const result = await onAdd(newName.trim(), newLogoUrl);
    setIsAdding(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        name: newName.trim(),
        logo_url: newLogoUrl,
        sort_order: prev.length,
        created_at: new Date().toISOString(),
      },
    ]);
    setNewName("");
    setNewLogoUrl(null);
    toast.success("Tool added.");
  }

  async function handleDelete(item: Tool) {
    setDeletingId(item.id);
    const result = await onDelete(item.id);
    setDeletingId(null);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    setItems((prev) => prev.filter((i) => i.id !== item.id));
    toast.success(`"${item.name}" removed.`);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tools</CardTitle>
        <CardDescription>Tools & software the team uses, shown on the /about page.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-3 rounded-xl border border-dashed border-border p-4">
          <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Tool name" />
          <ImageUpload
            label="Logo (optional)"
            bucket={STORAGE_BUCKETS.ABOUT_ASSETS}
            value={newLogoUrl}
            onChange={setNewLogoUrl}
            aspectClassName="aspect-square max-w-[100px]"
          />
          <Button type="button" size="sm" onClick={handleAdd} disabled={isAdding || !newName.trim()}>
            {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add Tool
          </Button>
        </div>

        {items.length === 0 ? (
          <EmptyState title="No tools yet" description="Add your first one above." />
        ) : (
          <div className="flex flex-wrap gap-2">
            {items.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-2 rounded-full border border-border py-1.5 pl-1.5 pr-3"
              >
                {item.logo_url ? (
                  <span className="relative h-6 w-6 shrink-0 overflow-hidden rounded-full bg-muted">
                    <Image src={item.logo_url} alt={item.name} fill sizes="24px" className="object-cover" />
                  </span>
                ) : (
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-semibold">
                    {item.name.slice(0, 2).toUpperCase()}
                  </span>
                )}
                <span className="text-sm font-medium">{item.name}</span>
                <button
                  type="button"
                  onClick={() => handleDelete(item)}
                  disabled={deletingId === item.id}
                  aria-label={`Remove ${item.name}`}
                  className="flex h-4 w-4 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-destructive hover:text-destructive-foreground"
                >
                  {deletingId === item.id ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <X className="h-3 w-3" />
                  )}
                </button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
