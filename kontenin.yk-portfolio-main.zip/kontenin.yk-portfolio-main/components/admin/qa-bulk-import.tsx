"use client";

import * as React from "react";
import { Upload, Download, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { parseQaCsv, type ParsedQaRow } from "@/lib/csv";
import { bulkImportQaEntriesAction } from "@/lib/actions/chat";

const TEMPLATE_CSV = `keywords,answer_1,answer_2,answer_3
"jam operasional; buka jam berapa; jam buka","Kami biasanya aktif Senin-Sabtu jam 09.00-17.00 WIB.","Tim kami online Senin-Sabtu jam 9 pagi sampai 5 sore ya!",""
"lokasi kantor; alamat kantor; dimana kantornya","Kami berbasis di Daerah Istimewa Yogyakarta.","Kantor kami ada di Yogyakarta, tapi kami melayani klien dari seluruh Indonesia.",""
"minimal kontrak; durasi kerja sama; berapa lama kontrak","Durasi kerja sama biasanya kami sesuaikan dengan kebutuhan brand kamu — bisa dibahas langsung via WhatsApp.","",""
`;

function downloadTemplate() {
  const blob = new Blob([TEMPLATE_CSV], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "kontenin-qa-template.csv";
  link.click();
  URL.revokeObjectURL(url);
}

export function QaBulkImport() {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [preview, setPreview] = React.useState<ParsedQaRow[] | null>(null);
  const [fileName, setFileName] = React.useState<string | null>(null);
  const [isImporting, setIsImporting] = React.useState(false);

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === "string" ? reader.result : "";
      const rows = parseQaCsv(text);
      setPreview(rows);
      setFileName(file.name);
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  async function handleImport() {
    if (!preview || preview.length === 0) return;

    setIsImporting(true);
    const result = await bulkImportQaEntriesAction(preview);
    setIsImporting(false);

    if (result.error) {
      toast.error(result.error);
      return;
    }

    toast.success(
      `Imported ${result.importedCount} entries${
        result.skippedCount ? ` (${result.skippedCount} skipped — check for empty rows)` : ""
      }. Reload the page to see them below.`
    );
    setPreview(null);
    setFileName(null);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Bulk Import (CSV)</CardTitle>
        <CardDescription>
          Prepare many Q&A entries at once in a spreadsheet, export as CSV, and upload here —
          faster than adding them one by one below.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" size="sm" onClick={downloadTemplate}>
            <Download className="h-3.5 w-3.5" />
            Download Template
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-3.5 w-3.5" />
            Upload CSV
          </Button>
          <input ref={fileInputRef} type="file" accept=".csv,text/csv" onChange={handleFileSelect} className="hidden" />
        </div>

        <div className="rounded-xl bg-secondary/50 p-4 text-xs text-muted-foreground">
          <p className="font-medium text-foreground">Format (4 columns):</p>
          <p className="mt-1">
            <code className="rounded bg-background px-1 py-0.5">keywords</code>,{" "}
            <code className="rounded bg-background px-1 py-0.5">answer_1</code>,{" "}
            <code className="rounded bg-background px-1 py-0.5">answer_2</code>,{" "}
            <code className="rounded bg-background px-1 py-0.5">answer_3</code>
          </p>
          <p className="mt-2">
            Put multiple trigger words in the <code className="rounded bg-background px-1 py-0.5">keywords</code>{" "}
            cell separated by semicolons, e.g. <code className="rounded bg-background px-1 py-0.5">jam buka; jam operasional</code>.
            Only <code className="rounded bg-background px-1 py-0.5">answer_1</code> is required — leave{" "}
            <code className="rounded bg-background px-1 py-0.5">answer_2</code>/
            <code className="rounded bg-background px-1 py-0.5">answer_3</code> blank if you don't need
            extra variants.
          </p>
        </div>

        {preview && (
          <div className="space-y-3 rounded-xl border border-border p-4">
            <div className="flex items-center gap-2 text-sm font-medium">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              {fileName} — {preview.length} row{preview.length === 1 ? "" : "s"} ready to import
            </div>

            <div className="max-h-48 space-y-2 overflow-y-auto text-xs">
              {preview.slice(0, 5).map((row, i) => (
                <div key={i} className="rounded-lg bg-secondary/50 p-2">
                  <p className="font-medium">{row.keywords.join(", ")}</p>
                  <p className="text-muted-foreground">{row.answer_1}</p>
                </div>
              ))}
              {preview.length > 5 && (
                <p className="text-muted-foreground">...and {preview.length - 5} more</p>
              )}
            </div>

            <div className="flex gap-2">
              <Button type="button" size="sm" onClick={handleImport} disabled={isImporting}>
                {isImporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
                Import {preview.length} Entries
              </Button>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => {
                  setPreview(null);
                  setFileName(null);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
