"use client";

import * as React from "react";
import { Eye, EyeOff, TrendingUp, TrendingDown } from "lucide-react";

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);
}

interface BalanceCardProps {
  balance: number;
  totalIncome: number;
  totalExpenses: number;
}

export function BalanceCard({ balance, totalIncome, totalExpenses }: BalanceCardProps) {
  const [hidden, setHidden] = React.useState(true);
  const isPositive = balance >= 0;

  return (
    <div className="grid grid-cols-1 divide-y divide-border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
      <div className="p-6">
        <div className="flex items-center justify-between">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Balance</p>
          <button
            type="button"
            onClick={() => setHidden((v) => !v)}
            aria-label={hidden ? "Show balance" : "Hide balance"}
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {hidden ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        <p
          className={`mt-2 text-3xl font-bold tracking-tight transition-all ${
            isPositive ? "text-foreground" : "text-destructive"
          } ${hidden ? "select-none blur-md" : ""}`}
        >
          {formatIDR(balance)}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">Paid invoices (IDR) minus all expenses</p>
      </div>
      <div className="p-6">
        <p className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
          Total Income
        </p>
        <p className={`mt-2 text-2xl font-semibold tracking-tight transition-all ${hidden ? "select-none blur-md" : ""}`}>
          {formatIDR(totalIncome)}
        </p>
      </div>
      <div className="p-6">
        <p className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          <TrendingDown className="h-3.5 w-3.5 text-destructive" />
          Total Expenses
        </p>
        <p className={`mt-2 text-2xl font-semibold tracking-tight transition-all ${hidden ? "select-none blur-md" : ""}`}>
          {formatIDR(totalExpenses)}
        </p>
      </div>
    </div>
  );
}
