"use client";

import { useRouter } from "next/navigation";
import { DeleteButton } from "@/components/admin/delete-button";
import { deleteClientAction } from "@/lib/actions/clients";

export function DeleteClientButton({ clientId, clientName }: { clientId: string; clientName: string }) {
  const router = useRouter();

  return (
    <DeleteButton
      itemLabel={clientName}
      confirmDescription={
        <>
          This will permanently delete <span className="font-medium">&quot;{clientName}&quot;</span> and
          all of its videos. This action cannot be undone.
        </>
      }
      onDelete={() => deleteClientAction(clientId)}
      onDeleted={() => router.refresh()}
    />
  );
}
