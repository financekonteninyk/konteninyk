import Image from "next/image";
import { ImageOff } from "lucide-react";
import type { InvoiceLineItem, InvoiceStatus, InvoiceCurrency, InvoiceBankAccount } from "@/types/tools";

const CURRENCY_FORMAT: Record<InvoiceCurrency, { locale: string; currency: string }> = {
  IDR: { locale: "id-ID", currency: "IDR" },
  USD: { locale: "en-US", currency: "USD" },
  SGD: { locale: "en-SG", currency: "SGD" },
  EUR: { locale: "de-DE", currency: "EUR" },
  MYR: { locale: "ms-MY", currency: "MYR" },
};

function formatMoney(value: number, currency: InvoiceCurrency): string {
  const { locale, currency: code } = CURRENCY_FORMAT[currency];
  return new Intl.NumberFormat(locale, { style: "currency", currency: code, maximumFractionDigits: 0 }).format(
    value
  );
}

const STATUS_STAMP: Record<InvoiceStatus, { label: string; className: string }> = {
  draft: { label: "Draft", className: "bg-slate-100 text-slate-600 border-slate-200" },
  unpaid: { label: "Unpaid", className: "bg-amber-100 text-amber-800 border-amber-200" },
  paid: { label: "Paid", className: "bg-sky-100 text-blue-800 border-sky-200" },
  partially_paid: { label: "Partially Paid", className: "bg-amber-100 text-amber-800 border-amber-200" },
  cancelled: { label: "Cancelled", className: "bg-slate-100 text-slate-500 border-slate-200" },
};

const BORDER_TOP: Record<InvoiceStatus, string> = {
  draft: "border-t-slate-500",
  unpaid: "border-t-amber-600",
  paid: "border-t-blue-800",
  partially_paid: "border-t-amber-600",
  cancelled: "border-t-slate-400",
};

export interface InvoicePreviewProps {
  invoiceNumber: string;
  docType: "keluar" | "masuk";
  status: InvoiceStatus;
  issueDate: string;
  dueDate: string;
  paymentPurpose: string;
  clientName: string;
  clientCompany: string;
  clientContact: string;
  clientLogoUrl: string | null;
  agencyLogoUrl: string | null;
  companyName: string;
  companySub: string;
  companyAddress: string;
  companyContact: string;
  items: InvoiceLineItem[];
  currency: InvoiceCurrency;
  discountPercent: number;
  taxPercent: number;
  bankAccount: InvoiceBankAccount | null;
  showQris: boolean;
  qrisUrl: string | null;
  footerNote: string;
  printTargetId?: string;
  theme?: "light" | "dark";
}

export function InvoicePreview({
  invoiceNumber,
  docType,
  status,
  issueDate,
  dueDate,
  paymentPurpose,
  clientName,
  clientCompany,
  clientContact,
  clientLogoUrl,
  agencyLogoUrl,
  companyName,
  companySub,
  companyAddress,
  companyContact,
  items,
  currency,
  discountPercent,
  taxPercent,
  bankAccount,
  showQris,
  qrisUrl,
  footerNote,
  printTargetId,
  theme = "light",
}: InvoicePreviewProps) {
  const subtotal = items.reduce((sum, item) => sum + (item.quantity || 0) * (item.unit_price || 0), 0);
  const discountAmount = subtotal * (discountPercent / 100);
  const afterDiscount = subtotal - discountAmount;
  const taxAmount = afterDiscount * (taxPercent / 100);
  const grandTotal = afterDiscount + taxAmount;
  const stamp = STATUS_STAMP[status];

  return (
    <div
      id={printTargetId}
      data-invoice-theme={theme}
      className={`rounded-lg border-t-[10px] bg-white p-8 text-[13px] leading-relaxed text-slate-800 shadow-2xl sm:p-12 ${BORDER_TOP[status]}`}
    >
      <div className="mb-10 flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="flex h-[60px] w-[60px] shrink-0 items-center justify-center overflow-hidden rounded-lg border border-dashed border-slate-300 bg-slate-50">
            {agencyLogoUrl ? (
              <Image
                src={agencyLogoUrl}
                alt=""
                width={60}
                height={60}
                className={`h-full w-full object-contain ${theme === "dark" ? "invert" : ""}`}
              />
            ) : (
              <span className="text-lg font-black text-blue-800">K</span>
            )}
          </div>
          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-blue-800">{companyName.toUpperCase()}</h2>
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{companySub}</p>
          </div>
        </div>
        <div className="text-right">
          <h3 className="text-2xl font-extrabold tracking-tight text-slate-900">
            {docType === "keluar" ? "INVOICE STATEMENT" : "BILL RECEIPT"}
          </h3>
          <span
            className={`mt-2 inline-block rounded-md border px-3.5 py-1 text-[11px] font-bold uppercase tracking-wide ${stamp.className}`}
          >
            {stamp.label}
          </span>
        </div>
      </div>

      <div className="mb-9 grid grid-cols-1 gap-8 border-t border-slate-200 pt-6 sm:grid-cols-2">
        <div>
          <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Issued By</h4>
          <p className="font-bold text-slate-900">{companyName}</p>
          <p className="mt-0.5 whitespace-pre-line text-xs text-slate-600">{companyAddress}</p>
          <p className="mt-0.5 text-xs text-slate-500">{companyContact}</p>
        </div>
        <div className="relative pr-16">
          <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Invoiced To</h4>
          <p className="text-sm font-bold text-slate-900">{clientName || "-"}</p>
          {clientCompany && <p className="font-medium text-slate-700">{clientCompany}</p>}
          <p className="mt-0.5 text-xs text-slate-600">{clientContact || "No Contact Provided"}</p>
          <div className="absolute right-0 top-0 flex h-[60px] w-[60px] items-center justify-center overflow-hidden rounded-lg border border-dashed border-slate-300 bg-slate-50">
            {clientLogoUrl ? (
              <Image src={clientLogoUrl} alt="" width={60} height={60} className="h-full w-full object-contain" />
            ) : (
              <ImageOff className="h-4 w-4 text-slate-300" />
            )}
          </div>
        </div>
      </div>

      <div className="mb-9 grid grid-cols-3 gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4 sm:p-6">
        <div>
          <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Invoice ID</span>
          <strong className="text-sm text-slate-900">{invoiceNumber || "-"}</strong>
        </div>
        <div>
          <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Date of Issue</span>
          <strong className="text-sm text-slate-900">{issueDate || "-"}</strong>
        </div>
        <div>
          <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Due Date</span>
          <strong className="text-sm text-slate-900">{dueDate || "-"}</strong>
        </div>
      </div>

      {paymentPurpose && (
        <div className="mb-5">
          <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-slate-500">
            Project Purpose
          </span>
          <p className="text-sm font-semibold text-slate-800">{paymentPurpose}</p>
        </div>
      )}

      <table className="mb-9 w-full border-collapse">
        <thead>
          <tr>
            <th className="rounded-l-md bg-blue-800 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-white">
              Description of Services
            </th>
            <th className="bg-blue-800 px-4 py-3 text-center text-xs font-semibold uppercase tracking-wide text-white">
              Qty
            </th>
            <th className="bg-blue-800 px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-white">
              Rate
            </th>
            <th className="rounded-r-md bg-blue-800 px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-white">
              Amount
            </th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, i) => (
            <tr key={i} className="border-b border-slate-200">
              <td className="px-4 py-3.5 font-semibold text-slate-700">{item.description || "Creative Asset Services"}</td>
              <td className="px-4 py-3.5 text-center text-slate-700">{item.quantity}</td>
              <td className="px-4 py-3.5 text-right text-slate-700">{formatMoney(item.unit_price, currency)}</td>
              <td className="px-4 py-3.5 text-right font-semibold text-slate-900">
                {formatMoney(item.quantity * item.unit_price, currency)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mb-9 flex justify-end">
        <table className="w-full max-w-[300px]">
          <tbody>
            <tr>
              <td className="py-1.5 text-slate-600">Subtotal:</td>
              <td className="py-1.5 text-right text-slate-600">{formatMoney(subtotal, currency)}</td>
            </tr>
            <tr>
              <td className="py-1.5 text-slate-600">Discount ({discountPercent}%):</td>
              <td className="py-1.5 text-right text-slate-600">-{formatMoney(discountAmount, currency)}</td>
            </tr>
            <tr>
              <td className="py-1.5 text-slate-600">Tax / VAT ({taxPercent}%):</td>
              <td className="py-1.5 text-right text-slate-600">{formatMoney(taxAmount, currency)}</td>
            </tr>
            <tr className="border-t-2 border-dashed border-slate-300">
              <td className="pt-3 text-lg font-extrabold text-blue-800">Grand Total:</td>
              <td className="pt-3 text-right text-lg font-extrabold text-blue-800">
                {formatMoney(grandTotal, currency)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {(bankAccount || showQris) && (
        <div className="mb-9 flex flex-col items-start justify-between gap-6 rounded-lg border border-slate-200 bg-gradient-to-r from-slate-50 to-white p-6 sm:flex-row sm:items-center">
          <div>
            <h5 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              Remittance Gateways
            </h5>
            {bankAccount ? (
              <div className="text-xs text-slate-600">
                <p className="text-[13px] font-bold text-slate-900">{bankAccount.bank_name} Network</p>
                <p>
                  Account No: <strong>{bankAccount.account_number}</strong>
                </p>
                <p>Holder: {bankAccount.account_holder}</p>
              </div>
            ) : (
              <p className="text-xs text-slate-500">No bank gateway active</p>
            )}
          </div>
          {showQris && (
            <div className="rounded-lg border border-slate-200 bg-white p-2.5 text-center shadow-sm">
              {qrisUrl ? (
                <Image src={qrisUrl} alt="QRIS" width={130} height={130} className="block object-contain" />
              ) : (
                <div className="flex h-[130px] w-[130px] items-center justify-center bg-slate-50 text-[10px] text-slate-400">
                  No QRIS uploaded
                </div>
              )}
              <span className="mt-1.5 block text-[9px] font-bold uppercase tracking-wide text-slate-500">
                Scan to Pay
              </span>
            </div>
          )}
        </div>
      )}

      <div className="border-t border-slate-200 pt-5 text-center text-[11px] italic text-slate-500">
        {footerNote}
      </div>

      <div className="mt-6 hidden text-center text-[9px] font-medium uppercase tracking-wide text-slate-400 print:block">
        {companyName} | Premium Invoice System
      </div>
    </div>
  );
}
