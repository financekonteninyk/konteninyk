import Image from "next/image";
import { Sparkles, Calendar, User, Hash, ClipboardList, ShieldCheck } from "lucide-react";

export interface FreelancerOfferPreviewProps {
  offerNumber: string;
  freelancerName: string;
  jobTitle: string;
  price: number;
  specifications: string;
  projectDeadline: string;
  companyName: string;
  companyLogoUrl: string | null;
  printTargetId?: string;
  theme?: "light" | "dark";
}

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);
}

function formatDate(value: string): string {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

export function FreelancerOfferPreview({
  offerNumber,
  freelancerName,
  jobTitle,
  price,
  specifications,
  projectDeadline,
  companyName,
  companyLogoUrl,
  printTargetId,
  theme = "light",
}: FreelancerOfferPreviewProps) {
  return (
    <div
      id={printTargetId}
      data-print-theme={theme}
      className="relative overflow-hidden rounded-lg bg-white text-[13px] leading-relaxed text-slate-800 shadow-2xl"
    >
      {/* Decorative corner flourishes */}
      <div aria-hidden className="pointer-events-none absolute left-0 top-0 h-24 w-24 border-l-2 border-t-2 border-violet-200" style={{ margin: 14 }} />
      <div aria-hidden className="pointer-events-none absolute bottom-0 right-0 h-24 w-24 border-b-2 border-r-2 border-violet-200" style={{ margin: 14 }} />

      <div className="border-b border-slate-100 bg-gradient-to-br from-slate-50 via-white to-violet-50/60 px-10 py-14 text-center sm:px-16">
        <div className="mb-6 flex items-center justify-center gap-2.5">
          {companyLogoUrl && (
            <span className="relative h-9 w-9 overflow-hidden rounded-lg border border-slate-100 bg-white p-1">
              <Image src={companyLogoUrl} alt="" fill sizes="36px" className="object-contain" />
            </span>
          )}
          <p className="text-sm font-bold tracking-tight text-slate-900">{companyName}</p>
        </div>

        <span className="mb-5 inline-flex items-center gap-1.5 rounded-full bg-violet-100 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.15em] text-violet-700">
          <Sparkles className="h-3 w-3" />
          Project Offer
        </span>

        <p className="mb-2 text-sm text-slate-500">Dear {freelancerName || "Freelancer"},</p>
        <h1 className="mx-auto max-w-lg text-balance text-2xl font-bold leading-tight text-slate-900 sm:text-4xl">
          {jobTitle || "Project Offer"}
        </h1>

        <div className="mx-auto mt-4 h-px w-20 bg-violet-200" />

        <div className="mx-auto mt-8 max-w-xs">
          <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500">Offered Rate</span>
          <span className="mt-1 block text-4xl font-extrabold tracking-tight text-violet-700 sm:text-6xl">
            {formatIDR(price)}
          </span>
        </div>

        <p className="mx-auto mt-6 flex max-w-xs items-center justify-center gap-1.5 text-[11px] text-slate-400">
          <ShieldCheck className="h-3.5 w-3.5" />
          Ref. {offerNumber}
        </p>
      </div>

      <div className="px-10 py-12 sm:px-16">
        {specifications && (
          <div className="mb-9">
            <h4 className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              <ClipboardList className="h-3.5 w-3.5" />
              Job Description & Specifications
            </h4>
            <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-5">
              <p className="whitespace-pre-line text-slate-700">{specifications}</p>
            </div>
          </div>
        )}

        <div className="mb-9 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="flex items-center gap-3 rounded-xl border border-slate-200 p-5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet-50 text-violet-600">
              <User className="h-5 w-5" />
            </span>
            <div>
              <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Freelancer</span>
              <strong className="text-sm text-slate-900">{freelancerName || "-"}</strong>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-xl border border-slate-200 p-5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet-50 text-violet-600">
              <Calendar className="h-5 w-5" />
            </span>
            <div>
              <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-500">Project Deadline</span>
              <strong className="text-sm text-slate-900">{formatDate(projectDeadline)}</strong>
            </div>
          </div>
        </div>

        <p className="text-center text-xs italic text-slate-500">
          We're excited about the possibility of working with you. Let us know if you have any
          questions about this offer, or if you're ready to get started.
        </p>
      </div>

      <div className="flex items-center justify-center gap-1.5 border-t border-slate-100 bg-slate-50 px-10 py-4 text-center text-[10px] uppercase tracking-wide text-slate-400">
        <Hash className="h-3 w-3" />
        {offerNumber} — {companyName}
      </div>
    </div>
  );
}
