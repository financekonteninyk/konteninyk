import { getYouTubeId } from "@/lib/utils";

export function YouTubeEmbed({ url, title }: { url: string; title: string }) {
  const videoId = getYouTubeId(url);

  if (!videoId) return null;

  return (
    <div className="aspect-video w-full overflow-hidden rounded-2xl border border-border shadow-sm">
      <iframe
        src={`https://www.youtube.com/embed/${videoId}`}
        title={`${title} — YouTube video`}
        className="h-full w-full"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    </div>
  );
}
