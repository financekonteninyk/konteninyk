import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SocialLinkButtonProps {
  href: string;
  icon: LucideIcon;
  label: string;
}

export function SocialLinkButton({ href, icon: Icon, label }: SocialLinkButtonProps) {
  return (
    <Button asChild variant="outline" size="lg">
      <Link href={href} target="_blank" rel="noreferrer noopener">
        <Icon className="h-4 w-4" />
        {label}
      </Link>
    </Button>
  );
}
