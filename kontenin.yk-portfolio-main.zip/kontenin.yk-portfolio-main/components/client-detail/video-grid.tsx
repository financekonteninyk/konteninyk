import { VideoCard } from "@/components/client-detail/video-card";
import { EmptyState } from "@/components/shared/empty-state";
import type { Video } from "@/types/video";

export function VideoGrid({ videos }: { videos: Video[] }) {
  if (videos.length === 0) {
    return (
      <EmptyState
        title="No videos yet"
        description="Content for this client hasn't been published yet — check back soon."
      />
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
      {videos.map((video) => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
}
