"use client";

import { motion } from "framer-motion";
import { Flag, Compass, Video, TrendingUp } from "lucide-react";
import type { Client } from "@/types/client";

interface CaseStudySectionProps {
  client: Pick<
    Client,
    "case_study_challenge" | "case_study_strategy" | "case_study_production" | "case_study_result"
  >;
}

const STEPS = [
  { key: "case_study_challenge" as const, number: "01", title: "Challenge", icon: Flag },
  { key: "case_study_strategy" as const, number: "02", title: "Strategy", icon: Compass },
  { key: "case_study_production" as const, number: "03", title: "Production", icon: Video },
  { key: "case_study_result" as const, number: "04", title: "Result", icon: TrendingUp },
];

export function CaseStudySection({ client }: CaseStudySectionProps) {
  const steps = STEPS.filter((step) => client[step.key]);

  if (steps.length === 0) return null;

  return (
    <div className="mt-16 border-t border-border pt-16">
      <span className="eyebrow mb-3 block text-xs text-muted-foreground">Case Study</span>
      <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">How We Got There</h2>

      <div className="mt-10 grid grid-cols-1 gap-10 md:grid-cols-2">
        {steps.map((step, i) => (
          <motion.div
            key={step.key}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
          >
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full border border-border">
                <step.icon className="h-4 w-4" />
              </span>
              <div>
                <span className="eyebrow block text-xs text-muted-foreground">{step.number}</span>
                <h3 className="font-semibold tracking-tight">{step.title}</h3>
              </div>
            </div>
            <p className="mt-4 whitespace-pre-line leading-relaxed text-muted-foreground">
              {client[step.key]}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
