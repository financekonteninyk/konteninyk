"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Instagram, Music2, Youtube, Play, Eye, Layers } from "lucide-react";
import type { Video } from "@/types/video";

const PLATFORM_ICON = {
  instagram: Instagram,
  tiktok: Music2,
  youtube: Youtube,
  other: Play,
} as const;

function getVideoLink(video: Video): string | null {
  return video.youtube_url || video.instagram_url || video.tiktok_url || null;
}

export function VideoCard({ video }: { video: Video }) {
  const link = getVideoLink(video);
  const Icon = video.platform ? PLATFORM_ICON[video.platform] : Play;

  const content = (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.35 }}
      className={`group relative w-full overflow-hidden rounded-2xl border border-border bg-muted shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
        video.content_type === "carousel" ? "aspect-[4/5]" : "aspect-[9/16]"
      }`}
    >
      <Image
        src={video.thumbnail_url}
        alt={video.title ?? "Video thumbnail"}
        fill
        sizes="(max-width: 768px) 45vw, (max-width: 1200px) 22vw, 16vw"
        className="object-cover transition-transform duration-500 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/0 to-black/0 opacity-80 transition-opacity group-hover:opacity-100" />

      {video.content_type === "carousel" && (
        <div className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-black/40 px-2 py-1 text-[10px] font-medium text-white backdrop-blur-sm">
          <Layers className="h-3 w-3" />
          {video.carousel_images.length + 1}
        </div>
      )}

      <div className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white backdrop-blur-sm">
        <Icon className="h-4 w-4" />
      </div>

      {(video.title || video.views_count) && (
        <div className="absolute inset-x-0 bottom-0 p-3">
          {video.title && (
            <p className="line-clamp-2 text-sm font-medium text-white">{video.title}</p>
          )}
          {video.views_count != null && (
            <div className="mt-1 flex items-center gap-1 text-xs text-white/80">
              <Eye className="h-3 w-3" />
              {video.views_count.toLocaleString()}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );

  if (!link) return content;

  return (
    <a href={link} target="_blank" rel="noreferrer noopener" aria-label={video.title ?? "View video"}>
      {content}
    </a>
  );
}
