import Link from "next/link";
import { Check, Minus, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { PricingCategory } from "@/types/pricing";

// Same palette used on the printable pricing sheets, for visual consistency
// with your reference price list design.
const ACCENT_COLORS = ["#5B8FB9", "#9CAF6B", "#E39A5D", "#B3273E", "#7C6FA6"];

function formatIDR(value: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    value
  );
}

function waLinkFor(baseUrl: string | null, tierName: string, categoryName: string): string | null {
  if (!baseUrl) return null;
  const message = `Halo, saya tertarik dengan paket ${tierName} (${categoryName}). Boleh minta info lebih lanjut?`;
  const separator = baseUrl.includes("?") ? "&" : "?";
  return `${baseUrl}${separator}text=${encodeURIComponent(message)}`;
}

export function PricingCategoryDisplay({
  category,
  whatsappUrl,
  ctaLabel,
}: {
  category: PricingCategory;
  whatsappUrl: string | null;
  ctaLabel: string;
}) {
  return (
    <div className="mb-20 last:mb-0">
      <div className="mb-10">
        <h2 className="text-2xl font-bold tracking-tight md:text-3xl">{category.name}</h2>
        {category.subtitle && <p className="mt-2 text-muted-foreground">{category.subtitle}</p>}
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        {category.tiers.map((tier, i) => {
          const isHighlighted = Boolean(tier.badge);
          const link = waLinkFor(whatsappUrl, tier.name, category.name);
          const accent = ACCENT_COLORS[i % ACCENT_COLORS.length];

          return (
            <div
              key={i}
              className={`flex flex-col overflow-hidden rounded-2xl border p-6 ${
                isHighlighted ? "border-foreground shadow-lg" : "border-border"
              }`}
              style={{ borderTop: `4px solid ${accent}` }}
            >
              {tier.badge && (
                <span className="mb-3 inline-flex w-fit items-center gap-1 rounded-full bg-foreground px-2.5 py-1 text-[11px] font-semibold text-background">
                  <Star className="h-3 w-3 fill-current" />
                  {tier.badge}
                </span>
              )}

              <h3 className="text-lg font-semibold">{tier.name}</h3>
              <p className="mt-2 text-3xl font-bold tracking-tight">
                {formatIDR(tier.price)}
                {tier.period && <span className="text-base font-medium text-muted-foreground">{tier.period}</span>}
              </p>

              {tier.description && <p className="mt-3 text-sm text-muted-foreground">{tier.description}</p>}

              <ul className="mt-6 flex-1 space-y-2.5">
                {tier.features.map((feature, j) => {
                  const isTrue = feature.value === "true";
                  const isFalse = feature.value === "false";
                  return (
                    <li
                      key={j}
                      className={`flex items-start gap-2 text-sm ${
                        isFalse ? "text-muted-foreground/50" : "text-foreground"
                      }`}
                    >
                      {isFalse ? (
                        <Minus className="mt-0.5 h-4 w-4 shrink-0" />
                      ) : (
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      )}
                      <span>
                        {feature.label}
                        {!isTrue && !isFalse && (
                          <span className="text-muted-foreground"> — {feature.value}</span>
                        )}
                      </span>
                    </li>
                  );
                })}
              </ul>

              {link && (
                <Button asChild className="mt-6" variant={isHighlighted ? "gradient" : "outline"}>
                  <Link href={link} target="_blank" rel="noreferrer noopener">
                    {ctaLabel}
                  </Link>
                </Button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
